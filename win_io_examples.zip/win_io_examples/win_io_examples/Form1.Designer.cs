﻿namespace win_io_examples
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_binarywriter = new System.Windows.Forms.Button();
            this.btn_binaryreader = new System.Windows.Forms.Button();
            this.btn_streamreader = new System.Windows.Forms.Button();
            this.btn_streamwriter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_binarywriter
            // 
            this.btn_binarywriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_binarywriter.Location = new System.Drawing.Point(64, 76);
            this.btn_binarywriter.Name = "btn_binarywriter";
            this.btn_binarywriter.Size = new System.Drawing.Size(170, 44);
            this.btn_binarywriter.TabIndex = 0;
            this.btn_binarywriter.Text = "Binary Writer";
            this.btn_binarywriter.UseVisualStyleBackColor = true;
            this.btn_binarywriter.Click += new System.EventHandler(this.btn_binarywriter_Click);
            // 
            // btn_binaryreader
            // 
            this.btn_binaryreader.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_binaryreader.Location = new System.Drawing.Point(64, 174);
            this.btn_binaryreader.Name = "btn_binaryreader";
            this.btn_binaryreader.Size = new System.Drawing.Size(170, 48);
            this.btn_binaryreader.TabIndex = 1;
            this.btn_binaryreader.Text = "Binary Reader";
            this.btn_binaryreader.UseVisualStyleBackColor = true;
            this.btn_binaryreader.Click += new System.EventHandler(this.btn_binaryreader_Click);
            // 
            // btn_streamreader
            // 
            this.btn_streamreader.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_streamreader.Location = new System.Drawing.Point(326, 174);
            this.btn_streamreader.Name = "btn_streamreader";
            this.btn_streamreader.Size = new System.Drawing.Size(170, 48);
            this.btn_streamreader.TabIndex = 3;
            this.btn_streamreader.Text = "Stream Reader";
            this.btn_streamreader.UseVisualStyleBackColor = true;
            this.btn_streamreader.Click += new System.EventHandler(this.btn_streamreader_Click);
            // 
            // btn_streamwriter
            // 
            this.btn_streamwriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_streamwriter.Location = new System.Drawing.Point(326, 76);
            this.btn_streamwriter.Name = "btn_streamwriter";
            this.btn_streamwriter.Size = new System.Drawing.Size(170, 44);
            this.btn_streamwriter.TabIndex = 2;
            this.btn_streamwriter.Text = "Stream Writer";
            this.btn_streamwriter.UseVisualStyleBackColor = true;
            this.btn_streamwriter.Click += new System.EventHandler(this.btn_streamwriter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 400);
            this.Controls.Add(this.btn_streamreader);
            this.Controls.Add(this.btn_streamwriter);
            this.Controls.Add(this.btn_binaryreader);
            this.Controls.Add(this.btn_binarywriter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_binarywriter;
        private System.Windows.Forms.Button btn_binaryreader;
        private System.Windows.Forms.Button btn_streamreader;
        private System.Windows.Forms.Button btn_streamwriter;
    }
}

