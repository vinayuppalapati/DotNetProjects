﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employee
{
    class Company
    {
        public void onLeave(int ID, string Reason)
        {
            Console.WriteLine("Company Class : Employee on Leave :" + ID + " , " + Reason);
        }
        private string Address;
        private string CompanyName;

        public Company(string CompanyName,string Address)
        {
            this.CompanyName = CompanyName;
            this.Address = Address;
        }
        private List<Employee> employeelist = new List<Employee>();

        public void AddEmployee(Employee ei)
        {
            Employee.delleave d = new Employee.delleave(this.onLeave);
            ei.evtleave += d;
            employeelist.Add(ei);
        }
        public Employee Find(int ID)
        {
            foreach (Employee e in employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    return e;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach (Employee s in employeelist)
            {
                if (s.PEmployeeID == ID)
                {
                    employeelist.Remove(s);
                    return true;
                }
            }
            return false;
        }




        public void ShowAll()
        {
            foreach (Employee e in employeelist)
            {
                Console.WriteLine(e.PEmployeeID + " " + e.PEmployeeName + " " + e.PEmployeeCity);
            }
        }
    }
}
