﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Day19_11_mvc_mybankwebsite.Controllers
{
    public class BankController : Controller
    {
        // GET: Bank
        public ActionResult Index()
        {
            int username = Convert.ToInt32(Session["username"]);    
            ViewBag.username = username;
            return View();
        }
        public ActionResult NewUser()
        {
            return View();
        }
        [HttpPost]
        public ActionResult NewUser(string email,string password,string fullname,string city,string mobileno)
        {
            string mail = email;
            string pass = password;
            string name = fullname;
            string ccity = city;
            string phonene = mobileno;
            ViewBag.msg = "Account Created";
            return View();
        }
        
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(int username,string password)
        {
            if (username == 1002 && password =="pass")
            {
                Session["username"] = username;
                return RedirectToAction("Index", "Bank");
            }

            else
            {
                ViewBag.msg = "Invalid user name and password";
                return View();
            }
        }
    }
}