﻿namespace win_salary_calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_days = new System.Windows.Forms.Label();
            this.lbl_perdaysalary = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_perdaysalary = new System.Windows.Forms.TextBox();
            this.btn_GetSalary = new System.Windows.Forms.Button();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_days.Location = new System.Drawing.Point(49, 57);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(57, 25);
            this.lbl_days.TabIndex = 0;
            this.lbl_days.Text = "Days";
            // 
            // lbl_perdaysalary
            // 
            this.lbl_perdaysalary.AutoSize = true;
            this.lbl_perdaysalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_perdaysalary.Location = new System.Drawing.Point(52, 120);
            this.lbl_perdaysalary.Name = "lbl_perdaysalary";
            this.lbl_perdaysalary.Size = new System.Drawing.Size(143, 25);
            this.lbl_perdaysalary.TabIndex = 1;
            this.lbl_perdaysalary.Text = "Per Day Salary";
            // 
            // txt_days
            // 
            this.txt_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_days.Location = new System.Drawing.Point(267, 49);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 30);
            this.txt_days.TabIndex = 2;
            // 
            // txt_perdaysalary
            // 
            this.txt_perdaysalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_perdaysalary.Location = new System.Drawing.Point(267, 120);
            this.txt_perdaysalary.Name = "txt_perdaysalary";
            this.txt_perdaysalary.Size = new System.Drawing.Size(100, 30);
            this.txt_perdaysalary.TabIndex = 3;
            // 
            // btn_GetSalary
            // 
            this.btn_GetSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GetSalary.Location = new System.Drawing.Point(82, 198);
            this.btn_GetSalary.Name = "btn_GetSalary";
            this.btn_GetSalary.Size = new System.Drawing.Size(125, 38);
            this.btn_GetSalary.TabIndex = 4;
            this.btn_GetSalary.Text = "Get Salary";
            this.btn_GetSalary.UseVisualStyleBackColor = true;
            this.btn_GetSalary.Click += new System.EventHandler(this.btn_GetSalary_Click);
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.Location = new System.Drawing.Point(267, 205);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(79, 25);
            this.lbl_Salary.TabIndex = 5;
            this.lbl_Salary.Text = "Salary :";
            this.lbl_Salary.Click += new System.EventHandler(this.lbl_Salary_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 388);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.btn_GetSalary);
            this.Controls.Add(this.txt_perdaysalary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.lbl_perdaysalary);
            this.Controls.Add(this.lbl_days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.Label lbl_perdaysalary;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_perdaysalary;
        private System.Windows.Forms.Button btn_GetSalary;
        private System.Windows.Forms.Label lbl_Salary;
    }
}

