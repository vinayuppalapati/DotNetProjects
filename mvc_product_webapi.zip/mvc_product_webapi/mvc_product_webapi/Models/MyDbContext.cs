﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;


namespace mvc_product_webapi.Models
{
    public class MyDbContext:DbContext
    {
        public MyDbContext() : base("constr")
        {

        }
       public  DbSet<ProductModel> products { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductModel>().MapToStoredProcedures();
        }
    }
}