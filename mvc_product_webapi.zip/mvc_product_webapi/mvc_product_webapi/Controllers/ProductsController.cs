﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using mvc_product_webapi.Models;

namespace mvc_product_webapi.Controllers
{
    public class ProductsController : ApiController
    {
        // GET: api/Products
        public IEnumerable<ProductModel> Get()
        {
            MyDbContext db = new MyDbContext();
            var data = db.products.ToList();
            return data;
        }

        // GET: api/Products/5
        public ProductModel Get(int id)
        {
            MyDbContext db = new MyDbContext();
            var model = db.products.FirstOrDefault(p => p.ProductID == id);
            return model;
        }
        [HttpGet]
        [Route("api/Search/{key}")]
        public IEnumerable<ProductModel> Search(string key)
        {
            MyDbContext db = new MyDbContext();
            var data = db.products.Where(p => p.PName.Contains(key) || p.ProcCategory.Contains(key)).ToList();
            return data;

        }
        // POST: api/Products
        public int Post([FromBody]ProductModel value)
        {
            MyDbContext db = new MyDbContext();
            db.products.Add(value);
            db.SaveChanges();
            return value.ProductID;

        }

        // PUT: api/Products/5
        public void Put(int id, [FromBody]ProductModel value)
        {
            MyDbContext db = new MyDbContext();
            var dbmodel = db.products.FirstOrDefault(p => p.ProductID==id);
            dbmodel.PName = value.PName;
            dbmodel.PPrice = value.PPrice;
            dbmodel.ProcCategory = value.ProcCategory;
            db.SaveChanges();
        }

        // DELETE: api/Products/5
        public void Delete(int id)
        {
            MyDbContext db = new MyDbContext();
            var model = db.products.FirstOrDefault(p => p.ProductID == id);
            db.products.Remove(model);
            db.SaveChanges();
        }
    }
}
