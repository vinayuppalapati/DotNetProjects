namespace mvc_product_webapi.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MyDB : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ProductModels",
                c => new
                    {
                        ProductID = c.Int(nullable: false, identity: true),
                        PName = c.String(nullable: false),
                        PPrice = c.Int(nullable: false),
                        ProcCategory = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ProductID);
            
            CreateStoredProcedure(
                "dbo.ProductModel_Insert",
                p => new
                    {
                        PName = p.String(),
                        PPrice = p.Int(),
                        ProcCategory = p.String(),
                    },
                body:
                    @"INSERT [dbo].[ProductModels]([PName], [PPrice], [ProcCategory])
                      VALUES (@PName, @PPrice, @ProcCategory)
                      
                      DECLARE @ProductID int
                      SELECT @ProductID = [ProductID]
                      FROM [dbo].[ProductModels]
                      WHERE @@ROWCOUNT > 0 AND [ProductID] = scope_identity()
                      
                      SELECT t0.[ProductID]
                      FROM [dbo].[ProductModels] AS t0
                      WHERE @@ROWCOUNT > 0 AND t0.[ProductID] = @ProductID"
            );
            
            CreateStoredProcedure(
                "dbo.ProductModel_Update",
                p => new
                    {
                        ProductID = p.Int(),
                        PName = p.String(),
                        PPrice = p.Int(),
                        ProcCategory = p.String(),
                    },
                body:
                    @"UPDATE [dbo].[ProductModels]
                      SET [PName] = @PName, [PPrice] = @PPrice, [ProcCategory] = @ProcCategory
                      WHERE ([ProductID] = @ProductID)"
            );
            
            CreateStoredProcedure(
                "dbo.ProductModel_Delete",
                p => new
                    {
                        ProductID = p.Int(),
                    },
                body:
                    @"DELETE [dbo].[ProductModels]
                      WHERE ([ProductID] = @ProductID)"
            );
            
        }
        
        public override void Down()
        {
            DropStoredProcedure("dbo.ProductModel_Delete");
            DropStoredProcedure("dbo.ProductModel_Update");
            DropStoredProcedure("dbo.ProductModel_Insert");
            DropTable("dbo.ProductModels");
        }
    }
}
