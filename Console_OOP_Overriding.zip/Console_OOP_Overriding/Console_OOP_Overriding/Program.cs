﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Employee ID");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary: ");
            int salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter type of Employee: ");
            string type = Console.ReadLine();

            Employee obj = null;

          

            if (type == "Employee")
            {
                obj = new Employee(id, name, salary);
            }
            else if (type == "Contract")
            {
                obj = new Employee_Contract(id, name, salary);
            }
            else if (type == "Trainee")
            {
                obj = new Employee_Trainee(id, name, salary);
            }
            if (obj != null)
            {

                string work = obj.GetWork();
               // obj.NewEmployeeMethod("yugi");
                Console.WriteLine(work);
               


                Console.WriteLine("Enter Days : ");
                int Days = Convert.ToInt32(Console.ReadLine());
                int CurrentMonthSalary = obj.GetSalary(Days);
                Console.WriteLine("Salary : " + CurrentMonthSalary);
            }
            Console.ReadLine();




        }
    }
}
