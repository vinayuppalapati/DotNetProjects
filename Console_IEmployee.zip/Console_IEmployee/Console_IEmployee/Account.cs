﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_IEmployee
{
    class Account 
    {
        public void GetEmployee(IAccountEmp e)
        {
            Console.WriteLine("Account Section");
            Console.WriteLine("Employee ID is : "+e.GetEmployeeID());
            Console.WriteLine("Employee Account Number : "+e.GetEmployeeAccountNumber());
            Console.WriteLine("Employee Salary :"+e.GetEmployeeSalary());
        }
    }
}
