﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_IEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee(234, "vinay", "vijayawada", "Bangalore", "IOT", 2, 2343434, "SBI", 34, 25000);
            HR h = new HR();
            h.GetEmployee(e);
           
            Manager m = new Manager();
            m.GetEmployee(e);
           
            Account a = new Account();
            a.GetEmployee(e);
            

            Console.ReadLine();



        }
    }
}
