﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_IEmployee
{
    class HR 
    {
        public void GetEmployee(IHREMp e)
        {
            Console.WriteLine("HR Section");
            Console.WriteLine("Employee ID is : " + e.GetEmployeeID());
            Console.WriteLine("Address is : "+e.GetEmployeeAddress());
            Console.WriteLine("Employee Salary :" + e.GetEmployeeSalary());
        }
    }
}
