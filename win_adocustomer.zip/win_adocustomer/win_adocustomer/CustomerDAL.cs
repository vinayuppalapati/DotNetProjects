﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;


namespace win_adocustomer
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(Customer cus)
        {
            SqlCommand com_cus_insert = new SqlCommand("insert tbl_customers values(@name,@password,@city,@address,@mobileno,@email)", con);
            com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
            com_cus_insert.Parameters.AddWithValue("@city", cus.CustomerCity);
            com_cus_insert.Parameters.AddWithValue("@address", cus.CustomerAddress);
            com_cus_insert.Parameters.AddWithValue("@mobileno", cus.CustomerMobileNo);
            com_cus_insert.Parameters.AddWithValue("@email", cus.CustomerEmailID);
            con.Open();
            com_cus_insert.ExecuteNonQuery();

            SqlCommand com_id = new SqlCommand("select @@identity",con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());

            con.Close();
            return ID;
        }
        public Customer Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_customers where CustomerID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            
            if (dr.Read())
            {
                Customer c = new Customer();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassword = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomerMobileNo = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                return c;
            }
            else
            {
                return null;
            }
            
        }
        public bool update(int ID,string Mobileno,string email)
        {
            SqlCommand com_update = new SqlCommand("update tbl_customers set CustomerMobileNo=@mobile,CustomerEmailID=@email where CustomerID=@id", con);
            com_update.Parameters.AddWithValue("@mobile", Mobileno);
            com_update.Parameters.AddWithValue("@email", email);
            com_update.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_customers where CustomerID=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}
