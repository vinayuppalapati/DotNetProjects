﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_adocustomer
{
    public partial class frm_New : Form
    {
        public frm_New()
        {
            InitializeComponent();
        }

        private void btn_findcustomer_Click(object sender, EventArgs e)
        {
            frm_Find f1 = new frm_Find();
            f1.Show();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customeraddress.Text = string.Empty;
            txt_customercity.Text = string.Empty;
            txt_customeremailid.Text = string.Empty;
            txt_customermobileno.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;
            txt_customername.Text = string.Empty;
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            if(txt_customername.Text == string.Empty)
            {
                MessageBox.Show("Enter Name ");
            }
            else if(txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("Enter password");
            }
            else if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                MessageBox.Show("Enter address");
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("Enter MobileNo");
            }
            else if (txt_customeremailid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailID");
            }else
            {
                try { 
                Customer obj = new Customer();
                obj.CustomerName = txt_customername.Text;
                obj.CustomerPassword = txt_customerpassword.Text;
                obj.CustomerMobileNo = txt_customermobileno.Text;
                obj.CustomerEmailID = txt_customeremailid.Text;
                obj.CustomerCity = txt_customercity.Text;
                obj.CustomerAddress = txt_customeraddress.Text;

                CustomerDAL_proc dal = new CustomerDAL_proc();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("Customer id is : "+id);
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }

        }
    }
}
