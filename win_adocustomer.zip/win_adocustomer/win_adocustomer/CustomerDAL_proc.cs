﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace win_adocustomer
{
    class CustomerDAL_proc
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(Customer cus)
        {
            try
            {
                SqlCommand com_cus_insert = new SqlCommand("proc_addcustomer", con);
                com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
                com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
                com_cus_insert.Parameters.AddWithValue("@city", cus.CustomerCity);
                com_cus_insert.Parameters.AddWithValue("@address", cus.CustomerAddress);
                com_cus_insert.Parameters.AddWithValue("@mobileno", cus.CustomerMobileNo);
                com_cus_insert.Parameters.AddWithValue("@email", cus.CustomerEmailID);
                com_cus_insert.CommandType = CommandType.StoredProcedure;

                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cus_insert.Parameters.Add(retdata);

                con.Open();
                com_cus_insert.ExecuteNonQuery();

                int ID = Convert.ToInt32(retdata.Value);

                con.Close();
                return ID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public Customer Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("proc_customerdetails", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;


            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();

            if (dr.Read())
            {
                Customer c = new Customer();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassword = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomerMobileNo = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                return c;
            }
            else
            {
                return null;
            }

        }
        public bool update(int ID, string address, string mobileno)
        {
            try
            {
                SqlCommand com_update = new SqlCommand("proc_updatecustomer", con);
                com_update.Parameters.AddWithValue("@mobileno", mobileno);
                com_update.Parameters.AddWithValue("@address", address);
                com_update.Parameters.AddWithValue("@id", ID);
                com_update.CommandType = CommandType.StoredProcedure;

                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                con.Open();
                int count = com_update.ExecuteNonQuery();
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool delete(int ID)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletecustomer", con);
                com_delete.Parameters.AddWithValue("@id", ID);
                com_delete.CommandType = CommandType.StoredProcedure;

                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                con.Open();

                int count = com_delete.ExecuteNonQuery();
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        
        }
        public List<Customer> ShowCustomers(string City)
        {
            try
            {
                SqlCommand com_customers = new SqlCommand
                    ("proc_showcustomers", con);
                com_customers.Parameters.AddWithValue("@city", City);
                com_customers.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = com_customers.ExecuteReader();

                List<Customer> cuslist = new List<Customer>();
                while (dr.Read())
                {
                    Customer obj = new Customer();
                    obj.CustomerID = dr.GetInt32(0);
                    obj.CustomerName = dr.GetString(1);
                    obj.CustomerPassword = dr.GetString(2);
                    obj.CustomerCity = dr.GetString(3);
                    obj.CustomerAddress = dr.GetString(4);
                    obj.CustomerMobileNo = dr.GetString(5);
                    obj.CustomerEmailID = dr.GetString(6);

                    cuslist.Add(obj);
                }
                con.Close();
                return cuslist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Login(int ID, string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_logincustomer", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
    }
}
