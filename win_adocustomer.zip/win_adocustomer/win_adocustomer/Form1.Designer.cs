﻿namespace win_adocustomer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_findcustomer = new System.Windows.Forms.Button();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_findcustomer
            // 
            this.btn_findcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findcustomer.Location = new System.Drawing.Point(351, 180);
            this.btn_findcustomer.Name = "btn_findcustomer";
            this.btn_findcustomer.Size = new System.Drawing.Size(156, 55);
            this.btn_findcustomer.TabIndex = 0;
            this.btn_findcustomer.Text = "Find Customer";
            this.btn_findcustomer.UseVisualStyleBackColor = true;
            this.btn_findcustomer.Click += new System.EventHandler(this.btn_findcustomer_Click_1);
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newcustomer.Location = new System.Drawing.Point(140, 180);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(173, 55);
            this.btn_newcustomer.TabIndex = 1;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 471);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.btn_findcustomer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_findcustomer;
        private System.Windows.Forms.Button btn_newcustomer;
    }
}

