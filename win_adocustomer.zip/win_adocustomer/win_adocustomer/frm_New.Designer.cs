﻿namespace win_adocustomer
{
    partial class frm_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_findcustomer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(42, 56);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(64, 25);
            this.lbl_customername.TabIndex = 0;
            this.lbl_customername.Text = "Name";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(45, 104);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(98, 25);
            this.lbl_customerpassword.TabIndex = 1;
            this.lbl_customerpassword.Text = "Password";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(48, 148);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(46, 25);
            this.lbl_customercity.TabIndex = 2;
            this.lbl_customercity.Text = "City";
            this.lbl_customercity.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeraddress.Location = new System.Drawing.Point(45, 191);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(85, 25);
            this.lbl_customeraddress.TabIndex = 3;
            this.lbl_customeraddress.Text = "Address";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customermobileno.Location = new System.Drawing.Point(45, 236);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(144, 25);
            this.lbl_customermobileno.TabIndex = 4;
            this.lbl_customermobileno.Text = "Mobile Number";
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeremailid.Location = new System.Drawing.Point(45, 278);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(79, 25);
            this.lbl_customeremailid.TabIndex = 5;
            this.lbl_customeremailid.Text = "EmailID";
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(233, 56);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(156, 30);
            this.txt_customername.TabIndex = 6;
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(233, 96);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(156, 30);
            this.txt_customerpassword.TabIndex = 7;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customercity.Location = new System.Drawing.Point(233, 140);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(156, 30);
            this.txt_customercity.TabIndex = 8;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(233, 191);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(156, 30);
            this.txt_customeraddress.TabIndex = 9;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(233, 236);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(156, 30);
            this.txt_customermobileno.TabIndex = 10;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(233, 275);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(156, 30);
            this.txt_customeremailid.TabIndex = 11;
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newcustomer.Location = new System.Drawing.Point(126, 383);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(171, 48);
            this.btn_newcustomer.TabIndex = 12;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(351, 383);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(162, 48);
            this.btn_reset.TabIndex = 13;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_findcustomer
            // 
            this.btn_findcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findcustomer.Location = new System.Drawing.Point(434, 93);
            this.btn_findcustomer.Name = "btn_findcustomer";
            this.btn_findcustomer.Size = new System.Drawing.Size(187, 59);
            this.btn_findcustomer.TabIndex = 14;
            this.btn_findcustomer.Text = "Find Customer";
            this.btn_findcustomer.UseVisualStyleBackColor = true;
            this.btn_findcustomer.Click += new System.EventHandler(this.btn_findcustomer_Click);
            // 
            // frm_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 492);
            this.Controls.Add(this.btn_findcustomer);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "frm_New";
            this.Text = "frm_New";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_findcustomer;
    }
}