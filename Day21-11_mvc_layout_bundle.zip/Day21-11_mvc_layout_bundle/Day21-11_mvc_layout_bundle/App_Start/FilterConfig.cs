﻿using System.Web;
using System.Web.Mvc;

namespace Day21_11_mvc_layout_bundle
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
