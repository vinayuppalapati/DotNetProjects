﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


/// <summary>
/// Summary description for StudentDAL
/// </summary>
public class StudentDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    
        public int addStudent(Student s)
    {
        try
        {

       
        SqlCommand com_st_insert = new SqlCommand("proc_addstudent",con);
        com_st_insert.Parameters.AddWithValue("@name", s.StudentName);
        com_st_insert.Parameters.AddWithValue("@city", s.StudentCity);
        com_st_insert.Parameters.AddWithValue("@image", s.StudentImageAddress);
        com_st_insert.CommandType = CommandType.StoredProcedure;

        SqlParameter retdata = new SqlParameter();
        retdata.Direction = ParameterDirection.ReturnValue;
        com_st_insert.Parameters.Add(retdata);

        con.Open();
        com_st_insert.ExecuteNonQuery();
        int ID = Convert.ToInt32(retdata.Value);
        con.Close();
        return ID;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
        }


    }
    public List<Student> searchStudent(string key)
    {
        try
        {

        List<Student> list_students = new List<Student>();
        SqlCommand com_st_sea = new SqlCommand("proc_search", con);
        com_st_sea.Parameters.AddWithValue("@key", key);
        com_st_sea.CommandType = CommandType.StoredProcedure;

        con.Open();
        SqlDataReader dr = com_st_sea.ExecuteReader();

        while (dr.Read())
        {
            Student s = new Student();
            s.StudentID = dr.GetInt32(0);
            s.StudentName = dr.GetString(1);
            s.StudentCity = dr.GetString(2);
            s.StudentImageAddress = dr.GetString(3);
            list_students.Add(s);
        }
        con.Close();

        return list_students;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }
             
    public Student Find(int id)
    {
        try
        {

        SqlCommand com_st_find = new SqlCommand("proc_details", con);
        com_st_find.Parameters.AddWithValue("@id", id);
        com_st_find.CommandType = CommandType.StoredProcedure;
        con.Open();
            Student s = new Student();
            SqlDataReader dr = com_st_find.ExecuteReader();
        if(dr.Read())
        {
            
            s.StudentID = dr.GetInt32(0);
            s.StudentName = dr.GetString(1);
            s.StudentCity = dr.GetString(2);
            s.StudentImageAddress = dr.GetString(3);
                con.Close();
                return s;
            }
           
            return null;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

        //
        // TODO: Add constructor logic here
        //
    
}