﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewStudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddl_city.Items.Add(new ListItem("Select", ""));
            ddl_city.Items.Add(new ListItem("VIJ", "VIJ"));
            ddl_city.Items.Add(new ListItem("BGL", "BGL"));
            ddl_city.Items.Add(new ListItem("HYD", "HYD"));
        }
    }



    protected void btn_newstudent_Click(object sender, EventArgs e)
    {
        Student s = new Student();
        s.StudentName = txt_name.Text;
        s.StudentCity = ddl_city.Text;
        s.StudentImageAddress = "~/Images/" + Guid.NewGuid() + ".jpg";
        flp_image.SaveAs(Server.MapPath(s.StudentImageAddress));
        StudentDAL dal = new StudentDAL();
        int id = dal.addStudent(s);
        lbl_studentid.Text = id.ToString();
    }
}