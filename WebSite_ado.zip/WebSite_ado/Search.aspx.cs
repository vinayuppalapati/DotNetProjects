﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_search_Click(object sender, EventArgs e)
    {
        StudentDAL dal = new StudentDAL();
        List<Student> list = dal.searchStudent(txt_search.Text);
        gv.DataSource = list;
        gv.DataBind();
    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = gv.SelectedRow.FindControl("lbl_sid") as Label;
        string id = l.Text;
        Response.Redirect("~/Details.aspx?id=" + id);
    }
}