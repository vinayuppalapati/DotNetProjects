create database studentdb

use studentdb 

create table tbl_student(
studentID int identity(100,1) primary key,
StudentName varchar(100) not null,
StudentCity varchar(100) not null,
StudentImageAddres varchar(1000) not null)

alter proc proc_addstudent(@name varchar(100),@city varchar(100),@image varchar(1000))
as
insert tbl_student values(@name,@city,@image)
return @@identity



create proc proc_search(@key varchar(1000))
as
select * from tbl_student where studentID like '%'+@key+'%'
or StudentName like '%'+@key+'%'
or StudentCity like '%'+@key+'%'

create proc proc_details(@id int)
as
select * from tbl_student where studentID=@id