﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_Cookies : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_addcookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie("code", txt_addcookie.Text);
        c.Expires = DateTime.Now.AddDays(30);
        Response.Cookies.Add(c);
    }

    protected void btn_readcookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = Request.Cookies["code"];
        lbl_pid.Text = c.Value;

    }
}