﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_Session : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_add_session_Click(object sender, EventArgs e)
    {
        string str = txt_sessiondata.Text;
        Session["data"] = str;
    }

    protected void btn_read_sessionid_Click(object sender, EventArgs e)
    {
        string sid = Session.SessionID;
        lbl_sessionid.Text = sid;
    }

    protected void btn_read_sessiondata_Click(object sender, EventArgs e)
    {
        if (Session["data"] == null)
        {
            Response.Redirect("~/SessionExpiredPage.aspx");
        }
        else
        {
            string str = Session["data"].ToString();
            lbl_sessiondata.Text = str; 
        }
        
    }
}