﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_ViewState : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    int count;
    protected void btn_count_Click(object sender, EventArgs e)
    {
        if (ViewState["c"] == null)
        {
            ViewState["c"] = 0;
        }
        count = Convert.ToInt32(ViewState["c"]);


        count++;
        ViewState["c"] = count;

        lbl_count.Text = count.ToString();
    }
}