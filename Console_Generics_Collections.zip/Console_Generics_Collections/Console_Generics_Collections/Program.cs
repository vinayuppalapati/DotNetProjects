﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1, "Pathfront");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter you Operation : 1-Add, 2-Find, 3-Remove, 4-Show, 5-Leave,6-Exit");
                int Opt = Convert.ToInt32(Console.ReadLine());
                switch (Opt)
                {
                    case 1:
                        Console.WriteLine("Enter Student Name : ");
                        string Name = Console.ReadLine();
                        Console.WriteLine("Enter Student City : ");
                        string City = Console.ReadLine();
                        Student s = new Student(Name, City);
                        c.AddStudent(s);
                        Console.WriteLine("Student Added : " + s.PStudentID);
                        break;

                    case 2:
                        Console.WriteLine("Enter Student ID: ");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PStudentID + " " + obj.PStudentName);
                        }
                        else
                        {
                            Console.WriteLine("Student Not Found");
                        }
                        break;


                    case 3:
                        Console.WriteLine("Enter Student ID:");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(SID);
                        if(status)
                        {
                            Console.WriteLine(" Student  is removed successfully");
                        }
                        else
                        {
                            Console.WriteLine("Student is Not Found");
                        }
                        break;

                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        Console.WriteLine("Enter Student ID:");
                        int StID = Convert.ToInt32(Console.ReadLine());
                        Student obj3 = c.Find(StID);
                        Console.WriteLine("Enter the Reason for Leave");
                        string r = Console.ReadLine();
                        obj3.TakeLeave(r);
                        break;

                    case 6:
                        flag = false;
                        break;

                         






                }
            }
        }
    }
}
