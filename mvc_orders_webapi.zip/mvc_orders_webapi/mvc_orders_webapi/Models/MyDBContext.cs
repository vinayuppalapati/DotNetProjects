﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace mvc_orders_webapi.Models
{
    public class MyDBContext:DbContext
    {
       public MyDBContext():base("constr"){}
         
        public DbSet<OrderModel> Orders { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderModel>().MapToStoredProcedures();
        }
    }
    }
