﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;


namespace mvc_orders_webapi.Models
{
    public class OrderModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderID { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string CustomerEmailID { get; set; }
        [Required]
        public string ItemName { get; set; }
        [Required]
        public int ItemQuantity { get; set; }

        
    }
}