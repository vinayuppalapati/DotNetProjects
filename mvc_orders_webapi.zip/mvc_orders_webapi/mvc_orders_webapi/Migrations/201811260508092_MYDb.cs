namespace mvc_orders_webapi.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MYDb : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.OrderModels",
                c => new
                    {
                        OrderID = c.Int(nullable: false, identity: true),
                        CustomerEmailID = c.String(nullable: false),
                        ItemName = c.String(nullable: false),
                        ItemQuantity = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.OrderID);
            
            CreateStoredProcedure(
                "dbo.OrderModel_Insert",
                p => new
                    {
                        CustomerEmailID = p.String(),
                        ItemName = p.String(),
                        ItemQuantity = p.Int(),
                    },
                body:
                    @"INSERT [dbo].[OrderModels]([CustomerEmailID], [ItemName], [ItemQuantity])
                      VALUES (@CustomerEmailID, @ItemName, @ItemQuantity)
                      
                      DECLARE @OrderID int
                      SELECT @OrderID = [OrderID]
                      FROM [dbo].[OrderModels]
                      WHERE @@ROWCOUNT > 0 AND [OrderID] = scope_identity()
                      
                      SELECT t0.[OrderID]
                      FROM [dbo].[OrderModels] AS t0
                      WHERE @@ROWCOUNT > 0 AND t0.[OrderID] = @OrderID"
            );
            
            CreateStoredProcedure(
                "dbo.OrderModel_Update",
                p => new
                    {
                        OrderID = p.Int(),
                        CustomerEmailID = p.String(),
                        ItemName = p.String(),
                        ItemQuantity = p.Int(),
                    },
                body:
                    @"UPDATE [dbo].[OrderModels]
                      SET [CustomerEmailID] = @CustomerEmailID, [ItemName] = @ItemName, [ItemQuantity] = @ItemQuantity
                      WHERE ([OrderID] = @OrderID)"
            );
            
            CreateStoredProcedure(
                "dbo.OrderModel_Delete",
                p => new
                    {
                        OrderID = p.Int(),
                    },
                body:
                    @"DELETE [dbo].[OrderModels]
                      WHERE ([OrderID] = @OrderID)"
            );
            
        }
        
        public override void Down()
        {
            DropStoredProcedure("dbo.OrderModel_Delete");
            DropStoredProcedure("dbo.OrderModel_Update");
            DropStoredProcedure("dbo.OrderModel_Insert");
            DropTable("dbo.OrderModels");
        }
    }
}
