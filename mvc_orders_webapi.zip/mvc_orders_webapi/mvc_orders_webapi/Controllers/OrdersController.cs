﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using mvc_orders_webapi.Models;

namespace mvc_orders_webapi.Controllers
{
    public class OrdersController : ApiController
    {
        // GET: api/Orders
        public IEnumerable<OrderModel> Get()
        {
            MyDBContext db = new MyDBContext();
            var data = db.Orders.ToList();
            return data;
        }

        // GET: api/Orders/5
        public OrderModel Get(int id)
        {
            MyDBContext db = new MyDBContext();
            var model = db.Orders.FirstOrDefault(c => c.OrderID == id);
            return model;
        }
        [HttpGet]

        [Route("api/Search/{key}")]

        public IEnumerable<OrderModel> Search(string key)
        {
            MyDBContext db = new MyDBContext();
            var data = db.Orders.Where(c => c.ItemName.Contains(key) || c.CustomerEmailID.Contains(key)).ToList();
            return data;
        }

        // POST: api/Orders
        public int Post([FromBody]OrderModel value)
        {
            MyDBContext db = new MyDBContext();
            db.Orders.Add(value);
            db.SaveChanges();
            return value.OrderID;
          
        }

        // PUT: api/Orders/5
        public void Put(int id, [FromBody]OrderModel value)
        {
            MyDBContext db = new MyDBContext();
            var dbmodel = db.Orders.FirstOrDefault(c => c.OrderID == id);
            dbmodel.ItemName = value.ItemName;
            dbmodel.ItemQuantity = value.ItemQuantity;
            dbmodel.CustomerEmailID = value.CustomerEmailID;
            db.SaveChanges();
        }

        // DELETE: api/Orders/5
        public void Delete(int id)
        {
            MyDBContext db = new MyDBContext();
            var model = db.Orders.FirstOrDefault(c => c.OrderID == id);
            db.Orders.Remove(model);
            db.SaveChanges();
        }
    }
}
