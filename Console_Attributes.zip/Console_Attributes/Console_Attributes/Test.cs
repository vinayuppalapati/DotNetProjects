﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Attributes
{
    [Developer("1001", "John")]
    class Test
    {
        [Obsolete("Not in use, use xyz")]
        [Developer("1002","David")]
        public void call()
        {
            Console.WriteLine("Call function called");
        }

        [Developer("1003","Vinay")]

        public void Call1()
        {
            Console.WriteLine("Call1 function called");
        }
    }
}
