create database BankingDB

use BankingDB

create table tbl_Customers(CustomerID int identity(100,1) primary key,
CustomerName varchar(100) not null,CustomerEmail varchar(100) not null,
CustomerMobile varchar(20) not null,CustomerGender varchar(10) not null,
CustomerPassword varchar(100) not null)

select * from tbl_Customers


create table tbl_Accounts(AccountID int identity(1000,1) primary key,
CustomerID int foreign key references tbl_Customers(CustomerID),
AccountBalance int not null,AccountType varchar(20) not null,
AccountOpeningDate datetime)

select * from tbl_Accounts

create table tbl_transactions(TransactionID int identity(10000,1) primary key,
AccountID int foreign key references tbl_Accounts(AccountID),
Amount int not null,Transtype varchar(20) not null,TransDate datetime)

select * from tbl_transactions

create proc add_customer(@name varchar(100),@email varchar(100),
@mobileno varchar(100),@gender varchar(20),@password varchar(100))
as
insert tbl_Customers values(@name,@email,@mobileno,@gender,@password)
return @@identity

exec add_customer 'vinay','sdas@fhf.com','45678','male','123456'

create proc add_account(@cid int,@balance int,@actype varchar(20))
as
insert tbl_Accounts values(@cid,@balance,@actype,GETDATE())
return @@identity

exec add_account 100,543,'savings'

create proc show_account(@cid int)
as
select * from tbl_Accounts where CustomerID=@cid

exec show_account 100

create proc		(@aid int,@amt int,@transtype varchar(100))
as
insert tbl_transactions values(@aid,@amt,@transtype,GETDATE())
return @@identity

exec add_transaction 1000,50,'withdraw'
exec add_transaction 1000,100,'Deposit'


create proc show_transactions(@aid int)
as
select * from tbl_transactions where AccountID=@aid


create proc customer_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Customers where CustomerID=@id and CustomerPassword=@password
return @count

 create proc accountbalance(@id int)
 as
 declare @bal int
 select @bal=AccountBalance from tbl_Accounts where AccountID=@id
 return @bal

 exec accountbalance 1002 
 
sp_help tbl_transactions

create trigger Account_balance
on tbl_transactions
for insert
as
begin
declare @aid int
declare @amt int
declare @type varchar(20)
select @aid=AccountID,@amt=Amount,@type=Transtype from inserted
if(@type='withdraw')
begin
update tbl_Accounts set AccountBalance=AccountBalance-@amt where AccountID=@aid
end
if(@type='Deposit')
begin
update tbl_Accounts set AccountBalance=AccountBalance+@amt where AccountID=@aid
end
end
