﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_MiniProject
{
    class Transaction
    {
        public int TransactionID { get; set; }

        public int AccountID { get; set; }

        public int Amount { get; set; }

        public string Transtype { get; set; }
        public DateTime TransDate { get; set; }
    }
}
