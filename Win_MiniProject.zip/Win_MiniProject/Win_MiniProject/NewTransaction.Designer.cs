﻿namespace Win_MiniProject
{
    partial class NewTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.lbl_transactiontype = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.cb_transactiontype = new System.Windows.Forms.ComboBox();
            this.btn_makepayment = new System.Windows.Forms.Button();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountid.Location = new System.Drawing.Point(111, 51);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(108, 25);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "Account ID";
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.Location = new System.Drawing.Point(111, 102);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(80, 25);
            this.lbl_Amount.TabIndex = 1;
            this.lbl_Amount.Text = "Amount";
            // 
            // lbl_transactiontype
            // 
            this.lbl_transactiontype.AutoSize = true;
            this.lbl_transactiontype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transactiontype.Location = new System.Drawing.Point(114, 158);
            this.lbl_transactiontype.Name = "lbl_transactiontype";
            this.lbl_transactiontype.Size = new System.Drawing.Size(165, 25);
            this.lbl_transactiontype.TabIndex = 2;
            this.lbl_transactiontype.Text = "Transaction Type";
            // 
            // txt_amount
            // 
            this.txt_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_amount.Location = new System.Drawing.Point(296, 97);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(149, 30);
            this.txt_amount.TabIndex = 4;
            // 
            // cb_transactiontype
            // 
            this.cb_transactiontype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_transactiontype.FormattingEnabled = true;
            this.cb_transactiontype.Location = new System.Drawing.Point(296, 150);
            this.cb_transactiontype.Name = "cb_transactiontype";
            this.cb_transactiontype.Size = new System.Drawing.Size(149, 33);
            this.cb_transactiontype.TabIndex = 5;
            // 
            // btn_makepayment
            // 
            this.btn_makepayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_makepayment.Location = new System.Drawing.Point(213, 243);
            this.btn_makepayment.Name = "btn_makepayment";
            this.btn_makepayment.Size = new System.Drawing.Size(186, 61);
            this.btn_makepayment.TabIndex = 6;
            this.btn_makepayment.Text = "Make Payment";
            this.btn_makepayment.UseVisualStyleBackColor = true;
            this.btn_makepayment.Click += new System.EventHandler(this.btn_makepayment_Click);
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(296, 51);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(149, 33);
            this.cmb_accountid.TabIndex = 7;
            this.cmb_accountid.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // NewTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 472);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.btn_makepayment);
            this.Controls.Add(this.cb_transactiontype);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.lbl_transactiontype);
            this.Controls.Add(this.lbl_Amount);
            this.Controls.Add(this.lbl_accountid);
            this.Name = "NewTransaction";
            this.Text = "NewTransaction";
            this.Load += new System.EventHandler(this.NewTransaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Label lbl_transactiontype;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.ComboBox cb_transactiontype;
        private System.Windows.Forms.Button btn_makepayment;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}