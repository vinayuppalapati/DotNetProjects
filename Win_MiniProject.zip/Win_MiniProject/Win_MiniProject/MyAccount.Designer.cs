﻿namespace Win_MiniProject
{
    partial class MyAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_showaccounts = new System.Windows.Forms.DataGridView();
            this.btn_showaccounts = new System.Windows.Forms.Button();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showaccounts)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_showaccounts
            // 
            this.dgv_showaccounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showaccounts.Location = new System.Drawing.Point(54, 178);
            this.dgv_showaccounts.Name = "dgv_showaccounts";
            this.dgv_showaccounts.Size = new System.Drawing.Size(581, 183);
            this.dgv_showaccounts.TabIndex = 0;
            // 
            // btn_showaccounts
            // 
            this.btn_showaccounts.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showaccounts.Location = new System.Drawing.Point(218, 113);
            this.btn_showaccounts.Name = "btn_showaccounts";
            this.btn_showaccounts.Size = new System.Drawing.Size(184, 45);
            this.btn_showaccounts.TabIndex = 1;
            this.btn_showaccounts.Text = "Show Accounts";
            this.btn_showaccounts.UseVisualStyleBackColor = true;
            this.btn_showaccounts.Click += new System.EventHandler(this.btn_showaccounts_Click);
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(76, 45);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(116, 25);
            this.lbl_customerid.TabIndex = 2;
            this.lbl_customerid.Text = "CustomerID";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(263, 42);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(190, 30);
            this.txt_customerid.TabIndex = 3;
            // 
            // MyAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 414);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.btn_showaccounts);
            this.Controls.Add(this.dgv_showaccounts);
            this.Name = "MyAccount";
            this.Text = "MyAccount";
            this.Load += new System.EventHandler(this.MyAccount_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showaccounts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_showaccounts;
        private System.Windows.Forms.Button btn_showaccounts;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customerid;
    }
}