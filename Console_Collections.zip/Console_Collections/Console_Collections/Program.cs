﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            list.Add(1000);
            list.Add(2000);
            list.Add(3000);
            Customer c = new Customer();
            int x = 4000;
            list.Add(x);
            list.Add(c);
           // list.Add("ABC");

           // int x1 = Convert.ToInt32(list[0]);
            //string s1 = list[4].ToString();

            foreach(int t in list)
            {
                Console.WriteLine(t);
            }
           
            Console.WriteLine(list.Count);
            list.Remove(1000);
            list.RemoveAt(0);
            Console.WriteLine(list.Count);

          
            Console.ReadLine();

        }
    }
}
