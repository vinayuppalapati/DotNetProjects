﻿using System.Web;
using System.Web.Mvc;

namespace Day22_11_Mvc_Employees_Model
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
