﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Day22_11_Mvc_Employees_Model.Models;

namespace Day22_11_Mvc_Employees_Model.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: Employees
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.addEmployee(model);
                ViewBag.msg = "Employee ID is :" + id;
            }
            return View();
        }
        public ActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Search(string key)
        {
            EmployeeDAL dal = new EmployeeDAL();
            List<EmployeeModel> list = dal.SearchEmployees(key);
            return View(list);
        }
        public ActionResult Details(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            EmployeeModel model = dal.FindEmployee(id);
            return View(model);
        }
        public ActionResult Delete(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            dal.deleteemployee(id);
            return View();
        }
        public ActionResult Edit(int id)
        {
            EmployeeDAL dal = new EmployeeDAL();
            EmployeeModel model = dal.FindEmployee(id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(EmployeeModel model)
        {
            EmployeeDAL dal = new EmployeeDAL();
            dal.updateemployee(model.EmployeeID, model.EmployeeName, model.EmployeeCity);
            return View("EmployeeUpdated");
        }

    }
}