﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Day22_11_Mvc_Employees_Model.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addEmployee(EmployeeModel model)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_addemployee", con);
                com_add.Parameters.AddWithValue("@name", model.EmployeeName);
                com_add.Parameters.AddWithValue("@city", model.EmployeeCity);
                com_add.Parameters.AddWithValue("@email", model.EmployeeEmail);
                com_add.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_add.Parameters.Add(retdata);
                com_add.ExecuteNonQuery();
                int id = Convert.ToInt32(retdata.Value);
                con.Close();
                if (id != 0)
                {
                    return id;
                }
                else
                {
                    return id;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public List<EmployeeModel> SearchEmployees(string key)
        {
            try
            {

            SqlCommand com_search = new SqlCommand("proc_searchemployee", con);
            com_search.Parameters.AddWithValue("@key", key);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader rd = com_search.ExecuteReader();
            List<EmployeeModel> list = new List<EmployeeModel>();
            while (rd.Read())
            {
                EmployeeModel m = new EmployeeModel();
                m.EmployeeID = rd.GetInt32(0);
                m.EmployeeName = rd.GetString(1);
                m.EmployeeCity = rd.GetString(2);
                m.EmployeeEmail = rd.GetString(3);
                list.Add(m);

            }
                con.Close();
            if (rd != null)
            {
                return list;
            }
            else
            {
                return null;
            }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        public EmployeeModel FindEmployee(int id)
        {
            try
            {

            SqlCommand com_find = new SqlCommand("proc_findemployee", con);
            com_find.Parameters.AddWithValue("@id", id);
            com_find.CommandType = CommandType.StoredProcedure;
            con.Open();
                SqlDataReader rd = com_find.ExecuteReader();
                EmployeeModel e = new EmployeeModel();
                if (rd.Read())
                {
                    e.EmployeeID = rd.GetInt32(0);
                    e.EmployeeName = rd.GetString(1);
                    e.EmployeeCity = rd.GetString(2);
                    e.EmployeeEmail = rd.GetString(3);

                }
                con.Close();
                if (e != null)
                {
                    return e;
                }
                else
                {
                    return e;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }  

        public bool updateemployee(int @id,string name,string city)
        {
            try
            { 
            SqlCommand com_update = new SqlCommand("proc_updateemployee", con);
            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@name", name);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(retdata);
                com_update.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool deleteemployee(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deleteemployee", con);
                com_delete.Parameters.AddWithValue("@id", id);
                com_delete.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(retdata);
                com_delete.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


    }
}