﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Day22_11_Mvc_Employees_Model.Models
{
    public class EmployeeModel
    {
      // [Display(Name ="Employee ID :")]

        public int EmployeeID { get; set; }
        [Display(Name ="Employee Name :")]
        [Required(ErrorMessage ="*")]
        [StringLength(100,MinimumLength =5,ErrorMessage ="Invalid Format")]
        public string EmployeeName { get; set; }

        [Display(Name ="Employee City :")]
        [Required(ErrorMessage ="*")]

        public string EmployeeCity { get; set; }
        [Display(Name ="Employee EmailID:")]
        [Required(ErrorMessage ="*")]
        [EmailAddress(ErrorMessage ="Invalid Format")]
        public string EmployeeEmail { get; set; }
    }
}