use mvcdb

create table tbl_employees(EmployeeID int identity(200,1) primary key,
EmployeeName varchar(100) not null,EmployeeCity varchar(100) not null,
EmployeeEmail varchar(100) not null)

--drop table tbl_employees

create proc proc_addemployee(@name varchar(100),@city varchar(100),@email varchar(100))
as
insert tbl_employees values(@name,@city,@email)
return @@identity

create proc proc_searchemployee(@key varchar(100))
as
select * from tbl_employees  where EmployeeID like '%'+@key+'%' or EmployeeName like '%'+@key+'%' or EmployeeEmail like '%'+@key+'%'

create proc proc_findemployee(@id int)
as
select * from tbl_employees where EmployeeID=@id

create proc proc_updateemployee(@id int ,@name varchar(100),@city varchar(100))
as
update tbl_employees  set EmployeeName=@name,EmployeeCity=@city where EmployeeID=@id
return @@rowcount

create proc proc_deleteemployee(@id int)
as
delete tbl_employees  where EmployeeID=@id
return @@rowcount

select * from tbl_employees