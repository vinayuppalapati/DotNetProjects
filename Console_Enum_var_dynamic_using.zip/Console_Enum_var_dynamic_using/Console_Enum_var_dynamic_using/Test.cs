﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Enum_var_dynamic_using;


namespace Console_Enum_var_dynamic_using1
{
    class Test
    {
        public void MakePayment(PaymentType p)
        {
            if (p == PaymentType.Card)
            {
                Console.WriteLine(p);
            }
        }
        public static void call()
        {


        }

    }
}
