﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order_2
{
    class Order
    {
        private int OrderId;
        private static int count=100;
        private int ItemPrice;
        private string ItemName;
        private int Quantity;
        private string CustomerName;

        public Order(string CustomerName,string ItemName,int ItemPrice,int Quantity)
        {
            Order.count++;
            this.OrderId = Order.count;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.Quantity = Quantity;
            this.CustomerName = CustomerName;
        }
        //static Order()
        //{
        //    Order.count++;

        //}
       public int POrderID
        {
            get
            {
                return this.OrderId;
            }
            
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
            set
            {
                this.ItemPrice = value;
            }
        }



        public int PQuantity
        {
            get
            {
                return this.Quantity;
            }
            set
            {
                this.Quantity = value;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
            set
            {
                this.CustomerName = value;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
            set
            {
                this.ItemName = value;
            }
        }

        public int GetOrderAmount()
        {
            return this.ItemPrice * this.Quantity;
        }
        public string GetDetails()
        {
            return this.OrderId + " " + this.CustomerName + " " + this.ItemName + "  " + ItemPrice;
        }
    }
}
