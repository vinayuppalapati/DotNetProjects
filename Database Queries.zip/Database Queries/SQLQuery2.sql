create database Emp_DB

create table Employees(EmployeeID int,EmployeeFName varchar(10),
EmployeeLName varchar(10),EmployeeCity varchar(10),
EmployeeDOB date,EmployeeSalary int,Employeestatus varchar(10))

sp_help Employees

alter table Employees add EmployeeDept varchar(10),EmployeeDOJ date

insert Employees values(101,'vinay','kumar','vijayawada','11-18-1996',20000,'working','Technical','11-05-2018')

select * from Employees

insert Employees values(102,'ramesh','kumar','guntur','11-20-1987',25000,'working','Finance','07-05-2018')

insert Employees values(103,'lalitha','sai','gudiwada','06-19-1996',50000,'working','Technical','11-01-2018')
insert Employees values(104,'rahul','varma','hyderabad','02-28-1993',28000,'resign','Technical','05-13-2017')

insert Employees values(105,'rajesh','rao','vijayawada','02-18-1989',29000,'working','Sales','01-05-2016')
insert Employees values(106,'gopi','obulusetty','tenali','09-21-1996',10000,'resign','Architect','05-30-2017')
insert Employees values(107,'raju','abc','Hyderabad','05-03-1986',32000,'working','Technical','06-17-2016')

insert Employees values(108,'ram','sandeep','guntur','04-09-1997',25000,'working','Technical','01-05-2019')
insert Employees values(109,'sumanth','reddy','vizag','09-27-1994',25460,'resign','Finance','05-26-2015')
insert Employees values(110,'dinesh','sai','tenali','10-30-1993',35000,'working','HR','04-10-2018')

insert Employees values(111,'boopathi','raja','chennai','10-30-1986',45000,'working','Trainer','12-10-2014')

select * from Employees where EmployeeCity='chennai'
--5

select * from Employees where EmployeeSalary between 26000 and 50000 
--6

select CONCAT(EmployeeFName,EmployeeLName) As 'FullName',EmployeeID,EmployeeCity from Employees

--7

select * from Employees order by len(EmployeeFName) asc
--8

select sum(Employeesalary) from Employees
--9

select count(*) from Employees
--10

select * from Employees where DATEPART(mm,EmployeeDOJ)=1
--11
select * from Employees where DATEDIFF(yy,Employeedoj,getdate())>1
--12

select Count(*),EmployeeDept from Employees group by EmployeeDept
--13
select Count(*),EmployeeCity from Employees group by EmployeeCity
--14

update Employees set EmployeeCity='Pune' where EmployeeCity='chennai'
--15
select * from Employees

select SUM(EmployeeSalary),EmployeeDept from Employees group by EmployeeDept having SUM(EmployeeSalary)>50000
--16

Select EmployeeFName,CAST(employeesalary as decimal(12,4)) from Employees
--17

update Employees set Employeestatus='resign' where EmployeeCity='guntur'

--20

select * from Employees where DATEPART(mm,EmployeeDOJ)=11

--21









