create database EmployeesManagementDB
drop table tbl_employees
create table tbl_employees(EmployeeId int identity(10,1) primary key,Employeecity varchar(15),
EmployeeSalary int,EmployeeDOB date,EmployeeDOJ date,
EmployeeMobileNo varchar(10),EmployeeEmailID varchar(20),
EmployeePassword varchar(15),EmployeeDept varchar(10))

insert tbl_employees values(

create proc LoginCheck(@id int ,@pass varchar(20))
   as
   declare @count int;
   select @count = count(*) from tbl_CustomerInfo where CustomerID =@id and CustomerPassword=@pass;
   if(@count=1)
   begin
   return 1;
   end
   else
   begin 
   return 0;
   end

   declare @a int
exec  @a=LoginCheck 101,'ADASD@123';
select @a;
	  select * from tbl_CustomerInfo