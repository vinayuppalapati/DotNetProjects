declare @count int =0;
set @count =100;
select @count=count(*) from tbl_Employees;

if (@count>0)
begin
--insert
end

else
begin
--Update
end

select @count;


declare @count int=0
while(@count<10)
begin
select @count;
set @count=@count+1
end

alter proc sp_employees
as
select * from tbl_Employees order by EmployeeSalary desc

exec sp_employees


create proc sp_employees_city(@city varchar(100))
as
select * from tbl_Employees where EmployeeCity=@city

exec sp_employees_city 'guntur'


select * from accounts

Create proc sp_add_account(@Name varchar(100),@Balance int)
as
if(@Balance >=100)
begin
insert accounts values(@Name,@Balance)
return @@identity
end
else
begin
return 0
end

exec sp_add_account 'ABCdr',10

declare @r int
exec @r=sp_add_account 'ABCdr',1000
select @r


-------------
create proc sp_account_balance(@AccountID int)
as

declare @balance int 
select @balance= Accountbalance from accounts where AccountId=@AccountID;
return @balance

declare @bal int
exec @bal=sp_account_balance 1000
select @bal

-------------

create proc sp_login(@id int, @password varchar(100))
as
declare @count int
select @count = count(*) from tbl_CustomerInfo 
where CustomerID=@id and CustomerPassword=@password
return @count

select * from tbl_CustomerInfo
declare @c int
exec @c=sp_login 101,'ADASD@123'
select @c

-------------


select * from tbl_Employees

create proc sp_employeedetails(@id int, @name varchar(100) output,@city varchar(100) output)
as
select @name=EmployeeName, @city =EmployeeCity from tbl_Employees where EmployeeID=@id

declare @ename varchar(100)
declare @ecity varchar(100)
exec sp_employeedetails 101,@ename output,@ecity output
select @ename,@ecity

----------------




Create table tbl_Student
(
StudentID int,
StudentName varchar(100),
StudentCity varchar(100),
)

alter trigger trg_add_student
on tbl_student
for insert
as
begin
select * from inserted
select 'Trigger Fired'
end

insert tbl_student values (1,'AS','chennai')

select * from tbl_student

-------------------------------


create table stock
(
ItemID int primary key,
itemqty int
)
insert stock values(2,100)
select * from stock


create table orders(
orderid int,
itemid int not null foreign key references Stock(ItemID),
itemqty int not null,
itemprice int check(itemprice>0)
)

insert orders values(12,2,20,12)
select * from orders


insert orders values(13,2,5,12)
insert orders values(16,2,20,12)



select * from stock



Create Trigger trg_update_stock
on orders
for insert 
as
begin
declare @itemid int
declare @qty int
Select @itemid=itemid, @qty=itemqty from inserted
update stock set itemqty=itemqty-@qty where itemid=@itemid
end


select   * from Stock


------------------------

--views


Select * from tbl_Employees

create view v_Employees_VIJ
as
select * from tbl_Employees where EmployeeCity ='vijayawada'

alter view v_Employees_VIJ
as
select * from tbl_Employees where EmployeeCity ='vijayawada'
with check option
---will insert only with access of particular 
select * from v_Employees_VIJ

sp_help V_Employees_VIJ

alter view v_Employees_VIJ
with encryption
as
select * from tbl_Employees where EmployeeCity ='vijayawada'
with check option

select * from v_Employees_VIJ
insert v_Employees_VIJ values(110,'kumar','vijayawada',232312)
insert v_Employees_VIJ values(103,'sdf','tenali',4322)
 

 alter view v_Employees_VIJ
with encryption,schemabinding
as
select employeeid,EmployeeName,EmployeeSalary,EmployeeCity from dbo.tbl_Employees where EmployeeCity ='vijayawada'
with check option

drop table v_Employee_VIJ





Create table t1
(
Code int,
Name varchar(100)
)
--drop table t2
Create table t2
(
Code int,
City varchar(100)
)
insert t1 values(1,'A')

insert t2 values(1,'BGL')

select * from t1

select * from t2

create view v_data
as
select t1.Code,t1.Name,t2.City from t1 join t2 on t1.Code=t2.Code

select * from v_data

insert v_data values(2,'XYZ','PUNE')

--create trigger trg_view
--on v_data
--for insert
--as
--begin
--declare @code int
--declare @name varchar(100)
--declare @city varchar(100)
--select @code=code, @name=name,@city=city from inserted
--insert t1 values(@code, @name)
--insert t2 values(@code,@city)
--end



create trigger trg_view
on v_data
instead of insert
as
begin
declare @code int
declare @name varchar(100)
declare @city varchar(100)
select @code=code, @name=name,@city=city from inserted
insert t1 values(@code, @name)
insert t2 values(@code,@city)
end



create table tbl_employeesinfo
(
EmployeeId int identity(1,1),
EmployeeName varchar(100),
Employeecity varchar(100)
)

declare @c int=0;
while(@c<50000)
begin
insert tbl_employeesinfo values('ABCD','HYD');
set @c=@c+1;
end

select * from tbl_employeesinfo where EmployeeId=49999

select * from tbl_employeesinfo where EmployeeName='ABCD'


Create clustered index idx
on tbl_employeesinfo(employeeid)

select * from tbl_Employees

begin tran tr1

insert tbl_Employees  values(15,'ABS','BGL',20000)

select * from tbl_Employees

rollback tran

commit tran
