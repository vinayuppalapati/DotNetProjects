select * from Employees

create table accounts(AccountID int identity(1000,1),
CustomerName varchar(50),
AccountBalance int
)

sp_help accounts

insert accounts values('Vinay',234234)

select * from accounts

insert accounts values('Kumar',2000)
insert accounts values('Gopi',1000)
insert accounts values('Dinesh',0)
insert accounts values('Rahul',5000)
insert accounts values('lalitha',10000)
insert accounts values('Sreekar',20000)



