create database BankDB

use  BankDB


create table tbl_CustomerInfo(CustomerID int identity(100,1) primary key,CustomerName varchar(20) not null,
CustomerCity varchar(20) not null,CustomerAddress varchar(50) not null,
CustomerMobileNo varchar(15) unique,PAN varchar(10) unique,CustomerPassword Varchar(15))

insert tbl_CustomerInfo values('vinay','vijayawada','JPN','23423434','ASDSADAS2','ADASD@123')
insert tbl_CustomerInfo values('Rahul','hyderabad','fhsdf','826736784','AHJDSADAS2','ADASD@123')
insert tbl_CustomerInfo values('ram','Guntur','JPN','378246237','JAHSDJ23','ADASD@123')
insert tbl_CustomerInfo values('sandeep','chennai','asdhfjk','9786232342','KLJDSD#C#','ADASD@123')
insert tbl_CustomerInfo values('gopi','tenali','AFSDFE','9623864234','KJHRFEF223','ADASD@123')
insert tbl_CustomerInfo values('dinesh','Guntur','KWEURY','712786283','EYGEW#&23','ADASD@123')
insert tbl_CustomerInfo values('raj','bangalore','BVGHsf','398436437','A334SADAS2','ADASD@123')
insert tbl_CustomerInfo values('sai','hyderabad','jksfb','276472342','AJKSDSG32','ADASD@123')
insert tbl_CustomerInfo values('sumanth','vijayawada','JPN','KGJHSDA23','JKHEUIHDS','ADASD@123')
insert tbl_CustomerInfo values('srikar','hyderabad','NEJF','9823784723','IOEYEREW','ADASD@123')



 --delete tbl_CustomerInfo where CustomerName='ADB'
 
select * from tbl_CustomerInfo

create table tbl_AccountInfo(AccountId int identity(10,1) primary key,
 Customerid int not null foreign key references tbl_CustomerInfo(CustomerId),
 AccountType varchar(10) not null,AccountBalance int not null check(AccountBalance>0),
 AccountOpenDate date not null,
 AccountStatus varchar(10) not null)

 insert tbl_AccountInfo values(100,'savings',3323,GETDATE(),'Open')
 insert tbl_AccountInfo values(100,'current',332833,GETDATE(),'Open')
 insert tbl_AccountInfo values(103,'savings',1000,GETDATE(),'Closed')
 insert tbl_AccountInfo values(103,'current',323323,GETDATE(),'Open')
 insert tbl_AccountInfo values(102,'savings',878,GETDATE(),'Open')
 insert tbl_AccountInfo values(104,'savings',9888,GETDATE(),'Open')
 insert tbl_AccountInfo values(107,'current',73939,GETDATE(),'Open')
 insert tbl_AccountInfo values(108,'current',50000,GETDATE(),'Open')
 insert tbl_AccountInfo values(101,'savings',323,GETDATE(),'Blocked')
 insert tbl_AccountInfo values(105,'savings',3323,GETDATE(),'Blocked')
 insert tbl_AccountInfo values(106,'current',7878,GETDATE(),'Closed')

 update tbl_AccountInfo set AccountOpenDate ='10-01-2017' where AccountId =12
 select * from tbl_AccountInfo
 create table tbl_TransactionInfo(TransactionID int identity(1000,1) primary key,
 AccountId int not null foreign key references tbl_AccountInfo(Accountid),
 TransactionType varchar(10) not null,Amount int not null check(Amount>0),
 TransactionDate date not null)

 insert tbl_TransactionInfo values(12,'Deposit',2000,'02-02-2016')
 insert tbl_TransactionInfo values(11,'Withdraw',1500,'04-02-2016')
insert tbl_TransactionInfo values(10,'Deposit',2200,'06-02-2017')
insert tbl_TransactionInfo values(15,'Withdraw',2560,'06-02-2017')
insert tbl_TransactionInfo values(14,'Withdraw',12000,'07-23-2018')
insert tbl_TransactionInfo values(12,'Withdraw',1800,'10-02-2018')
insert tbl_TransactionInfo values(16,'Deposit',9000,'11-02-2018')
insert tbl_TransactionInfo values(12,'Withdraw',87000,'01-15-2018')
insert tbl_TransactionInfo values(18,'Withdraw',65000,'04-18-2018')
insert tbl_TransactionInfo values(17,'Deposit',45000,'07-12-2018')

select * from tbl_TransactionInfo
 
 select Top 5 * from tbl_TransactionInfo where accountid=12 order by TransactionDate desc
 --1

 select * from tbl_TransactionInfo where  AccountId =12 and TransactionDate
  between '10-02-2016' and '10-02-2018'
  --2

  select * from tbl_AccountInfo where Customerid=100
  --3

  select tbl_CustomerInfo.CustomerID,tbl_CustomerInfo.CustomerName,tbl_CustomerInfo.CustomerAddress,
  tbl_CustomerInfo.CustomerMobileNo,tbl_AccountInfo.AccountId,tbl_AccountInfo.AccountBalance
   from tbl_CustomerInfo join tbl_AccountInfo on tbl_CustomerInfo.CustomerID=tbl_AccountInfo.Customerid

   --4

   select tbl_AccountInfo.AccountId,tbl_AccountInfo.AccountBalance,tbl_TransactionInfo.TransactionID,
   tbl_TransactionInfo.Amount,tbl_TransactionInfo.TransactionType from tbl_AccountInfo join tbl_TransactionInfo
   on tbl_AccountInfo.AccountId=tbl_TransactionInfo.AccountId

   --5

   select tbl_CustomerInfo.CustomerID,tbl_CustomerInfo.CustomerName,tbl_CustomerInfo.CustomerAddress,
   tbl_CustomerInfo.CustomerMobileNo,tbl_AccountInfo.AccountId,tbl_AccountInfo.AccountBalance,
   tbl_TransactionInfo.TransactionID,tbl_TransactionInfo.Amount,tbl_TransactionInfo.TransactionType
   from tbl_CustomerInfo join tbl_AccountInfo
   on tbl_CustomerInfo.CustomerID=tbl_AccountInfo.Customerid 
   join tbl_TransactionInfo
   on tbl_AccountInfo.AccountId=tbl_TransactionInfo.AccountId

   --6


   select * from tbl_CustomerInfo where CustomerID in(select CustomerID from tbl_AccountInfo) 


   --7

   select * from tbl_CustomerInfo where CustomerID not in (select CustomerID from tbl_AccountInfo) 

   --8

   select * from tbl_AccountInfo where AccountID in (select AccountID from tbl_TransactionInfo)

   --9

      select * from tbl_AccountInfo where AccountID not  in (select AccountID from tbl_TransactionInfo)

	  --10

