Create Database pathfrontdb2

use PathfrontDB2

Create table tbl_customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerEmail varchar(100) not null unique,
CustomerMobiledNO varchar(15) not null unique
)

insert tbl_Customers values('Vinay','Vijayawada','vinay@pathfront.in','9232323232')
insert tbl_Customers values('Rahul','hyderabad','rahul@pathfront.in','9544534534')
insert tbl_Customers values('Dinesh','Tenali','dinesh@pathfront.in','9873647836')
insert tbl_Customers values('Sandeep','guntur','sam@pathfront.in','8336363692')
insert tbl_Customers values('sreekar','hyderabad','sreekar@pathfront.in','7394632476')






select * from tbl_customers
---5

Create table tbl_items
(
ItemID int identity(1,1) primary key,
ItemName varchar(100) not null,
ItemPrice int check(ItemPrice>0)
)

insert tbl_items values('Laptop',001)
insert tbl_items values('Pencil',10)
insert tbl_items values('Mobile',10000)
insert tbl_items values('Keyboard',300)
insert tbl_items values('Projector',13000)




select * from tbl_items
select * from tbl_customers
--5


create table tbl_invoices
(
InvoiceID int identity(10000,1) primary key,
CustomerID int not null foreign key references tbl_customers(customerid),
InvoiceCity varchar(100) not null,
InvoiceDate DateTime not null,
InvoiceAddress varchar(100)
)
--5


insert tbl_invoices values(1000,'vijayawada','11-01-2018','JPNAGARBANGALORE')
insert tbl_invoices values(1001,'BGL',GETDATE(),'BTM')
insert tbl_invoices values(1002,'HYD',GETDATE(),'Amerpet')
insert tbl_invoices values(1003,'VZA',GETDATE(),'BTM')
insert tbl_invoices values(1004,'VZA',GETDATE(),'HSR')




select * from tbl_invoices
Create table tbl_invoicesitems
(
InvoiceID int not null foreign key references tbl_invoices(invoiceid),
ItemID int not null foreign key references tbl_items(ItemID),
ItemQty int check(itemqty>0),
ItemPrice int check(itemprice>0)
primary key(invoiceid, itemid)
)
insert tbl_invoicesitems values(10001,2,2,200)
insert tbl_invoicesitems values(10001,4,2,200)
insert tbl_invoicesitems values(10001,6,1,400)
insert tbl_invoicesitems values(10005,5,4,200)
insert tbl_invoicesitems values(10003,7,2,800)
insert tbl_invoicesitems values(10004,4,5,1000)
insert tbl_invoicesitems values(10002,6,5,1200)
insert tbl_invoicesitems values(10005,2,2,500)
insert tbl_invoicesitems values(10003,6,6,2000)
insert tbl_invoicesitems values(10003,5,2,700)

select * from tbl_customers where CustomerID in (
select CustomerID from tbl_invoices
)

-- sub query first inside query will work 

select * from tbl_customers  where CustomerID not in (select CustomerID from tbl_invoices)
--
select * from tbl_items  where ItemID  in (select ItemID  from tbl_invoicesitems)

select * from tbl_items  where ItemID  not in (select ItemID  from tbl_invoicesitems)

select * from tbl_customers where CustomerID in(
select Top 1 CustomerID from tbl_invoices order by Invoicedate desc
)
-- Last Customer who places order last 

select top 1 with ties * from tbl_invoices order by invoicedate desc
--when ties happen in time in same time


create table tbl_employees
(
Employeeid int identity(1,1) primary key,
EmployeeName varchar(100) not null,
EmpployeeSalary int not null,
EmployeeDept varchar(100),
ManagerID int foreign key references tbl_employees(employeeid)
)
update table set column=EmployeeSalary int not null where column=EmpployeeSalary 
insert tbl_employees values('John',25000,'HR',null)
insert tbl_employees values('Rosy',15000,'HR',1)
insert tbl_employees values('ABX',20000,'IT',null)
insert tbl_employees values('XBA',18000,'IT',3)

select * from tbl_employees







--10



-- top 2 salary
select top 1 * from tbl_employees where Employeeid  in (
select top 2 Employeeid from tbl_employees order by EmpployeeSalary desc
) order by EmpployeeSalary asc

select top 1 * from tbl_employees where Employeeid not in (
select top 1 with ties Employeeid from tbl_employees order by EmpployeeSalary desc)
order by EmpployeeSalary  desc

select * from tbl_employees e1 where e1.EmpployeeSalary>
(Select AVG(e2.EmpployeeSalary) from  tbl_employees e2
where e2.EmployeeDept=e1.EmployeeDept)



select * from tbl_customers
select * from tbl_invoices

---join

select tbl_customers.CustomerID,tbl_customers.CustomerName,tbl_invoices.InvoiceID,tbl_invoices.InvoiceDate
 from tbl_customers join tbl_Invoices
 on
 tbl_customers.CustomerID=tbl_invoices.CustomerID 

 select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty from tbl_invoices join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 
 ---2 tables inner join
 
 --where tbl_invoicesitems.ItemQty>2


 select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty,tbl_items.ItemName from tbl_invoices join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 join tbl_items
 on tbl_invoicesitems.ItemID=tbl_items.ItemID

 --- 3 tables inner join

  select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_customers.CustomerName,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty,tbl_items.ItemName from tbl_invoices join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 join tbl_items
 on tbl_invoicesitems.ItemID=tbl_items.ItemID
 join tbl_customers
 on tbl_invoices.CustomerID=tbl_customers.CustomerID

 -- 4 tables inner join 



 select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty from tbl_invoices left outer join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 --left outer join


 select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty from tbl_invoices right outer join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 -- right outer join


 select tbl_invoices.InvoiceID,tbl_invoices.CustomerID,tbl_invoices.InvoiceCity,
 tbl_invoicesitems.ItemID,tbl_invoicesitems.ItemQty from tbl_invoices full join tbl_invoicesitems
 on 
 tbl_invoices.InvoiceID =tbl_invoicesitems.InvoiceID
 --full outer join


 select * from tbl_customers cross join tbl_invoices
--cross join

select e.employeeid, e.employeename, e.empployeesalary, e.managerid, m.employeename
from tbl_employees e join tbl_employees m
on 
e.ManagerID=m.Employeeid

-- self join

select * from tbl_employees e join tbl_employees m
on 
e.ManagerID=m.Employeeid


select e.employeeid, e.employeename, e.empployeesalary, e.managerid, m.employeename
from tbl_employees e left outer join tbl_employees m
on 
e.ManagerID=m.Employeeid
--left outer join







 

