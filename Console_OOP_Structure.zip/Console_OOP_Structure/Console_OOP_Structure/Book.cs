﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Structure
{
    class Book
    {
        private int ID=99;
        private string Name="jfg";

        public Book(int ID, string Name)
        {
            this.ID = ID;
            this.Name = Name;

        }
        public int PID
        {
            get
            {
                return this.ID;
            }
        }
        public string PName
        {
            get
            {
                return this.Name;
            }
            set
            {
                this.Name = value;

            }
        }

    }
}
