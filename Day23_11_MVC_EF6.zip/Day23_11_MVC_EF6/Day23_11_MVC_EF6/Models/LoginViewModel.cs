﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Day23_11_MVC_EF6.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage ="*")]
        [Display(Name ="Login ID :")]
        public int LoginID { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Password :")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}