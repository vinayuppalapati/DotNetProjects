﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Day23_11_MVC_EF6.Models
{
    public class OrderModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderID { get; set; }

        [Required(ErrorMessage ="*")]

        public int CustomerID { get; set; }

        [Required(ErrorMessage = "*")]

        public string ItemName { get; set; }
        [Column("ItemQuantity")]
        [Required(ErrorMessage = "*")]

        public int ItemQty { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime OrderDate { get; set; }
        [NotMapped]
        public int OTP { get; set; }

        [ForeignKey("CustomerID")]
        public CustomerModel Customer { get; set; }

    }
}