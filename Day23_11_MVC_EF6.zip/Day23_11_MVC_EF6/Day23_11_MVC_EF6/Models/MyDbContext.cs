﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Day23_11_MVC_EF6.Models
{
    public class MyDbContext : DbContext
    {
        public MyDbContext() : base("constr") { }

        public DbSet<CustomerModel> Customers { get; set; }
        public DbSet<OrderModel> Orders { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerModel>().MapToStoredProcedures();
            modelBuilder.Entity<OrderModel>().MapToStoredProcedures();
        }
    }
}