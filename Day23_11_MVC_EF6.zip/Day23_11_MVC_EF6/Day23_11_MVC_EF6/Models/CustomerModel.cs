﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Day23_11_MVC_EF6.Models
{
    [Table("tbl_customers")] 
    public class CustomerModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        
        public int CustomerID { get; set; }

        [Required(ErrorMessage ="*")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage ="*")]
        [DataType(DataType.Password)]
        public string CustomerPassword { get; set; }
        [Required(ErrorMessage ="*")]
        [DataType(DataType.EmailAddress)]
        public string CustomerEmailID { get; set; }


        public List<OrderModel> OrdersModel { get; set; }


    }
}