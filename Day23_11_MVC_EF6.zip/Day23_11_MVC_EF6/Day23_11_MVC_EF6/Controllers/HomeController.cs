﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Day23_11_MVC_EF6.Models;
using System.Threading.Tasks;

namespace Day23_11_MVC_EF6.Controllers
{
    public class HomeController : Controller
    {
        
        // GET: Home
       

        public ActionResult AddCustomer()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> AddCustomer(CustomerModel model)
        {
            MyDbContext db = new MyDbContext();
            db.Customers.Add(model);
            var t = db.SaveChangesAsync();
            await t;
            db.SaveChanges();
            ViewBag.msg = "Customer ID : " + model.CustomerID;

            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            MyDbContext db = new MyDbContext();
            var count = db.Customers.Count(c => c.CustomerID == model.LoginID && c.CustomerPassword == model.Password);
            if (count > 0)
            {
                Session["LoginID"] = model.LoginID;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid Id or Password";
                return View();
            }

        }
        public ActionResult Index()
        {
            if (Session["LoginID"] != null)
            {
                ViewBag.msg = "LoginID :" + Session["LoginID"];
            }
            return View();
        }

        public ActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Search(string key)
        {
            if (key != string.Empty ) {
            MyDbContext db = new MyDbContext();
            var data = db.Customers.Where(c =>c.CustomerName.Contains(key) || c.CustomerEmailID.Contains(key) || c.CustomerID.ToString().Contains(key)).ToList();

            return View(data);
            }
            return View();
        }
        public ActionResult Details(int id)
        {
            MyDbContext db = new MyDbContext();
            var model = db.Customers.FirstOrDefault(c => c.CustomerID == id);
            return View(model);
        }
        public ActionResult Delete(int id)
        {
            MyDbContext db = new MyDbContext();
            var model = db.Customers.FirstOrDefault(c => c.CustomerID == id);
            db.Customers.Remove(model);
            db.SaveChanges();
            return View();
        }
        public ActionResult Edit(int id)
        {
            MyDbContext db = new MyDbContext();
            var model = db.Customers.FirstOrDefault(c => c.CustomerID == id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(CustomerModel model)
        {
            MyDbContext db = new MyDbContext();
            var dbmodel = db.Customers.FirstOrDefault(c => c.CustomerID == model.CustomerID);
            dbmodel.CustomerEmailID = model.CustomerEmailID;
            dbmodel.CustomerName = model.CustomerName;
            db.SaveChanges();
            return View("CustomerUpdatedView");
        }
    }
}