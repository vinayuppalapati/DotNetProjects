namespace Day23_11_MVC_EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DBfile : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tbl_customers",
                c => new
                    {
                        CustomerID = c.Int(nullable: false, identity: true),
                        CustomerName = c.String(nullable: false),
                        CustomerPassword = c.String(nullable: false),
                        CustomerEmailID = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.CustomerID);
            
            CreateTable(
                "dbo.OrderModels",
                c => new
                    {
                        OrderID = c.Int(nullable: false, identity: true),
                        CustomerID = c.Int(nullable: false),
                        ItemName = c.String(nullable: false),
                        ItemQuantity = c.Int(nullable: false),
                        OrderDate = c.DateTime(nullable: false,defaultValueSql:"getdate()"),
                    })
                .PrimaryKey(t => t.OrderID)
                .ForeignKey("dbo.tbl_customers", t => t.CustomerID, cascadeDelete: true)
                .Index(t => t.CustomerID);
            
            CreateStoredProcedure(
                "dbo.CustomerModel_Insert",
                p => new
                    {
                        CustomerName = p.String(),
                        CustomerPassword = p.String(),
                        CustomerEmailID = p.String(),
                    },
                body:
                    @"INSERT [dbo].[tbl_customers]([CustomerName], [CustomerPassword], [CustomerEmailID])
                      VALUES (@CustomerName, @CustomerPassword, @CustomerEmailID)
                      
                      DECLARE @CustomerID int
                      SELECT @CustomerID = [CustomerID]
                      FROM [dbo].[tbl_customers]
                      WHERE @@ROWCOUNT > 0 AND [CustomerID] = scope_identity()
                      
                      SELECT t0.[CustomerID]
                      FROM [dbo].[tbl_customers] AS t0
                      WHERE @@ROWCOUNT > 0 AND t0.[CustomerID] = @CustomerID"
            );
            
            CreateStoredProcedure(
                "dbo.CustomerModel_Update",
                p => new
                    {
                        CustomerID = p.Int(),
                        CustomerName = p.String(),
                        CustomerPassword = p.String(),
                        CustomerEmailID = p.String(),
                    },
                body:
                    @"UPDATE [dbo].[tbl_customers]
                      SET [CustomerName] = @CustomerName, [CustomerPassword] = @CustomerPassword, [CustomerEmailID] = @CustomerEmailID
                      WHERE ([CustomerID] = @CustomerID)"
            );
            
            CreateStoredProcedure(
                "dbo.CustomerModel_Delete",
                p => new
                    {
                        CustomerID = p.Int(),
                    },
                body:
                    @"DELETE [dbo].[tbl_customers]
                      WHERE ([CustomerID] = @CustomerID)"
            );
            
            CreateStoredProcedure(
                "dbo.OrderModel_Insert",
                p => new
                    {
                        CustomerID = p.Int(),
                        ItemName = p.String(),
                        ItemQuantity = p.Int(),
                    },
                body:
                    @"INSERT [dbo].[OrderModels]([CustomerID], [ItemName], [ItemQuantity])
                      VALUES (@CustomerID, @ItemName, @ItemQuantity)
                      
                      DECLARE @OrderID int
                      SELECT @OrderID = [OrderID]
                      FROM [dbo].[OrderModels]
                      WHERE @@ROWCOUNT > 0 AND [OrderID] = scope_identity()
                      
                      SELECT t0.[OrderID], t0.[OrderDate]
                      FROM [dbo].[OrderModels] AS t0
                      WHERE @@ROWCOUNT > 0 AND t0.[OrderID] = @OrderID"
            );
            
            CreateStoredProcedure(
                "dbo.OrderModel_Update",
                p => new
                    {
                        OrderID = p.Int(),
                        CustomerID = p.Int(),
                        ItemName = p.String(),
                        ItemQuantity = p.Int(),
                    },
                body:
                    @"UPDATE [dbo].[OrderModels]
                      SET [CustomerID] = @CustomerID, [ItemName] = @ItemName, [ItemQuantity] = @ItemQuantity
                      WHERE ([OrderID] = @OrderID)
                      
                      SELECT t0.[OrderDate]
                      FROM [dbo].[OrderModels] AS t0
                      WHERE @@ROWCOUNT > 0 AND t0.[OrderID] = @OrderID"
            );
            
            CreateStoredProcedure(
                "dbo.OrderModel_Delete",
                p => new
                    {
                        OrderID = p.Int(),
                    },
                body:
                    @"DELETE [dbo].[OrderModels]
                      WHERE ([OrderID] = @OrderID)"
            );
            
        }
        
        public override void Down()
        {
            DropStoredProcedure("dbo.OrderModel_Delete");
            DropStoredProcedure("dbo.OrderModel_Update");
            DropStoredProcedure("dbo.OrderModel_Insert");
            DropStoredProcedure("dbo.CustomerModel_Delete");
            DropStoredProcedure("dbo.CustomerModel_Update");
            DropStoredProcedure("dbo.CustomerModel_Insert");
            DropForeignKey("dbo.OrderModels", "CustomerID", "dbo.tbl_customers");
            DropIndex("dbo.OrderModels", new[] { "CustomerID" });
            DropTable("dbo.OrderModels");
            DropTable("dbo.tbl_customers");
        }
    }
}
