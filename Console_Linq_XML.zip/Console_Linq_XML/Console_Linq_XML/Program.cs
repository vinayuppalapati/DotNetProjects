﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_Linq_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("Orders",
    new XElement("Order", new XElement("OrderID", "1001"),
                          new XElement("CustomerName", "XYZ"),
                          new XElement("OrderAmt", "20000")),

    new XElement("Order", new XElement("OrderID", "1002"),
                          new XElement("CustomerName", "ABC"),
                          new XElement("OrderAmt", "30000"))

                        );
            orders.Save(@"D:/DotNetProjects/XML/orders.xml");
            Console.WriteLine("XML file created");
                        


            /*
            string url = @"D:\DotNetProjects\Projects\Console_06-11\Console_Linq_XML\Console_Linq_XML\Customers.xml";
            XDocument doc = XDocument.Load(url);

            var data = from x in doc.Descendants("Customer")
                       select new
                       {
                           CID = x.Element("CustomerID").Value,
                           CName = x.Element("CustomerName").Value,
                           CCity = x.Element("CustomerCity").Value
                       };
            foreach(var d in data)
            {
                Console.WriteLine(d.CID + " " + d.CName + " " + d.CCity);
            }
            */



            Console.ReadLine();
        }
    }
}
