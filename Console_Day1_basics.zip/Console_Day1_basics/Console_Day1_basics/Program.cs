﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_basics
{
    class Program
    {
        static void Main(string[] args)
        {

            int i = 100;
            string s = i.ToString();

            int? x=null;
            string str=null;
            x++;

            const int days = 7;
        
            
            if (x == null)
            {
                Console.WriteLine("It is null ");
            }
            else
            {

                x++;
                Console.WriteLine(x);
            }

            Console.WriteLine("Enter Number  1 : ");
            int num1 = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter Number 2 : ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            int total = num1 + num2;

            Console.WriteLine("Total : " + total);

            Console.ReadLine();

        }
    }
}
