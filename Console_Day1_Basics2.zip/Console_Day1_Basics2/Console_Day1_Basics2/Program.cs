﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Basics2
{
    class Program
    {
        static void Main(string[] args)
        {

            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine(flag);
                flag = false;
            }
            int[] nums = new int[5];// int takes 4 bytes
            nums[0] = 10;
            nums[1] = 20;
            nums[2] = 30;
            nums[3] = 40;
            nums[4] = 50;
            for (int c = 0; c < nums.Length; c++)
            {
                nums[c]=Convert.ToInt32(Console.ReadLine());
            }
            for (int c = 0; c < nums.Length; c++)
            {
                Console.WriteLine(nums[c]);
            }
            

            foreach(int n in nums)
            {
                Console.WriteLine(n);
            }



            int x = 0;
           /* while(x<10)
            {
                Console.WriteLine(x);
                x++;
            }
            for(int i = 0; i < 10; i++)
            {

                Console.WriteLine(i);
            }
            */

            int opt = 1;
            opt= Convert.ToInt32(Console.ReadLine());
            switch (opt)
            {
                case 1:
                    Console.WriteLine("One");
                    break;
                case 2:
                    Console.WriteLine("Two");
                    break;
                case 3:
                    Console.WriteLine("Three");
                    break;
                default:
                    Console.WriteLine("Wrong Number");
                    break;

            }


            /*
            Console.WriteLine("Enter Item Name :");
            string itemname = Console.ReadLine();
            Console.WriteLine("Enter item Quantity");
            int qty = Convert.ToInt32(Console.ReadLine());
            if (qty < 1)
            {
                Console.WriteLine("Invalid Quantity");
            }
            else
            {
                Console.WriteLine("Order Placed");

            }*/
            Console.ReadLine();
        }
    }
}
