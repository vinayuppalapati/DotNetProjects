﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("Enter Login Id");
            }
           else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
           else
            {
                string login = txt_loginid.Text;
                string password = txt_password.Text;
                if (login == "vinay@pathfront.com" && password == "password")
                {
                    //Frm_Sum.Show()
                    MessageBox.Show("Succesfully Login");
                    
                    Frm_Sum obj = new Frm_Sum();
                    obj.Show();
                    //Form1 obj1 = new Form1();
                    //obj1.Close();
                }
                else
                {
                    
                    MessageBox.Show("Invalid User and password");
                    
                }
            }
        }

        private void Libl_LoginId_Click(object sender, EventArgs e)
        {

        }
    }
}
