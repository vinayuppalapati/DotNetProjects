﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application1
{
    public partial class Frm_Sum : Form
    {
        public Frm_Sum()
        {
            InitializeComponent();
        }

        private void btn_Sum_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number2");

            }
            else 
            {
                
                MessageBox.Show("The sum of two Numbers is " + (Convert.ToInt32(txt_Number1.Text)+Convert.ToInt32(txt_Number2.Text))) ;
            }
        }
    }
}
