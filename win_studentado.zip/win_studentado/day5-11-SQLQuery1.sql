use PathfrontADO

select * from tbl_students

alter table tbl_students add studentpassword varchar(100)

create proc proc_addstudent(@name varchar, @city varchar(50),@address varchar(50),@email varchar(50),@studentpassword varchar(50))
as 
insert tbl_students values(@name,@city,@address,@email,@studentpassword)
return @@identity

create proc proc_findstudent(@id int)
as
select * from tbl_students where StudentID=@id

create proc proc_showstudents(@city varchar(50))
as
select * from tbl_students where StudentCity=@city

create proc proc_updatestudent(@id int,@city varchar(50),@email varchar(50))
as
update tbl_students set StudentCity=@city,StudentEmailID=@email where StudentID=@id
return @@rowcount

create proc proc_deletestudent(@id int)
as
delete tbl_students where StudentID=@id


create proc proc_loginstudent(@id int,@password varchar(50))
as
declare @Count int
select @Count=count(*) from tbl_students where StudentID=@id and studentpassword=@password
return @Count;




update tbl_students set studentpassword='123456'