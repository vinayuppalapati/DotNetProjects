select * from tbl_customers

Create table tbl_students(StudentID int identity(100,1) primary key,
StudentName varchar(100),StudentCity varchar(100),
StudentAddress varchar(50),StudentEmailID varchar(50))

select * from tbl_students