﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;


namespace win_studentado
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddStudent(Student st)
        {
            SqlCommand com_cus_insert = new SqlCommand("insert tbl_students values(@name,@city,@address,@email)", con);
            com_cus_insert.Parameters.AddWithValue("@name", st.StudentName);
            com_cus_insert.Parameters.AddWithValue("@city", st.StudentCity);
            com_cus_insert.Parameters.AddWithValue("@address", st.StudentAddress);
            com_cus_insert.Parameters.AddWithValue("@email", st.StudentEmailID);
            con.Open();
            com_cus_insert.ExecuteNonQuery();

            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());

            con.Close();
            return ID;
        }
        public Student Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_students where StudentID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();

            if (dr.Read())
            {
                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.StudentAddress = dr.GetString(3);
                s.StudentEmailID = dr.GetString(4);
                return s;
            }
            else
            {
                return null;
            }

        }
        public bool update(int ID, string city, string email)
        {
            SqlCommand com_update = new SqlCommand("update tbl_students set Studentcity=@city,StudentEmailID=@email where StudentID=@id", con);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@email", email);
            com_update.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_students where StudentID=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
