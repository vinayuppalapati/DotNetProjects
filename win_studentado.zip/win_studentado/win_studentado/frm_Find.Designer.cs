﻿namespace win_studentado
{
    partial class frm_Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentCity = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentid = new System.Windows.Forms.Label();
            this.txt_studentid = new System.Windows.Forms.TextBox();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.dg_studentdata = new System.Windows.Forms.DataGridView();
            this.btn_showstudents = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_studentdata)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(420, 108);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(105, 52);
            this.btn_find.TabIndex = 21;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newstudent.Location = new System.Drawing.Point(563, 22);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(147, 47);
            this.btn_newstudent.TabIndex = 19;
            this.btn_newstudent.Text = "New Student";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentemailid.Location = new System.Drawing.Point(192, 228);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(154, 30);
            this.txt_studentemailid.TabIndex = 18;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentaddress.Location = new System.Drawing.Point(192, 173);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(155, 30);
            this.txt_studentaddress.TabIndex = 17;
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentcity.Location = new System.Drawing.Point(192, 130);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(155, 30);
            this.txt_studentcity.TabIndex = 16;
            // 
            // txt_studentname
            // 
            this.txt_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentname.Location = new System.Drawing.Point(192, 85);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(155, 30);
            this.txt_studentname.TabIndex = 15;
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentemailid.Location = new System.Drawing.Point(42, 236);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(79, 25);
            this.lbl_studentemailid.TabIndex = 14;
            this.lbl_studentemailid.Text = "EmailID";
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentaddress.Location = new System.Drawing.Point(42, 181);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(85, 25);
            this.lbl_studentaddress.TabIndex = 13;
            this.lbl_studentaddress.Text = "Address";
            // 
            // lbl_studentCity
            // 
            this.lbl_studentCity.AutoSize = true;
            this.lbl_studentCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentCity.Location = new System.Drawing.Point(42, 130);
            this.lbl_studentCity.Name = "lbl_studentCity";
            this.lbl_studentCity.Size = new System.Drawing.Size(46, 25);
            this.lbl_studentCity.TabIndex = 12;
            this.lbl_studentCity.Text = "City";
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentname.Location = new System.Drawing.Point(39, 85);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(64, 25);
            this.lbl_studentname.TabIndex = 11;
            this.lbl_studentname.Text = "Name";
            // 
            // lbl_studentid
            // 
            this.lbl_studentid.AutoSize = true;
            this.lbl_studentid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentid.Location = new System.Drawing.Point(47, 33);
            this.lbl_studentid.Name = "lbl_studentid";
            this.lbl_studentid.Size = new System.Drawing.Size(31, 25);
            this.lbl_studentid.TabIndex = 22;
            this.lbl_studentid.Text = "ID";
            // 
            // txt_studentid
            // 
            this.txt_studentid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentid.Location = new System.Drawing.Point(192, 33);
            this.txt_studentid.Name = "txt_studentid";
            this.txt_studentid.Size = new System.Drawing.Size(155, 30);
            this.txt_studentid.TabIndex = 23;
            // 
            // btn_Update
            // 
            this.btn_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.Location = new System.Drawing.Point(410, 22);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(105, 52);
            this.btn_Update.TabIndex = 24;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(580, 116);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(105, 52);
            this.btn_delete.TabIndex = 25;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // dg_studentdata
            // 
            this.dg_studentdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_studentdata.Location = new System.Drawing.Point(3, 335);
            this.dg_studentdata.Name = "dg_studentdata";
            this.dg_studentdata.Size = new System.Drawing.Size(707, 208);
            this.dg_studentdata.TabIndex = 26;
            // 
            // btn_showstudents
            // 
            this.btn_showstudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showstudents.Location = new System.Drawing.Point(451, 211);
            this.btn_showstudents.Name = "btn_showstudents";
            this.btn_showstudents.Size = new System.Drawing.Size(201, 47);
            this.btn_showstudents.TabIndex = 27;
            this.btn_showstudents.Text = "Show Students";
            this.btn_showstudents.UseVisualStyleBackColor = true;
            this.btn_showstudents.Click += new System.EventHandler(this.btn_showstudents_Click);
            // 
            // txt_password
            // 
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(198, 283);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(154, 30);
            this.txt_password.TabIndex = 29;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(48, 291);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(98, 25);
            this.lbl_password.TabIndex = 28;
            this.lbl_password.Text = "Password";
            // 
            // frm_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 494);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.btn_showstudents);
            this.Controls.Add(this.dg_studentdata);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.txt_studentid);
            this.Controls.Add(this.lbl_studentid);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentCity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "frm_Find";
            this.Text = "frm_Find";
            ((System.ComponentModel.ISupportInitialize)(this.dg_studentdata)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentCity;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentid;
        private System.Windows.Forms.TextBox txt_studentid;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.DataGridView dg_studentdata;
        private System.Windows.Forms.Button btn_showstudents;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label lbl_password;
    }
}