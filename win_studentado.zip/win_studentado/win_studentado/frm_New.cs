﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_studentado
{
    public partial class frm_New : Form
    {
        public frm_New()
        {
            InitializeComponent();
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            if (txt_studentname.Text == string.Empty)
            {
                MessageBox.Show("Enter Name ");
            }
            else if (txt_studentcity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_studentaddress.Text == string.Empty)
            {
                MessageBox.Show("Enter address");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailID");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                try { 

                Student obj = new Student();
                obj.StudentName = txt_studentname.Text;
                obj.StudentEmailID = txt_studentemailid.Text;
                obj.StudentCity = txt_studentcity.Text;
                obj.StudentAddress = txt_studentaddress.Text;
                obj.StudentPassword = txt_password.Text;

                StudentDAL_proc dal = new StudentDAL_proc();
                int id = dal.AddStudent(obj);
                MessageBox.Show("Student id is : " + id);
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_studentaddress.Text = string.Empty;
            txt_studentcity.Text = string.Empty;
            txt_studentemailid.Text = string.Empty;
            txt_studentname.Text = string.Empty;
            txt_password.Text = string.Empty;
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            frm_Find f1 = new frm_Find();
            f1.Show();
        }

        private void txt_studentemailid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentaddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentcity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentname_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_studentemailid_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentaddress_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentCity_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentname_Click(object sender, EventArgs e)
        {

        }
    }
}
