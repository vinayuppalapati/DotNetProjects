﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Order ID :");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Item Name :");
            string itname = Console.ReadLine();

            Console.WriteLine("Enter Item Price :");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Quantity:");
            int quantity = Convert.ToInt32(Console.ReadLine());


            Order obj = new Order(id,name,itname,price,quantity);
            Console.WriteLine("Order Amount is :"+ obj.GetOrderAmount());

            Console.WriteLine("Order Details  :" +obj.GetDetails());
            Console.ReadLine();
            
        }
    }
}
