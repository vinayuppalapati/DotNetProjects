﻿namespace Win_ado
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addemployee = new System.Windows.Forms.Button();
            this.btn_findemployee = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_addemployee
            // 
            this.btn_addemployee.Location = new System.Drawing.Point(99, 114);
            this.btn_addemployee.Name = "btn_addemployee";
            this.btn_addemployee.Size = new System.Drawing.Size(136, 65);
            this.btn_addemployee.TabIndex = 0;
            this.btn_addemployee.Text = "Add Employee";
            this.btn_addemployee.UseVisualStyleBackColor = true;
            this.btn_addemployee.Click += new System.EventHandler(this.btn_addemployee_Click);
            // 
            // btn_findemployee
            // 
            this.btn_findemployee.Location = new System.Drawing.Point(344, 114);
            this.btn_findemployee.Name = "btn_findemployee";
            this.btn_findemployee.Size = new System.Drawing.Size(149, 65);
            this.btn_findemployee.TabIndex = 1;
            this.btn_findemployee.Text = "Find Employee";
            this.btn_findemployee.UseVisualStyleBackColor = true;
            this.btn_findemployee.Click += new System.EventHandler(this.btn_findemployee_Click);
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 360);
            this.Controls.Add(this.btn_findemployee);
            this.Controls.Add(this.btn_addemployee);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_addemployee;
        private System.Windows.Forms.Button btn_findemployee;
    }
}