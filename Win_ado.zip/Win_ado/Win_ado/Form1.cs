﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if (txt_employeename.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_employeepassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                Employee obj = new Employee();
                obj.EmployeeCity = txt_employeecity.Text;
                obj.EmployeeName = txt_employeename.Text;
                obj.EmployeePassword = txt_employeepassword.Text;

                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee Added :" + id);
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_employeecity.Text = string.Empty;
            txt_employeename.Text = string.Empty;
            txt_employeepassword.Text = string.Empty;
            
        }
    }
}
