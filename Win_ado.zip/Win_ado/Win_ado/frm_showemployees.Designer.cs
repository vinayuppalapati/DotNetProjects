﻿namespace Win_ado
{
    partial class frm_showemployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_employeesearch = new System.Windows.Forms.TextBox();
            this.lbl_employeesearch = new System.Windows.Forms.Label();
            this.btn_employeefind = new System.Windows.Forms.Button();
            this.btn_employeesearchall = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(30, 29);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(189, 25);
            this.lbl_employeecity.TabIndex = 0;
            this.lbl_employeecity.Text = "Enter Employee City";
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(237, 29);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(201, 30);
            this.txt_employeecity.TabIndex = 1;
            // 
            // txt_employeesearch
            // 
            this.txt_employeesearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeesearch.Location = new System.Drawing.Point(237, 83);
            this.txt_employeesearch.Name = "txt_employeesearch";
            this.txt_employeesearch.Size = new System.Drawing.Size(201, 30);
            this.txt_employeesearch.TabIndex = 3;
            // 
            // lbl_employeesearch
            // 
            this.lbl_employeesearch.AutoSize = true;
            this.lbl_employeesearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeesearch.Location = new System.Drawing.Point(30, 83);
            this.lbl_employeesearch.Name = "lbl_employeesearch";
            this.lbl_employeesearch.Size = new System.Drawing.Size(81, 25);
            this.lbl_employeesearch.TabIndex = 2;
            this.lbl_employeesearch.Text = "Search:";
            // 
            // btn_employeefind
            // 
            this.btn_employeefind.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_employeefind.Location = new System.Drawing.Point(492, 29);
            this.btn_employeefind.Name = "btn_employeefind";
            this.btn_employeefind.Size = new System.Drawing.Size(124, 37);
            this.btn_employeefind.TabIndex = 4;
            this.btn_employeefind.Text = "Find";
            this.btn_employeefind.UseVisualStyleBackColor = true;
            this.btn_employeefind.Click += new System.EventHandler(this.btn_employeefind_Click);
            // 
            // btn_employeesearchall
            // 
            this.btn_employeesearchall.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_employeesearchall.Location = new System.Drawing.Point(492, 83);
            this.btn_employeesearchall.Name = "btn_employeesearchall";
            this.btn_employeesearchall.Size = new System.Drawing.Size(124, 37);
            this.btn_employeesearchall.TabIndex = 5;
            this.btn_employeesearchall.Text = "Search(All)";
            this.btn_employeesearchall.UseVisualStyleBackColor = true;
            this.btn_employeesearchall.Click += new System.EventHandler(this.btn_employeesearchall_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(12, 138);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(604, 298);
            this.dg_employees.TabIndex = 6;
            // 
            // frm_showemployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 448);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_employeesearchall);
            this.Controls.Add(this.btn_employeefind);
            this.Controls.Add(this.txt_employeesearch);
            this.Controls.Add(this.lbl_employeesearch);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.lbl_employeecity);
            this.Name = "frm_showemployees";
            this.Text = "frm_showemployees";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_employeesearch;
        private System.Windows.Forms.Label lbl_employeesearch;
        private System.Windows.Forms.Button btn_employeefind;
        private System.Windows.Forms.Button btn_employeesearchall;
        private System.Windows.Forms.DataGridView dg_employees;
    }
}