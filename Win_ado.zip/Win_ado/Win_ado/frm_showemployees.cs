﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_showemployees : Form
    {
        public frm_showemployees()
        {
            InitializeComponent();
        }

        private void btn_employeefind_Click(object sender, EventArgs e)
        {
            if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else
            {
                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                string city = txt_employeecity.Text;
                List<Employee> list = dal.ShowEmployees(city);
                dg_employees.DataSource = list;
            }
        }

        private void btn_employeesearchall_Click(object sender, EventArgs e)
        {
            if (txt_employeesearch.Text == string.Empty)
            {
                MessageBox.Show("enter Search");
            }
            else
            {
                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                string key = txt_employeesearch.Text;
                List<Employee> list = dal.SearchEmployees(key);
                dg_employees.DataSource = list;
            }

        }
    }
}
