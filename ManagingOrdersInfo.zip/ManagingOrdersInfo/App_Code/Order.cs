﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    public int Orderid { get; set; }
    public string Customeremail { get; set; }

    public int productid { get; set; }
    public int Price { get; set; }

    public int quantity { get; set; }

    public string city { get; set; }

    public string paymenttype { get; set; }


    public string address { get; set; }

   
}