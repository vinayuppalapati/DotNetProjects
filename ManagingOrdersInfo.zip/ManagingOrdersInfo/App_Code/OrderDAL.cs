﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


/// <summary>
/// Summary description for OrderDAL
/// </summary>
public class OrderDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int addorder(Order o)
    {
        try
        {
            SqlCommand com_or_insert = new SqlCommand("add_order", con);
            com_or_insert.Parameters.AddWithValue("@email", o.Customeremail);
            com_or_insert.Parameters.AddWithValue("@productid", o.productid);
            com_or_insert.Parameters.AddWithValue("@price", o.Price);
            com_or_insert.Parameters.AddWithValue("@quantity", o.quantity);
            com_or_insert.Parameters.AddWithValue("@paymenttype", o.paymenttype);
            com_or_insert.Parameters.AddWithValue("@city", o.city);
            com_or_insert.Parameters.AddWithValue("@address", o.address);
            com_or_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_or_insert.Parameters.Add(retdata);

            con.Open();
            com_or_insert.ExecuteNonQuery();
            int ID = Convert.ToInt32(retdata.Value);
            con.Close();
            return ID;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
}