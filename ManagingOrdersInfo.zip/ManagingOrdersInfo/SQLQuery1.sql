use PathfrontADO;

drop table tbl_orders
create table tbl_orders(OrderID int identity(100,1),CustomerEmailID varchar(100) primary key,
ProductID int,Productprice int,ProductQty int,PaymentType varchar(100),Ordercity varchar(100),
caddress varchar(100));


alter proc add_order(@email varchar(100),@productid int,@price int,@quantity int,@paymenttype varchar(100),@city varchar(100),@address varchar(100))
as
insert tbl_orders values(@email,@productid,@price,@quantity,@paymenttype,@city,@address)
return @@identity
exec add_order "abcd@abc.com",12,200,2,"online","vijayawada","BGL"

select * from tbl_orders