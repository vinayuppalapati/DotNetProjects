﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PagePlaceOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
            ddl_productid.Items.Add(new ListItem("select",""));
            ddl_productid.Items.Add(new ListItem("1", "1"));
            ddl_productid.Items.Add(new ListItem("2", "2"));
            ddl_productid.Items.Add(new ListItem("3", "3"));
            ddl_productid.Items.Add(new ListItem("4", "4"));
            ddl_productid.Items.Add(new ListItem("5", "5"));

        ddl_quantity.Items.Add(new ListItem("select", ""));
        ddl_quantity.Items.Add(new ListItem("1", "1"));
        ddl_quantity.Items.Add(new ListItem("2", "2"));
        ddl_quantity.Items.Add(new ListItem("3", "3"));
        ddl_quantity.Items.Add(new ListItem("4", "4"));
        ddl_quantity.Items.Add(new ListItem("5", "5"));

        //ddl_quantity.Items.Add("");
        //    ddl_quantity.Items.Add("1");
        //    ddl_quantity.Items.Add("2");
        //    ddl_quantity.Items.Add("3");
        //    ddl_quantity.Items.Add("4");
        //    ddl_quantity.Items.Add("5");

            ddl_city.Items.Add(new ListItem("select", ""));
            ddl_city.Items.Add(new ListItem("BGL", "BGL"));
            ddl_city.Items.Add(new ListItem("VIJ", "VIJ"));
            ddl_city.Items.Add(new ListItem("OGL", "OGL"));
            ddl_city.Items.Add(new ListItem("DEL", "DEL"));
            ddl_city.Items.Add(new ListItem("HYD", "HYD"));
        



    }

    protected void btn_neworder_Click(object sender, EventArgs e)
    {
       
        Order od = new Order();
        od.Customeremail = txt_email.Text;
        od.productid = Convert.ToInt32(ddl_productid.Text);
        od.quantity = Convert.ToInt32(ddl_quantity.Text);
        od.city = ddl_city.Text;
        if (r1.Checked == true)
        {
            od.paymenttype = "Net Banking";
        }else if(r2.Checked==true){
            od.paymenttype = "Debit";

        }else
        {
            od.paymenttype = "COD";
        }
        od.address = txt_address.Text;

        OrderDAL dal = new OrderDAL();
        int id=dal.addorder(od);
        
        Response.Redirect("~/home.aspx?code="+id);
    }
}