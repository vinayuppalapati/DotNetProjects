﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_paymentoption_Click(object sender, EventArgs e)
        {

        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            if (txt_orderid.Text == string.Empty)
                MessageBox.Show("Enter Orderid");
            else if (txt_CustomerName.Text == string.Empty)
                MessageBox.Show("Enter Customer Name");
            else if (txt_Itemid.Text == string.Empty)
                MessageBox.Show("Enter Item ID");
            else if (txt_itemqty.Text == string.Empty)
                MessageBox.Show("Enter Item Qty");
            else if (txt_itemprice.Text == string.Empty)
                MessageBox.Show("Enter Itemprice");
            else if (txt_DeliveryAddress.Text == string.Empty)
                MessageBox.Show("Enter Delivery Address ");
            else if (cmb_Ordercity.Text == string.Empty)
                MessageBox.Show("Select Order City");
            else if (rdb_cashondelivery.Checked == false && rdb_online.Checked == false)
                MessageBox.Show("Select Payment Option");
            else
            {
                string city = cmb_Ordercity.Text;
                string payment=String.Empty;
                if (rdb_cashondelivery.Checked == true)
                {
                    payment = "CashOnDelivery";
                }else
                {
                    payment = "Online";
                }

                Order obj = new Order(Convert.ToInt32(txt_orderid.Text), txt_CustomerName.Text, Convert.ToInt32(txt_Itemid.Text), Convert.ToInt32(txt_itemqty.Text), Convert.ToInt32(txt_itemprice.Text), txt_DeliveryAddress.Text, cmb_Ordercity.Text, payment);
                MessageBox.Show("Your Order has been successfully placed and Total Amount is "+obj.GetOrderValue().ToString());

            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_Ordercity.Items.Add("Vijayawada");
            cmb_Ordercity.Items.Add("Bangalore");
            cmb_Ordercity.Items.Add("hyderabad");
        }
    }
}
