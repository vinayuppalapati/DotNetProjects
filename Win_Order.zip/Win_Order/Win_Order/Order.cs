﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int itemid;
        private int itemprice;
        private int itemqty;
        private string DeliveryAddress;
        private string Ordercity;
        private string payment;
        public Order(int OrderID,string CustomerName,int itemid,int itemqty,int itemprice,string DeliveryAddress,string Ordercity,string payment)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.itemid = itemid;
            this.itemprice = itemprice;
            this.DeliveryAddress = DeliveryAddress;
            this.Ordercity = Ordercity;
            this.payment = payment;
            this.itemqty = itemqty;
        }

        public int GetOrderValue()
        {
            return this.itemprice * this.itemqty;
        }
    }
}
