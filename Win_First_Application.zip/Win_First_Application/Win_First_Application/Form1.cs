﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
       

        private void button1_Click(object sender, EventArgs e)
        {
            string button1 = textBox1.Text;
            string button2 = textBox2.Text;
            if(button1=="login" && button2 == "password")
            {
                MessageBox.Show("Succesfully Login");
            }
            else
            {
                MessageBox.Show("Invalid User and password");
            }
        }

     

     

      
    }
}
