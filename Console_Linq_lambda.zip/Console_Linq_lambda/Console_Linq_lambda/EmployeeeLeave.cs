﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_lambda
{
    class EmployeeeLeave
    {

        public int LeaveID { get; set; }
        public string LeaveType { get; set; }
        public string Reason { get; set; }
        public int EmployeeID { get; set; }
    }
}
