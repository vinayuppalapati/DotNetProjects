﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DAy21_11_Mvc_BankApplication_2.Controllers
{
    public class BankController : Controller
    {
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string id,string password)
        {
            if (id == "abc@path.in" && password == "pass")
            {
                return RedirectToAction("Index", "Bank");
            }
            else
            {
                ViewBag.msg = "Invalid id and password";
                return View();
            }
        }
        // GET: Bank
        public ActionResult Index()
        {

            return View();
        }
        
         public ActionResult AboutUs()
        {
            return View();
        } 
        public ActionResult Info()
        {
            return View();
        }
        public ActionResult Logout()
        {
            return RedirectToAction("Login", "Bank");
        }
    }
}