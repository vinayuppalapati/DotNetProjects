﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Day19_11_mvc_first_application.Controllers
{
    public class HomeController : Controller
    {  
        public ActionResult Index()
        {
            int loginid = Convert.ToInt32(Session["loginid"]);
            ViewBag.loginid = loginid;
            return View();
        }
        public ActionResult Calc()
        {
            return View();//Calc
        }
        [HttpPost]
        public ActionResult Calc(int num1,int num2)
        {
            int total = num1 + num2;
            ViewBag.sum = total;
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(int LoginID,string Password)
        {
            if (LoginID == 1001 && Password == "pass")
            {
                Session["loginid"] = LoginID;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid User Id or Password";
                return View();
            }
        }
    }
}