﻿using System.Web;
using System.Web.Mvc;

namespace Day24_11_Mvc_Error_handling
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
