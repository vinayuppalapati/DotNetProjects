﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Day24_11_Mvc_Error_handling.Controllers
{
    public class HomeController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            //   base.OnException(filterContext);
            filterContext.ExceptionHandled = true;
            System.Diagnostics.EventLog log = new System.Diagnostics.EventLog();
            log.Source = "MVCApplication";
            log.WriteEntry(filterContext.Exception.Message);
            ViewResult vr = new ViewResult()
            { ViewName = "~/Views/Shared/MyErrorHomeView.cshtml" };

        }
        // GET: Home
        [HandleError(View = "MyErrorHomeView",ExceptionType =typeof(DivideByZeroException))]

        [HandleError(View = "MyErrorHomeView1", ExceptionType = typeof(NullReferenceException))]
        public ActionResult Index()
        {
            int x = 100;
            int y = x / 0;

            return View();
        }
    }
}