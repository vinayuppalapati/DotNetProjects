﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Library
/// </summary>
public class Library
{
   public int BookId
    {
        get;
        set;
    }
    public string BookName { get; set; }
    public string AuthorName { get; set; }
    public string BookImageName { get; set; }

}