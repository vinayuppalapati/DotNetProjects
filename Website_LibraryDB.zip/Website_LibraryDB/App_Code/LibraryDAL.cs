﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LibraryDAL
/// </summary>
public class LibraryDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int addBook(Library l)
    {
        try
        {
            SqlCommand com_lb_insert = new SqlCommand("proc_addbooks", con);
            com_lb_insert.Parameters.AddWithValue("@name", l.BookName);
            com_lb_insert.Parameters.AddWithValue("@author", l.AuthorName);
            com_lb_insert.Parameters.AddWithValue("@image", l.BookImageName);
            com_lb_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_lb_insert.Parameters.Add(retdata);

            con.Open();
            com_lb_insert.ExecuteNonQuery();
            
            int id =Convert.ToInt32(retdata.Value);
            con.Close();
            return id;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    public List<Library> SearchBooks(string key)
    {
        try
        {
            SqlCommand com_lb_se = new SqlCommand("proc_searchbooks", con);
            com_lb_se.Parameters.AddWithValue("@key", key);
            com_lb_se.CommandType = CommandType.StoredProcedure;
            List<Library> lib_list = new List<Library>();

            con.Open();
            SqlDataReader rd = com_lb_se.ExecuteReader();
            while (rd.Read())
            {
                Library l = new Library();
                l.BookId = rd.GetInt32(0);
                l.BookName = rd.GetString(1);
                l.AuthorName = rd.GetString(2);
                l.BookImageName = rd.GetString(3);
                lib_list.Add(l);
            }
            con.Close();
            return lib_list;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
}