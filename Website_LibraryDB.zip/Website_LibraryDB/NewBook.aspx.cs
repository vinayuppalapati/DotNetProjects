﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_newbook_Click(object sender, EventArgs e)
    {
        Library l = new Library();
        l.AuthorName = txt_authorname.Text;
        l.BookName = txt_bookname.Text;
        l.BookImageName = "~/Images/" + Guid.NewGuid() + ".jpg";
        file_image.SaveAs(Server.MapPath(l.BookImageName));
        LibraryDAL dal = new LibraryDAL();
        int id = dal.addBook(l);
        lbl_BookID.Text = id.ToString();

    }
}