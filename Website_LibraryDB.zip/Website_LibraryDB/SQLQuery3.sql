create database LibraryDB

use LibraryDB

create table tbl_books(BookID int identity(1000,1) primary key,
BookName varchar(100),AuthorName varchar(100),BookImage varchar(1000))

select * from tbl_books

truncate table tbl_books
create proc proc_addbooks(@name varchar(100),@author varchar(100),@image varchar(1000))
as
insert tbl_books values(@name,@author,@image)
return @@identity

alter proc proc_searchbooks(@key varchar(100))
as
select * from tbl_books where  BookID  like '%'+@key+'%' or BookName like '%'+@key+'%' or AuthorName like'%'+@key+'%'
	