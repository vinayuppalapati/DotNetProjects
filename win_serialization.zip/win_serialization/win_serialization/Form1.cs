﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;


namespace win_serialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_serialize_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_productid.Text);
            p.ProductName = txt_productname.Text;
            p.ProductPrice = Convert.ToInt32(txt_productprice.Text);


            FileStream fs = new FileStream("D:/DotNetProjects/Text/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Binary Serialization Done");

        }

        private void btn_deserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("D:/DotNetProjects/Text/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs) as Product;
            fs.Close();
            txt_productid.Text = p.ProductID.ToString();
            txt_productname.Text = p.ProductName;
            txt_productprice.Text = p.ProductPrice.ToString();
        }

        private void btn_xmlserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("D:/DotNetProjects/Text/prod.xml", FileMode.Create, FileAccess.Write);
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_productid.Text);
            p.ProductName = txt_productname.Text;
            p.ProductPrice = Convert.ToInt32(txt_productprice.Text);

            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("XML Serialization Mode");
        }

        private void btn_xmldeserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("D:/DotNetProjects/Text/prod.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            txt_productid.Text = p.ProductID.ToString();
            txt_productname.Text = p.ProductName;
            txt_productprice.Text = p.ProductPrice.ToString();
        }
    }
}
