﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        string id = txt_loginid.Text;
        string password = txt_password.Text;
        if(id=="abc@abc.com"&& password == "pass@123")
        {
            Response.Redirect("~/PageHome.aspx");
        }
        else
        {
            lbl_msg.Text = "Invald User ID and password";
        }
    }
}