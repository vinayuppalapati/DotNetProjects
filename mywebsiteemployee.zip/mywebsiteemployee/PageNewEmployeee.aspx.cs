﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageNewEmployeee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ddl_cities.Items.Add(new ListItem("Select", ""));
        ddl_cities.Items.Add(new ListItem("BGL", "BGL"));
        ddl_cities.Items.Add(new ListItem("Pune", "Pune"));


    }

    protected void btn_new_employee_Click(object sender, EventArgs e)
    {
        string id = Guid.NewGuid().ToString();
        string address= "~/Images/" + id + ".jpg";
        file_upload_employee.SaveAs(Server.MapPath(address));
        emp_image.ImageUrl = address;

    }
}