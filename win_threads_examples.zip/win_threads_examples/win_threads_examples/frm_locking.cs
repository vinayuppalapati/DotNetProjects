﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace win_threads_examples
{
    public partial class frm_locking : Form
    {

        ReaderWriterLock rw = new ReaderWriterLock();


        int total;

        public void sum()
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            rw.AcquireReaderLock(Timeout.Infinite);
           // if (Monitor.TryEnter(this,3000))
           // {
                // lock (this)
                //{
                total = n1 + n2;
                Thread.Sleep(15000);
                MessageBox.Show("Total : " + total);
            //   }
            //       Monitor.Exit(this);
            // }
            // else
            //  {
            //    MessageBox.Show("Thread Busy");
            // }
            rw.ReleaseLock();
        }

        public void sum1()
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            rw.AcquireWriterLock(Timeout.Infinite);
           
            total = n1 + n2;
            Thread.Sleep(15000);
            MessageBox.Show("Total : " + total);

            rw.ReleaseLock();

        }
        public frm_locking()
        {
            InitializeComponent();
        }

        private void btn_thread1_Click(object sender, EventArgs e)
        {
           Thread th1 = new Thread(this.sum);
            th1.Start();
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {

            Thread th2 = new Thread(this.sum1);
            th2.Start();
        }
    }
}
