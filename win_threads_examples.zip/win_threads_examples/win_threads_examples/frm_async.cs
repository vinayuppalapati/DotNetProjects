﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace win_threads_examples
{
    public partial class frm_async : Form
    {
        public delegate int delthread(int n1, int n2);
        public frm_async()
        {
            InitializeComponent();
        }
        public int GetSum(int n1,int n2)
        {
            Thread.Sleep(5000);
            return n1 + n2;
        }

        public delegate void del();


        public void callback1(IAsyncResult res)
        {
            MessageBox.Show("GetSum called "+res.AsyncState);
        }

        public void done(IAsyncResult res)
        {
            int returndata = d.EndInvoke(res);
            // lbl_msg.Text+= MessageBox.Show("GetSum called" + res.AsyncState+" : "+returndata);
            del obj = new del(() =>
            {
                lst_msg.Items.Add(res.AsyncState + "      :    " + returndata);
               
            });
            this.BeginInvoke(obj);


           
        }
        delthread d;
        private void btn_asyncsum_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            if (d == null)
            {
                d = new delthread(this.GetSum);
            }

            string str= n1+ " + " +n2;
             d.BeginInvoke(n1, n2, done, str);//New Thread
           // d.BeginInvoke(10, 57, done, "101");//New Thread

        }
    }
}
