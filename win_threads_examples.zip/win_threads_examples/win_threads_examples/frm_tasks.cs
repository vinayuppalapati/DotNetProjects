﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_threads_examples
{
    public partial class frm_tasks : Form
    {
        public frm_tasks()
        {
            InitializeComponent();
        }

        private void btn_newtask_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Run(() =>
            {
                MessageBox.Show("Task 1");
            });

            Task t2 = Task.Run(() =>
             {
                 MessageBox.Show("Task 2");
             });
        }

        private async void btn_newtask2_Click(object sender, EventArgs e)
        {
            Test obj = new Test();
            var t=  obj.AddNumbersAsync(10, 20);
            MessageBox.Show("Some other Work");

            int x = await t;
            MessageBox.Show("Return Data:" + x);
        }
    }
}
