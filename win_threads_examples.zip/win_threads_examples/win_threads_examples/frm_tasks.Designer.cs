﻿namespace win_threads_examples
{
    partial class frm_tasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newtask = new System.Windows.Forms.Button();
            this.btn_newtask2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newtask
            // 
            this.btn_newtask.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtask.Location = new System.Drawing.Point(208, 124);
            this.btn_newtask.Name = "btn_newtask";
            this.btn_newtask.Size = new System.Drawing.Size(149, 38);
            this.btn_newtask.TabIndex = 0;
            this.btn_newtask.Text = "New Task";
            this.btn_newtask.UseVisualStyleBackColor = true;
            this.btn_newtask.Click += new System.EventHandler(this.btn_newtask_Click);
            // 
            // btn_newtask2
            // 
            this.btn_newtask2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtask2.Location = new System.Drawing.Point(208, 201);
            this.btn_newtask2.Name = "btn_newtask2";
            this.btn_newtask2.Size = new System.Drawing.Size(149, 38);
            this.btn_newtask2.TabIndex = 1;
            this.btn_newtask2.Text = "New Task 2";
            this.btn_newtask2.UseVisualStyleBackColor = true;
            this.btn_newtask2.Click += new System.EventHandler(this.btn_newtask2_Click);
            // 
            // frm_tasks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 316);
            this.Controls.Add(this.btn_newtask2);
            this.Controls.Add(this.btn_newtask);
            this.Name = "frm_tasks";
            this.Text = "frm_tasks";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newtask;
        private System.Windows.Forms.Button btn_newtask2;
    }
}