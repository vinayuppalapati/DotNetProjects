﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics
{
    class Test
    {
        public T GetDetails<T>(T para)
        {

            return para;

        }
        
    }
}
