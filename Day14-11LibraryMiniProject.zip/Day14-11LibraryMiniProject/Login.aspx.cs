﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        LibraryDAL dal = new LibraryDAL();

      bool status=  dal.LoginStudent(Convert.ToInt32(txt_studentid.Text), txt_password.Text);
        if (status)
        {
            Session["loginid"] = txt_studentid.Text;

            Response.Redirect("~/Home.aspx");
        }
        else
        {
            lbl_invalid.Text = "Invalid User and Password";
        }
    }
}