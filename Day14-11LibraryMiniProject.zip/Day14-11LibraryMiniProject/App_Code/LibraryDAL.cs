﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public class LibraryDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public int addStudent(Student s)
    {
        try
        {
            SqlCommand com_su_insert = new SqlCommand("proc_addstudent", con);
            com_su_insert.Parameters.AddWithValue("@studentname", s.StudentName);
            com_su_insert.Parameters.AddWithValue("@studentemail", s.StudentEmailID);
            com_su_insert.Parameters.AddWithValue("@studentpassword", s.StudentPassword);
            com_su_insert.Parameters.AddWithValue("@studentimage", s.StudentImage);
            com_su_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();

            retdata.Direction = ParameterDirection.ReturnValue;
            com_su_insert.Parameters.Add(retdata);
            con.Open();
            com_su_insert.ExecuteNonQuery();
            int id = Convert.ToInt32(retdata.Value);
            con.Close();

            return id;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }

    public int addBook(Book b)
    {
        try
        {

            SqlCommand com_bo_insert = new SqlCommand("proc_addBook", con);
            com_bo_insert.Parameters.AddWithValue("@bookname", b.BookName);
            com_bo_insert.Parameters.AddWithValue("@authorname", b.AuthorName);
            com_bo_insert.Parameters.AddWithValue("@BookImage", b.BookImage);
            com_bo_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_bo_insert.Parameters.Add(retdata);

            con.Open();
            com_bo_insert.ExecuteNonQuery();
            int ID = Convert.ToInt32(retdata.Value);
            con.Close();
            return ID;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }


    }
    public int addIssueBook(IssueBook i)
    {
        try
        {


            SqlCommand com_is_insert = new SqlCommand("proc_addIssue", con);
            com_is_insert.Parameters.AddWithValue("@bookid", i.BookId);
            com_is_insert.Parameters.AddWithValue("@studentid", i.StudentID);
            com_is_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_is_insert.Parameters.Add(retdata);
            con.Open();
            com_is_insert.ExecuteNonQuery();
            int ID = Convert.ToInt32(retdata.Value);
            con.Close();
            return ID;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    public List<Book> searchBooks(string key)
    {
        SqlCommand com_bo_search = new SqlCommand("proc_search", con);
        com_bo_search.Parameters.AddWithValue("@key", key);
        com_bo_search.CommandType = CommandType.StoredProcedure;
        List<Book> list = new List<Book>();

        con.Open();
        SqlDataReader dr = com_bo_search.ExecuteReader();
        while (dr.Read())
        {
            Book b = new Book();
            b.BookID = dr.GetInt32(0);
            b.BookName = dr.GetString(1);
            b.AuthorName = dr.GetString(2);
            b.BookImage = dr.GetString(3);
            
            list.Add(b);
        }
        con.Close();
        return list;

    }
    public List<IssueBook> SearchIssues(string key)
    {
        SqlCommand com_is_search = new SqlCommand("proc_myissuebooks", con);
        com_is_search.Parameters.AddWithValue("@key", key);
        com_is_search.CommandType = CommandType.StoredProcedure;
        con.Open();
        List<IssueBook> list = new List<IssueBook>();
        SqlDataReader dr = com_is_search.ExecuteReader();
        while (dr.Read())
        {
            IssueBook i = new IssueBook();
            i.IssueID = dr.GetInt32(0);
            i.BookId = dr.GetInt32(1);
            i.StudentID = dr.GetInt32(2);
            i.IssueDate = dr.GetDateTime(3);
            i.IssueStatus = dr.GetString(4);

            list.Add(i);

        }
        con.Close();
        return list;
    }
    public bool LoginStudent(int st,string pass)
    {
        SqlCommand com_st_login = new SqlCommand("proc_login", con);
        com_st_login.Parameters.AddWithValue("@studentid", st);
        com_st_login.Parameters.AddWithValue("@studentpassword", pass);
        com_st_login.CommandType = CommandType.StoredProcedure;

        SqlParameter retdata = new SqlParameter();        
        con.Open();
        retdata.Direction = ParameterDirection.ReturnValue;
        com_st_login.Parameters.Add(retdata);

        com_st_login.ExecuteNonQuery();
        int id = Convert.ToInt32(retdata.Value);
        if (id > 0)
        {
            return true;

        }
        else
        {
            return false;
        }

   }

    public Book Find(int id)
    {
        SqlCommand com_bo_find = new SqlCommand("proc_Find", con);
        com_bo_find.Parameters.AddWithValue("@id", id);
        com_bo_find.CommandType = CommandType.StoredProcedure;
        con.Open();
        SqlDataReader rd = com_bo_find.ExecuteReader();
        Book b = new Book();
        if (rd.Read())
        {
            b.BookID = rd.GetInt32(0);
            b.BookName = rd.GetString(1);
            b.AuthorName = rd.GetString(2);
            b.BookImage = rd.GetString(3);

        }
        if (b != null)
            return b;
        else
            return null;

    }
    public List<MyIssuedBooks> myissuebooks(int id)
    {
        SqlCommand com_my_list = new SqlCommand("proc_myissuebooks", con);
        com_my_list.Parameters.AddWithValue("@id", id);
        com_my_list.CommandType = CommandType.StoredProcedure;
        con.Open();
        SqlDataReader rd = com_my_list.ExecuteReader();
        List<MyIssuedBooks> list = new List<MyIssuedBooks>(); 
        while (rd.Read())
        {
            MyIssuedBooks m = new MyIssuedBooks();
            m.BookID = rd.GetInt32(0);
            m.BookName = rd.GetString(1);
            m.BookImage = rd.GetString(2);
            m.IssueDate = rd.GetDateTime(3);
            m.IssueID = rd.GetInt32(4);
            m.StudentID = rd.GetInt32(5);
            list.Add(m);
        }
        return list;

    }

}