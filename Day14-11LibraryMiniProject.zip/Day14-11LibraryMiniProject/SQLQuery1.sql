create database MiniLibraryDB1

use MiniLibraryDB1

create table tbl_Students(StudentID int identity(100,1) primary key,
StudentName varchar(100) not null,StudentEmailID varchar(100) not null,StudentPassword varchar(100) not null,StudentImage varchar(1000) not null)

--drop table tbl_students

select * from tbl_Students

create table tbl_Books(BookID int Identity(1000,1) primary key,
BookName varchar(100) not null,AuthorName varchar(100) not null,BookImage varchar(1000) not null)

alter table tbl_books alter column BookName varchar(100)
insert tbl_Books values('vinay','kumar','jsjsdajks')
	

select * from tbl_Books

create table tbl_IssueBooks(IssueID int identity(2000,1) primary key,BookID int foreign key references tbl_Books(BookID) not null,StudentID int foreign key references tbl_Students(StudentID) not null,IssueDate datetime not null,IssueStatus varchar(100) not null)

create proc proc_addBook(@bookname varchar(100),@authorname varchar(100),@BookImage varchar(1000))
as
insert tbl_Books values(@bookname,@authorname,@BookImage)
return @@identity

select * from tbl_Books
 
 sp_help proc_addBook
 sp_help tbl_books
 insert tbl_Books values('Something','Vinay','Images/SJHjhasjhsajsds.jpg')
	
exec proc_addBook 'Something','Vinay','Images/SJHjhasjhsajsds.jpg'

create proc proc_addstudent(@studentname varchar(100),@studentemail varchar(100),@studentpassword varchar(100),@studentimage varchar(1000))
as
insert tbl_Students values(@studentname,@studentemail,@studentpassword,@studentimage)
return @@identity

exec proc_addstudent 'vinay','asjh@hsdj.ss','1234','afdfsdfdsfsdfsd'
create proc proc_login(@studentid int,@studentpassword varchar(100))
as
declare @count int
select @count=count(*) from tbl_Students where StudentID=@studentid and StudentPassword=@studentpassword
return @count

create proc proc_search(@key varchar(100))
as
select * from tbl_Books where BookID like '%'+@key+'%' or BookName like'%'+@key+'%' or AuthorName like'%'+@key+'%'

alter proc proc_addIssue(@bookid int,@studentid int)
as
insert tbl_IssueBooks values(@bookid,@studentid,getdate(),'Issued')
return @@identity

exec proc_addIssue '1004','103'

alter proc proc_myissuebooks(@id int)
as
select tbl_Books.BookID,tbl_Books.BookName,tbl_Books.BookImage,tbl_IssueBooks.IssueDate,tbl_IssueBooks.IssueID,tbl_IssueBooks.StudentID from tbl_Books join tbl_IssueBooks on tbl_Books.BookID=tbl_IssueBooks.BookID where StudentID=@id

create proc proc_Find(@id int)
as
select * from tbl_Books where BookID=@id

select * from tbl_IssueBooks


