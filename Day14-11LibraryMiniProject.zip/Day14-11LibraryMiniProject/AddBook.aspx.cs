﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      

    }

    protected void btn_addbook_Click(object sender, EventArgs e)
    {
        LibraryDAL dal = new LibraryDAL();
        Book b = new Book();
        b.BookName = txt_bookname.Text;
        b.AuthorName = txt_authorname.Text;
        b.BookImage = "~/Images/" + Guid.NewGuid() + ".jpg";
        bookimage.SaveAs(Server.MapPath(b.BookImage));

        int id = dal.addBook(b);
        lbl_bookid.Text = id.ToString();
    }
}