﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_addstudent_Click(object sender, EventArgs e)
    {
        LibraryDAL dal = new LibraryDAL();
        Student s = new Student();
        s.StudentName = txt_studentname.Text;
        s.StudentPassword = txt_studentpassword.Text;
        s.StudentEmailID = txt_studentemail.Text;
        s.StudentImage = "~/Images/" + Guid.NewGuid() + ".jpg";
        file_studentimage.SaveAs(Server.MapPath(s.StudentImage));

       int id= dal.addStudent(s);
        lbl_studentid.Text = id.ToString();

    }
}