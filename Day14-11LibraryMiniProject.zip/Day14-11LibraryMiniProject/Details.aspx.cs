﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"];
        int Bookid = Convert.ToInt32(id);
        LibraryDAL dal = new LibraryDAL();

        Book b = dal.Find(Bookid);
        lbl_bookid.Text = b.BookID.ToString();
        lbl_bookname.Text = b.BookName;
        lbl_authorname.Text = b.AuthorName;
        file_image.ImageUrl = b.BookImage;

        
             
    }

    protected void btn_issue_Click(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"];
        int Bookid = Convert.ToInt32(id);
        int StudentID = Convert.ToInt32(Session["loginid"]);

        LibraryDAL dal = new LibraryDAL();
        IssueBook i = new IssueBook();
        i.StudentID = StudentID;
       

        i.BookId =Convert.ToInt32( lbl_bookid.Text);


        int issueid = dal.addIssueBook(i);
       Response.Redirect("~/IssueDetails.aspx?id=" +issueid);
    }
}