﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Customer
    {
        private readonly int CustomerID;
        private string CustomerName;
        private string CustomerCity;

        public Customer()
        {
            

        }
        public Customer(int CustomerID,string CustomerName,string CustomerCity)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = CustomerName;
            this.CustomerCity = CustomerCity;
            
            this.CustomerID = 23434;
        }
        public string GetDetails()
        {
            return this.CustomerID + " " + this.CustomerName + " " + this.CustomerCity;
        }
    }
}
