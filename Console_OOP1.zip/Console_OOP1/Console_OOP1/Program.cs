﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter Customer ID :");
            //int id = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter Customer Name: ");
            //string name = Console.ReadLine();
            //Console.WriteLine("Enter Customer Address: ");
            //string address = Console.ReadLine();

            //Customer obj = new Customer(id, name, address);
            //string details = obj.GetDetails();
            //Console.WriteLine(details);


            Console.WriteLine("Enter Account ID :");
            int AccID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name : ");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccID, Name, Balance);

           

            Console.WriteLine("Account Balance :" + obj.GetBalance());

            Console.WriteLine("Enter Amount to Withdraw");
            obj.Withdraw(Convert.ToInt32(Console.ReadLine()));

            Console.WriteLine("Account Balance :" + obj.GetBalance());


            Console.WriteLine("Enter Amount to Deposit")
                int ab = Convert.ToInt32(Console.ReadLine());

            obj.Deposit(a);



            Console.WriteLine("Account Balance :" + obj.GetBalance());

            Console.ReadLine();


        }
    }
}
