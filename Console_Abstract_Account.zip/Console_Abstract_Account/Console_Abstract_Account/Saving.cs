﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Saving : Account
    {
        private int SAccountID;
        private static int count = 1000;
        public Saving(string CustomerName, int AccountBalance) : base(CustomerName, AccountBalance)
        {
            Saving.count++;
            this.SAccountID = count;
            Console.WriteLine("Saving Constructor");
        }

        public int PAccountID
        {
            get
            {
                return this.SAccountID;
            }
        }

        public override void Deposit(int Amt)
        {
            this.AccountBalance += Amt + 100;
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance -= Amt + 10;
        }
    }
}
