﻿namespace Win_First_Application1
{
    partial class Frm_Controls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.chk_readme = new System.Windows.Forms.CheckBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_cities
            // 
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.Location = new System.Drawing.Point(175, 129);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.Size = new System.Drawing.Size(120, 95);
            this.lst_cities.TabIndex = 0;
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(425, 171);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_Save.TabIndex = 1;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(221, 273);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(121, 21);
            this.cmb_cities.TabIndex = 2;
            this.cmb_cities.Text = "Select a City";
            // 
            // chk_readme
            // 
            this.chk_readme.AutoSize = true;
            this.chk_readme.Location = new System.Drawing.Point(425, 235);
            this.chk_readme.Name = "chk_readme";
            this.chk_readme.Size = new System.Drawing.Size(70, 17);
            this.chk_readme.TabIndex = 3;
            this.chk_readme.Text = "Read Me";
            this.chk_readme.UseVisualStyleBackColor = true;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(192, 353);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(48, 17);
            this.rdb_male.TabIndex = 4;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "Male";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(313, 353);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(59, 17);
            this.rdb_female.TabIndex = 5;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // Frm_Controls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 497);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.chk_readme);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.lst_cities);
            this.Name = "Frm_Controls";
            this.Text = "Frm_Controls";
            this.Load += new System.EventHandler(this.Frm_Controls_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.CheckBox chk_readme;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
    }
}