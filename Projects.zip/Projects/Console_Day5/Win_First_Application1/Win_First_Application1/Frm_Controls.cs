﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application1
{
    public partial class Frm_Controls : Form
    {
        public Frm_Controls()
        {
            InitializeComponent();
        }



        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                MessageBox.Show("Select you Gender");
            }
            else 
            {
                string gender = string.Empty;
                if (rdb_male.Checked == true)
                {
                    gender = "Male";
                 }
                else
                {
                    gender = "Female";
                }
                MessageBox.Show(gender);
            }




            bool status = chk_readme.Checked;
            if (status)
            {
                MessageBox.Show("It is Checked");

            }
            else
            {
                MessageBox.Show("It is UnChecked");
            }
            if (lst_cities.Text == string.Empty)
            {
                MessageBox.Show("Select a City");

            }
             else
            {
                string city = lst_cities.Text;
                MessageBox.Show(" The Selected City is " + city);
            }

        }

        private void Frm_Controls_Load(object sender, EventArgs e)
        {

            lst_cities.Items.Add("Hyderabad");
            lst_cities.Items.Add("Bangalore");
            lst_cities.Items.Add("Chennai");

            cmb_cities.Items.Add("Hyderabad");
            cmb_cities.Items.Add("Chennai");
            cmb_cities.Items.Add("Bangalore");
        }
    }
}
