﻿namespace Win_First_Application1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_loginform = new System.Windows.Forms.Label();
            this.Libl_Username = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(190, 313);
            this.btn_login.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(150, 44);
            this.btn_login.TabIndex = 0;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_loginform
            // 
            this.lbl_loginform.AutoSize = true;
            this.lbl_loginform.Location = new System.Drawing.Point(195, 29);
            this.lbl_loginform.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_loginform.Name = "lbl_loginform";
            this.lbl_loginform.Size = new System.Drawing.Size(110, 25);
            this.lbl_loginform.TabIndex = 1;
            this.lbl_loginform.Text = "Login Form";
            // 
            // Libl_Username
            // 
            this.Libl_Username.AutoSize = true;
            this.Libl_Username.Location = new System.Drawing.Point(32, 116);
            this.Libl_Username.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Libl_Username.Name = "Libl_Username";
            this.Libl_Username.Size = new System.Drawing.Size(102, 25);
            this.Libl_Username.TabIndex = 2;
            this.Libl_Username.Text = "Username";
            this.Libl_Username.Click += new System.EventHandler(this.Libl_LoginId_Click);
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(36, 213);
            this.lbl_password.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(98, 25);
            this.lbl_password.TabIndex = 3;
            this.lbl_password.Text = "Password";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(256, 113);
            this.txt_loginid.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(232, 30);
            this.txt_loginid.TabIndex = 4;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(256, 213);
            this.txt_password.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(232, 30);
            this.txt_password.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 502);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.Libl_Username);
            this.Controls.Add(this.lbl_loginform);
            this.Controls.Add(this.btn_login);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_loginform;
        private System.Windows.Forms.Label Libl_Username;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
    }
}

