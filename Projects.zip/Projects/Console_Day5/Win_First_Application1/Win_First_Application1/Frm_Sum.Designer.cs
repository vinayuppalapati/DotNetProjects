﻿namespace Win_First_Application1
{
    partial class Frm_Sum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AdditionForm = new System.Windows.Forms.Label();
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lb1_Number2 = new System.Windows.Forms.Label();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.btn_Sum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_AdditionForm
            // 
            this.lbl_AdditionForm.AutoSize = true;
            this.lbl_AdditionForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AdditionForm.Location = new System.Drawing.Point(226, 24);
            this.lbl_AdditionForm.Name = "lbl_AdditionForm";
            this.lbl_AdditionForm.Size = new System.Drawing.Size(133, 25);
            this.lbl_AdditionForm.TabIndex = 0;
            this.lbl_AdditionForm.Text = "Addition Form";
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Number1.Location = new System.Drawing.Point(38, 77);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(92, 25);
            this.lbl_Number1.TabIndex = 1;
            this.lbl_Number1.Text = "Number1";
            // 
            // lb1_Number2
            // 
            this.lb1_Number2.AutoSize = true;
            this.lb1_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1_Number2.Location = new System.Drawing.Point(38, 145);
            this.lb1_Number2.Name = "lb1_Number2";
            this.lb1_Number2.Size = new System.Drawing.Size(92, 25);
            this.lb1_Number2.TabIndex = 2;
            this.lb1_Number2.Text = "Number2";
            // 
            // txt_Number1
            // 
            this.txt_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Number1.Location = new System.Drawing.Point(249, 77);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(131, 30);
            this.txt_Number1.TabIndex = 3;
            // 
            // txt_Number2
            // 
            this.txt_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Number2.Location = new System.Drawing.Point(249, 145);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(131, 30);
            this.txt_Number2.TabIndex = 4;
            // 
            // btn_Sum
            // 
            this.btn_Sum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sum.Location = new System.Drawing.Point(184, 240);
            this.btn_Sum.Name = "btn_Sum";
            this.btn_Sum.Size = new System.Drawing.Size(130, 48);
            this.btn_Sum.TabIndex = 5;
            this.btn_Sum.Text = "Sum";
            this.btn_Sum.UseVisualStyleBackColor = true;
            this.btn_Sum.Click += new System.EventHandler(this.btn_Sum_Click);
            // 
            // Frm_Sum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 408);
            this.Controls.Add(this.btn_Sum);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lb1_Number2);
            this.Controls.Add(this.lbl_Number1);
            this.Controls.Add(this.lbl_AdditionForm);
            this.Name = "Frm_Sum";
            this.Text = "Frm_Sum";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AdditionForm;
        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.Label lb1_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.Button btn_Sum;
    }
}