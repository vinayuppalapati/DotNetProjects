﻿namespace Win_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_Itemqty = new System.Windows.Forms.Label();
            this.lbl_ItemPrice = new System.Windows.Forms.Label();
            this.lbl_deliveryaddress = new System.Windows.Forms.Label();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.txt_Itemid = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.txt_DeliveryAddress = new System.Windows.Forms.TextBox();
            this.cmb_Ordercity = new System.Windows.Forms.ComboBox();
            this.rdb_online = new System.Windows.Forms.RadioButton();
            this.rdb_cashondelivery = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(79, 43);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(81, 25);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "OrderID";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(79, 83);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(154, 25);
            this.lbl_customername.TabIndex = 1;
            this.lbl_customername.Text = "Customer Name";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(79, 129);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(68, 25);
            this.lbl_itemid.TabIndex = 2;
            this.lbl_itemid.Text = "ItemID";
            // 
            // lbl_Itemqty
            // 
            this.lbl_Itemqty.AutoSize = true;
            this.lbl_Itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Itemqty.Location = new System.Drawing.Point(79, 167);
            this.lbl_Itemqty.Name = "lbl_Itemqty";
            this.lbl_Itemqty.Size = new System.Drawing.Size(85, 25);
            this.lbl_Itemqty.TabIndex = 3;
            this.lbl_Itemqty.Text = "Item Qty";
            // 
            // lbl_ItemPrice
            // 
            this.lbl_ItemPrice.AutoSize = true;
            this.lbl_ItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ItemPrice.Location = new System.Drawing.Point(79, 209);
            this.lbl_ItemPrice.Name = "lbl_ItemPrice";
            this.lbl_ItemPrice.Size = new System.Drawing.Size(93, 25);
            this.lbl_ItemPrice.TabIndex = 4;
            this.lbl_ItemPrice.Text = "ItemPrice";
            // 
            // lbl_deliveryaddress
            // 
            this.lbl_deliveryaddress.AutoSize = true;
            this.lbl_deliveryaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_deliveryaddress.Location = new System.Drawing.Point(79, 245);
            this.lbl_deliveryaddress.Name = "lbl_deliveryaddress";
            this.lbl_deliveryaddress.Size = new System.Drawing.Size(160, 25);
            this.lbl_deliveryaddress.TabIndex = 5;
            this.lbl_deliveryaddress.Text = "Delivery Address";
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ordercity.Location = new System.Drawing.Point(79, 282);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(96, 25);
            this.lbl_ordercity.TabIndex = 6;
            this.lbl_ordercity.Text = "OrderCity";
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paymentoption.Location = new System.Drawing.Point(79, 318);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(152, 25);
            this.lbl_paymentoption.TabIndex = 7;
            this.lbl_paymentoption.Text = "Payment Option";
            this.lbl_paymentoption.Click += new System.EventHandler(this.lbl_paymentoption_Click);
            // 
            // txt_orderid
            // 
            this.txt_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(371, 38);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(121, 30);
            this.txt_orderid.TabIndex = 9;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerName.Location = new System.Drawing.Point(371, 83);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(121, 30);
            this.txt_CustomerName.TabIndex = 10;
            // 
            // txt_Itemid
            // 
            this.txt_Itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Itemid.Location = new System.Drawing.Point(371, 129);
            this.txt_Itemid.Name = "txt_Itemid";
            this.txt_Itemid.Size = new System.Drawing.Size(121, 30);
            this.txt_Itemid.TabIndex = 11;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemqty.Location = new System.Drawing.Point(371, 170);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(121, 30);
            this.txt_itemqty.TabIndex = 12;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(371, 206);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(121, 30);
            this.txt_itemprice.TabIndex = 13;
            // 
            // txt_DeliveryAddress
            // 
            this.txt_DeliveryAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DeliveryAddress.Location = new System.Drawing.Point(371, 242);
            this.txt_DeliveryAddress.Name = "txt_DeliveryAddress";
            this.txt_DeliveryAddress.Size = new System.Drawing.Size(121, 30);
            this.txt_DeliveryAddress.TabIndex = 14;
            // 
            // cmb_Ordercity
            // 
            this.cmb_Ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Ordercity.FormattingEnabled = true;
            this.cmb_Ordercity.Location = new System.Drawing.Point(371, 279);
            this.cmb_Ordercity.Name = "cmb_Ordercity";
            this.cmb_Ordercity.Size = new System.Drawing.Size(121, 33);
            this.cmb_Ordercity.TabIndex = 15;
            // 
            // rdb_online
            // 
            this.rdb_online.AutoSize = true;
            this.rdb_online.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_online.Location = new System.Drawing.Point(371, 318);
            this.rdb_online.Name = "rdb_online";
            this.rdb_online.Size = new System.Drawing.Size(87, 29);
            this.rdb_online.TabIndex = 16;
            this.rdb_online.TabStop = true;
            this.rdb_online.Text = "Online";
            this.rdb_online.UseVisualStyleBackColor = true;
            // 
            // rdb_cashondelivery
            // 
            this.rdb_cashondelivery.AutoSize = true;
            this.rdb_cashondelivery.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_cashondelivery.Location = new System.Drawing.Point(497, 314);
            this.rdb_cashondelivery.Name = "rdb_cashondelivery";
            this.rdb_cashondelivery.Size = new System.Drawing.Size(184, 29);
            this.rdb_cashondelivery.TabIndex = 17;
            this.rdb_cashondelivery.TabStop = true;
            this.rdb_cashondelivery.Text = "Cash On Delivery";
            this.rdb_cashondelivery.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(257, 390);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(172, 40);
            this.btn_placeorder.TabIndex = 18;
            this.btn_placeorder.Text = "Place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 741);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_cashondelivery);
            this.Controls.Add(this.rdb_online);
            this.Controls.Add(this.cmb_Ordercity);
            this.Controls.Add(this.txt_DeliveryAddress);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_Itemid);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.lbl_deliveryaddress);
            this.Controls.Add(this.lbl_ItemPrice);
            this.Controls.Add(this.lbl_Itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_orderid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_Itemqty;
        private System.Windows.Forms.Label lbl_ItemPrice;
        private System.Windows.Forms.Label lbl_deliveryaddress;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.TextBox txt_Itemid;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.TextBox txt_DeliveryAddress;
        private System.Windows.Forms.ComboBox cmb_Ordercity;
        private System.Windows.Forms.RadioButton rdb_online;
        private System.Windows.Forms.RadioButton rdb_cashondelivery;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

