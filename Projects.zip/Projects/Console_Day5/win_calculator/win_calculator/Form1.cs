﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace win_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Addition_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1: ");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number2 : ");
            }
            else
            {
                Calculator.Calculator obj = new Calculator.Calculator();
                lbl_Solution.Text = obj.GetSum(Convert.ToInt32(txt_Number1.Text), Convert.ToInt32(txt_Number2.Text)).ToString();
            }
        }

        private void btn_Subtraction_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1: ");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number2 : ");
            }
            else
            {
                Calculator.Calculator obj = new Calculator.Calculator();
                lbl_Solution.Text = obj.GetSubtract(Convert.ToInt32(txt_Number1.Text), Convert.ToInt32(txt_Number2.Text)).ToString();
            }
        }

        private void btn_Multiply_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1: ");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number2 : ");
            }
            else
            {
                Calculator.Calculator obj = new Calculator.Calculator();
                lbl_Solution.Text = obj.GetMultiply(Convert.ToInt32(txt_Number1.Text), Convert.ToInt32(txt_Number2.Text)).ToString();
            }
        }

        private void btn_Division_Click(object sender, EventArgs e)
        {
            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1: ");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number2 : ");
            }
            else
            {
                Calculator.Calculator obj = new Calculator.Calculator();
                lbl_Solution.Text = obj.GetDivide(Convert.ToDecimal(txt_Number1.Text), Convert.ToDecimal (txt_Number2.Text)).ToString();
            }
        }
    }
}
