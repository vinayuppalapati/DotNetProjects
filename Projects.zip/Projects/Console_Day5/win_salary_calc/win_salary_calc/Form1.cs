﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalaryLibrary;

namespace win_salary_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_Salary_Click(object sender, EventArgs e)
        {

        }

        private void btn_GetSalary_Click(object sender, EventArgs e)
        {
            if (txt_days.Text == string.Empty)
            {
                MessageBox.Show("Enter Days");

            }
            else if (txt_perdaysalary.Text == string.Empty)
            {
                MessageBox.Show("Enter per day salary");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int perdaysalary = Convert.ToInt32(txt_perdaysalary.Text);

                //SalaryLibrary.Salary obj = new SalaryLibrary.Salary();
                //int total = obj.GetSalary(days, perdaysalary);
                //lbl_Salary.Text = total.ToString();
                Salary obj = new Salary();
                lbl_Salary.Text=obj.GetSalary(days, perdaysalary).ToString();



            }
        }
    }
}
