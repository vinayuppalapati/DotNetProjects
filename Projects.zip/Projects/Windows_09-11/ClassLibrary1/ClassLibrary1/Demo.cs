﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
   public class Demo
    {
        public string name()
        {
            return "vinay";
        }

        public string city()
        {
            return "vijayawada";
        }
    }
}
