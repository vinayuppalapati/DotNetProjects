﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 10, EmployeeName = "VINAY", EmployeeCity = "VIJ", EmployeeExp = 6,Salary=45678 });
            emplist.Add(new Employee { EmployeeID = 11, EmployeeName = "RAHUL", EmployeeCity = "HYD", EmployeeExp = 4, Salary = 65789 });
            emplist.Add(new Employee { EmployeeID = 12, EmployeeName = "GOPI", EmployeeCity = "TENALI", EmployeeExp =8, Salary = 87632 });
            emplist.Add(new Employee { EmployeeID = 13, EmployeeName = "DINESH", EmployeeCity = "TENALI", EmployeeExp =1, Salary = 12345 });
            emplist.Add(new Employee { EmployeeID = 14, EmployeeName = "SRIKAR", EmployeeCity = "HYD", EmployeeExp = 7, Salary = 76543 });


            List<EmployeeeLeave> empleavelist = new List<EmployeeeLeave>();
            empleavelist.Add(new EmployeeeLeave { LeaveID = 100, LeaveType = "HEALTH", Reason = "HEAD", EmployeeID = 10 });
            empleavelist.Add(new EmployeeeLeave { LeaveID = 101, LeaveType = "VOCATION", Reason = "CELEBRATIONS", EmployeeID = 13 });
            empleavelist.Add(new EmployeeeLeave { LeaveID = 102, LeaveType = "HEALTH", Reason = "LEG", EmployeeID = 14 });
            empleavelist.Add(new EmployeeeLeave { LeaveID = 103, LeaveType = "RELIGION", Reason = "FUNCTION", EmployeeID = 12 });
            empleavelist.Add(new EmployeeeLeave { LeaveID = 104, LeaveType = "HEALTH", Reason = "COLD", EmployeeID = 10 });



            //linq-1
          
            var i = from e in emplist
                    where e.EmployeeExp > 5
                    select e;

            foreach(var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " "+j.EmployeeCity);
            }
          //lambda-1

            var exp5 = emplist.Where((e) => e.EmployeeExp > 5);
            foreach (var j in exp5)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity);
            }
            //linq-2
            i = from e in emplist
                where e.Salary > 50000
                select e;
            foreach (var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity+" "+j.Salary );
            }
            //lambda-2

            exp5 = emplist.Where((e) => e.Salary > 50000);
             foreach (var j in exp5)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity+" "+j.Salary);
            }
            //linq-3
            string city = "HYD";
            i = from e in emplist
                where e.EmployeeCity == city
                select e;
            foreach (var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity);
            }
            //lambda-3
            exp5 = emplist.Where((e) => e.EmployeeCity == city);
            foreach (var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity);
            }
            //linq-4
           
            i = from e in emplist
                where e.EmployeeName.StartsWith("V")
                select e;
            foreach (var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity);
            }

            //lambda-4
            exp5 = emplist.Where((e) => e.EmployeeName.StartsWith("V"));
            foreach (var j in i)
            {
                Console.WriteLine(j.EmployeeID + " " + j.EmployeeName + " " + j.EmployeeExp + " " + j.EmployeeCity);
            }


            //linq-B

         var   ii = from c in emplist
                join e in empleavelist
                on c.EmployeeID equals e.EmployeeID
                select new { EID=c.EmployeeID, ENAME=c.EmployeeName, ECITY=c.EmployeeCity, LID=e.LeaveID, LTYPE=e.LeaveType, LReason=e.Reason };

            foreach (var j in ii)
            {
                Console.WriteLine(j.EID + " " + j.ENAME + " " + j.ECITY + " " + j.LID+" "+j.LTYPE+" "+j.LReason);
            }
            //lambda-B

            var exp4 = emplist.Join(empleavelist,
                (e) => e.EmployeeID,
                (c) => c.EmployeeID,
                (e, c) => new
                {
                    CID = e.EmployeeID,
                    CName = e.EmployeeName,
                    LID = c.LeaveID,
                    LType = c.LeaveType,
                    LReason = c.Reason

                });

            foreach(var j in exp4)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.LID + " "+ j.LType +" "+j.LReason);
            }
            Console.ReadLine();
        }
    }
}
