﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerName = "ABC", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 15, CustomerName = "YXA", CustomerCity = "HYD" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 20, CustomerName = "LMO", CustomerCity = "Delhi" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 26, CustomerName = "LION", CustomerCity = "VIJ" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 29, CustomerName = "TIGER", CustomerCity = "BGL" });


            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "LAPTOP", ItemPrice = 5678 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 2, ItemName = "MOBILE", ItemPrice = 783 });

            ordlist.Add(new Order { OrderID = 1003, CustomerID = 2, ItemName = "TV", ItemPrice = 3627 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 3, ItemName = "LAPTOP", ItemPrice = 7348 });

            var data = custlist.Where((c) => c.CustomerCity == "BGL");
            foreach(var x in data)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName);

            }
            var count = custlist.Count((c)=>c.CustomerCity=="BGL");
            Console.WriteLine(count);

           var obj=custlist.FirstOrDefault((c)=>c.CustomerID==1);
            if (obj != null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);

            }
            else
            {
                Console.WriteLine("Not found");
            }
            var status = custlist.Exists((c) => c.CustomerID == 1);
            Console.WriteLine(status);

            var dataprojection = custlist.Where((c) => c.CustomerCity == "BGL").Select((s) => new { CID = s.CustomerID, CName = s.CustomerName });


            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + " " + d.CName);
            }


            var dataorderby = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName);


            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            var dataorder = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName).ThenByDescending((o1) => o1.CustomerCity);



            foreach (var d in dataorder)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
           



            var groupdata = custlist.GroupBy((g) => g.CustomerCity).
                Select((s) => new { City = s.Key, Count = s.Count(), Avg = s.Average((a) => a.CustomerAge) });


            foreach(var x in groupdata)
            {
                Console.WriteLine(x.City + " " + x.Count + " " + x.Avg);
            }


            var joindata = custlist.Join(ordlist, 
                (c) => c.CustomerID,
                (o) => o.CustomerID,
                (c, o) => new
                {
                    CID = c.CustomerID,
                    CName = c.CustomerName,
                    OID = o.OrderID,
                    IName = o.ItemName,
                    IPrice = o.ItemPrice
                });

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " "+j.IName + " " + j.IPrice);
            }

            Console.ReadLine();

        }
    }
}
