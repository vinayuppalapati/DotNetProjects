﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("Vinay", "Vijayawada");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter you Operation : 1-Add, 2-Find, 3-Remove, 4-Show, 5-Leave,6-Exit");
                int Opt = Convert.ToInt32(Console.ReadLine());
                switch (Opt)
                {
                    case 1:
                        Console.WriteLine("Enter Employee Name : ");
                        string Name = Console.ReadLine();
                        Console.WriteLine("Enter Employee City : ");
                        string City = Console.ReadLine();

                        Employee em = new Employee(Name, City);
                        c.AddEmployee(em);
                        Console.WriteLine("Employee Added : " + em.PEmployeeID);
                        break;

                    case 2:
                        Console.WriteLine("Enter Employee ID: ");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeID + " " + obj.PEmployeeName);
                        }
                        else
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                        break;


                    case 3:
                        Console.WriteLine("Enter Employee ID:");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(EID);
                        if (status)
                        {
                            Console.WriteLine("Employee  is removed successfully");
                        }
                        else
                        {
                            Console.WriteLine("Employee is Not Found");
                        }
                        break;

                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        Console.WriteLine("Enter Employee ID:");
                        int EmpID = Convert.ToInt32(Console.ReadLine());
                        Employee obj3 = c.Find(EmpID);
                        Console.WriteLine("Enter the Reason for Leave");
                        string r = Console.ReadLine();
                        obj3.TakeLeave(r);
                        break;

                    case 6:
                        flag = false;
                        break;





                }


                }
            }
    }
}
