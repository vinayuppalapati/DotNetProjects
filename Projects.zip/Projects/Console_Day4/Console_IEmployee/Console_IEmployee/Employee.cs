﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_IEmployee
{
    class Employee:IHREMp,IManagerEmp,IAccountEmp
    {

        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccountNumber;
        private string EmployeeAccbankName;
        private int EmployeeAge;


        public Employee(int EmployeeID, string EmployeeName, string EmployeeCity, string EmployeeAddress, string EmployeeProjectDetails, int EmployeeExp, int EmployeeAccountNumber, string EmployeeAccbankName,int EmployeeAge,int EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeAge = EmployeeAge;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNumber = EmployeeAccountNumber;
            this.EmployeeAccbankName = EmployeeAccbankName;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeAccountNumber()
        {
            return this.EmployeeAccountNumber;
        }

        public int GetEmployeeID()
        {
            return this.EmployeeID;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }
    }
}
