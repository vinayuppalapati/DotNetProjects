﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_IEmployee
{
    class Manager
    {
        public void GetEmployee(IManagerEmp e)
        {
            Console.WriteLine("Manager Section");
            Console.WriteLine("Employee ID is : " + e.GetEmployeeID());
            Console.WriteLine("Employee Project Details : "+e.GetEmployeeProjectDetails());
            Console.WriteLine( "Experience is : "+e.GetEmployeeExp());
           
        }
    }
}
