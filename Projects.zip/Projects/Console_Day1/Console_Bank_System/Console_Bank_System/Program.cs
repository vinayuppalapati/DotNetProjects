﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Bank_System
{
    class Program
    {
        static void Main(string[] args)
        {

            int AccountID,balance=0;
            bool flag = true;
            string CustomerName,TypeofAccount,CustomerAddress;
            Console.WriteLine("Enter Account No");
            AccountID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name");
            CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Customer Address");
            CustomerAddress = Console.ReadLine();
            Console.WriteLine("Enter Account type");
            TypeofAccount = Console.ReadLine();
            int n, d;

            while (flag)
            {
                Console.WriteLine("1.Deposit");
                Console.WriteLine("2.Withdraw");
                Console.WriteLine("3.Check Balance");
                Console.WriteLine("4.Exit");

                n=Convert.ToInt32(Console.ReadLine());
                switch (n)
                {

                    case 1:
                        Console.WriteLine("Enter the Amount to deposit");
                        d=Convert.ToInt32(Console.ReadLine());
                        if ( d>= 500)
                        {
                            Console.WriteLine("Amount is Deposited");
                            balance = balance + d;
                        }
                        else
                        {
                            Console.WriteLine("Amount must be greater than 500");
                        }
                        break;


                    case 2:
                        Console.WriteLine("Enter amount to withdraw");
                        d = Convert.ToInt32(Console.ReadLine());
                        if (balance < d && d<5000 )
                        {
                            Console.WriteLine("Insufficient Balance");
                        }
                        else if (d > 5000x)
                        {
                            Console.WriteLine("Maximum limit per Withdraw is 5000");
                        }
                        else
                        {
                            balance = balance - d;
                            Console.WriteLine("Amount Debited is "+d);
                            Console.WriteLine("Available balance is " + balance);

                        }
                        break;

                    case 3:
                        Console.WriteLine("Available balance is " + balance);
                        break;

                    case 4:
                        flag=false;
                        break;


                }

            }
            

            
        }
    }
}
