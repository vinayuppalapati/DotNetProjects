﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class NewAccount : Form
    {
        public NewAccount()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewAccount_Load(object sender, EventArgs e)
        {
            cmb_accounttype.Items.Add("Savings");
            cmb_accounttype.Items.Add("Current");
            txt_customerid.Text = Test.cid.ToString();
            // txt_customerid.
            txt_customerid.Enabled = false;
        }

        private void btn_NewAccount_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter CustomerID");
            }
            else if (cmb_accounttype.Text ==string.Empty)
            {
                MessageBox.Show("Select Account type ");
            }
            else if (txt_balance.Text == string.Empty)
            {
                MessageBox.Show("Enter Balance");
            }else if (Convert.ToInt32(txt_balance.Text) < 0)
            {
                MessageBox.Show("Balance Should be greater than 0");
            }
            else
            {
                BankDAL dal = new BankDAL();
                Account a = new Account();
                a.AccountBalance = Convert.ToInt32(txt_balance.Text);
                a.CustomerID = Convert.ToInt32(txt_customerid.Text);
                a.AccountType = cmb_accounttype.Text;

                int id =dal.addAccount(a);
                MessageBox.Show(" New Account Number is " + id);
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_balance.Text = string.Empty;
            cmb_accounttype.Text = string.Empty;
        }
    }
}
