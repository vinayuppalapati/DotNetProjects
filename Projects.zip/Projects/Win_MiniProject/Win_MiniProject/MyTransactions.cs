﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class MyTransactions : Form
    {
        public MyTransactions()
        {
            InitializeComponent();
        }

        private void MyTransactions_Load(object sender, EventArgs e)
        {
            BankDAL dal = new BankDAL();
            List<int> y = dal.showOnlyAccounts(Test.cid);
            foreach (int x in y)
            {
                cmb_accountid.Items.Add(x);
            }
        }

        private void btn_showtransactions_Click(object sender, EventArgs e)
        {
            if (cmb_accountid.Text == string.Empty)
            {
                MessageBox.Show("Enter Account ID");
            }else
            {
                BankDAL dal = new BankDAL();
                
                List<Transaction> list= dal.showTransactions(Convert.ToInt32(cmb_accountid.Text));
                dgv_transactions.DataSource = list;

            }
        }
    }
}
