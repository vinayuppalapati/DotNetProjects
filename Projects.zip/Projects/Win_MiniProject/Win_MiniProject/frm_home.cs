﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class frm_home : Form
    {
        public frm_home()
        {
            InitializeComponent();
        }

        private void btn_newacc_Click(object sender, EventArgs e)
        {
            NewAccount a = new NewAccount();
            a.Show();
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
            MyAccount m = new MyAccount();
            m.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            NewTransaction t = new NewTransaction();
            t.Show();
        }

        private void btn_mytransactions_Click(object sender, EventArgs e)
        {
            MyTransactions my = new MyTransactions();
            my.Show();
        }
    }
}
