﻿namespace Win_MiniProject
{
    partial class NewAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.lbl_accounttype = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.cmb_accounttype = new System.Windows.Forms.ComboBox();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.btn_NewAccount = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(52, 58);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(116, 25);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "CustomerID";
            // 
            // lbl_accounttype
            // 
            this.lbl_accounttype.AutoSize = true;
            this.lbl_accounttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accounttype.Location = new System.Drawing.Point(52, 123);
            this.lbl_accounttype.Name = "lbl_accounttype";
            this.lbl_accounttype.Size = new System.Drawing.Size(126, 25);
            this.lbl_accounttype.TabIndex = 1;
            this.lbl_accounttype.Text = "Account type";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(52, 184);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(83, 25);
            this.lbl_balance.TabIndex = 2;
            this.lbl_balance.Text = "Balance";
            // 
            // txt_customerid
            // 
          
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(258, 58);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(162, 30);
            this.txt_customerid.TabIndex = 3;
            // 
            // cmb_accounttype
            // 
            this.cmb_accounttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_accounttype.FormattingEnabled = true;
            this.cmb_accounttype.Location = new System.Drawing.Point(258, 115);
            this.cmb_accounttype.Name = "cmb_accounttype";
            this.cmb_accounttype.Size = new System.Drawing.Size(162, 33);
            this.cmb_accounttype.TabIndex = 4;
            // 
            // txt_balance
            // 
            this.txt_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_balance.Location = new System.Drawing.Point(258, 179);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(162, 30);
            this.txt_balance.TabIndex = 5;
            this.txt_balance.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn_NewAccount
            // 
            this.btn_NewAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewAccount.Location = new System.Drawing.Point(127, 270);
            this.btn_NewAccount.Name = "btn_NewAccount";
            this.btn_NewAccount.Size = new System.Drawing.Size(156, 49);
            this.btn_NewAccount.TabIndex = 6;
            this.btn_NewAccount.Text = "New Account";
            this.btn_NewAccount.UseVisualStyleBackColor = true;
            this.btn_NewAccount.Click += new System.EventHandler(this.btn_NewAccount_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(314, 269);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(149, 50);
            this.btn_reset.TabIndex = 7;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // NewAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 417);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_NewAccount);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.cmb_accounttype);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_accounttype);
            this.Controls.Add(this.lbl_customerid);
            this.Name = "NewAccount";
            this.Text = "NewAccount";
            this.Load += new System.EventHandler(this.NewAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Label lbl_accounttype;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.ComboBox cmb_accounttype;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Button btn_NewAccount;
        private System.Windows.Forms.Button btn_reset;
    }
}