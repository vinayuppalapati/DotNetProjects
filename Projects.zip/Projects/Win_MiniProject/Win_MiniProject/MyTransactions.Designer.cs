﻿namespace Win_MiniProject
{
    partial class MyTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.btn_showtransactions = new System.Windows.Forms.Button();
            this.dgv_transactions = new System.Windows.Forms.DataGridView();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_transactions)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountid.Location = new System.Drawing.Point(117, 37);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(108, 25);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "Account ID";
            // 
            // btn_showtransactions
            // 
            this.btn_showtransactions.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showtransactions.Location = new System.Drawing.Point(222, 103);
            this.btn_showtransactions.Name = "btn_showtransactions";
            this.btn_showtransactions.Size = new System.Drawing.Size(207, 49);
            this.btn_showtransactions.TabIndex = 2;
            this.btn_showtransactions.Text = "Show Transactions";
            this.btn_showtransactions.UseVisualStyleBackColor = true;
            this.btn_showtransactions.Click += new System.EventHandler(this.btn_showtransactions_Click);
            // 
            // dgv_transactions
            // 
            this.dgv_transactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_transactions.Location = new System.Drawing.Point(41, 178);
            this.dgv_transactions.Name = "dgv_transactions";
            this.dgv_transactions.Size = new System.Drawing.Size(640, 230);
            this.dgv_transactions.TabIndex = 3;
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(304, 37);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(149, 33);
            this.cmb_accountid.TabIndex = 8;
            // 
            // MyTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 449);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.dgv_transactions);
            this.Controls.Add(this.btn_showtransactions);
            this.Controls.Add(this.lbl_accountid);
            this.Name = "MyTransactions";
            this.Text = "MyTransactions";
            this.Load += new System.EventHandler(this.MyTransactions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_transactions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Button btn_showtransactions;
        private System.Windows.Forms.DataGridView dgv_transactions;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}