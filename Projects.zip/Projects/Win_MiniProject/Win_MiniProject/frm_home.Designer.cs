﻿namespace Win_MiniProject
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newacc = new System.Windows.Forms.Button();
            this.btn_myaccount = new System.Windows.Forms.Button();
            this.btn_newtransaction = new System.Windows.Forms.Button();
            this.btn_mytransactions = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newacc
            // 
            this.btn_newacc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newacc.Location = new System.Drawing.Point(35, 123);
            this.btn_newacc.Name = "btn_newacc";
            this.btn_newacc.Size = new System.Drawing.Size(175, 43);
            this.btn_newacc.TabIndex = 0;
            this.btn_newacc.Text = "New Account";
            this.btn_newacc.UseVisualStyleBackColor = true;
            this.btn_newacc.Click += new System.EventHandler(this.btn_newacc_Click);
            // 
            // btn_myaccount
            // 
            this.btn_myaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_myaccount.Location = new System.Drawing.Point(289, 122);
            this.btn_myaccount.Name = "btn_myaccount";
            this.btn_myaccount.Size = new System.Drawing.Size(177, 44);
            this.btn_myaccount.TabIndex = 1;
            this.btn_myaccount.Text = "My Account";
            this.btn_myaccount.UseVisualStyleBackColor = true;
            this.btn_myaccount.Click += new System.EventHandler(this.btn_myaccount_Click);
            // 
            // btn_newtransaction
            // 
            this.btn_newtransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtransaction.Location = new System.Drawing.Point(35, 227);
            this.btn_newtransaction.Name = "btn_newtransaction";
            this.btn_newtransaction.Size = new System.Drawing.Size(175, 43);
            this.btn_newtransaction.TabIndex = 3;
            this.btn_newtransaction.Text = "New transaction";
            this.btn_newtransaction.UseVisualStyleBackColor = true;
            this.btn_newtransaction.Click += new System.EventHandler(this.btn_newtransaction_Click);
            // 
            // btn_mytransactions
            // 
            this.btn_mytransactions.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mytransactions.Location = new System.Drawing.Point(289, 227);
            this.btn_mytransactions.Name = "btn_mytransactions";
            this.btn_mytransactions.Size = new System.Drawing.Size(177, 43);
            this.btn_mytransactions.TabIndex = 2;
            this.btn_mytransactions.Text = "My Transactions";
            this.btn_mytransactions.UseVisualStyleBackColor = true;
            this.btn_mytransactions.Click += new System.EventHandler(this.btn_mytransactions_Click);
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 445);
            this.Controls.Add(this.btn_newtransaction);
            this.Controls.Add(this.btn_mytransactions);
            this.Controls.Add(this.btn_myaccount);
            this.Controls.Add(this.btn_newacc);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newacc;
        private System.Windows.Forms.Button btn_myaccount;
        private System.Windows.Forms.Button btn_newtransaction;
        private System.Windows.Forms.Button btn_mytransactions;
    }
}