﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter Account Id:");
            //int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance");
            int balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Account type ");
            string type = Console.ReadLine();
            Account obj = null;
            if (type == "savings")
            {
                obj = new Saving( Name, balance);
            }
            else if (type == "current")
            {
                obj = new Current( Name, balance);
            }
            if (obj != null)
            {
                obj.StopPayment();
                obj.BlockAccount();
                Console.WriteLine("Balance is :" + obj.GetBalance());
                Console.WriteLine("Enter Amount to Deposit :");
                obj.Deposit(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Balance is :" + obj.GetBalance());
                Console.WriteLine("Enter Amount to Withdraw :");

                obj.Withdraw(Convert.ToInt32(Console.ReadLine()));

                Console.WriteLine("Balance is :" + obj.GetBalance());
               // Console.WriteLine("Account ID is  :"+obj.PAccountID);

            }
            Console.ReadLine();
        }
    }
}
