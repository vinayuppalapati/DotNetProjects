﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Current: Account

    {
        private int CAccountID;
        public static int Count=2000;
        public Current(string CustomerName, int AccountBalance) : base(CustomerName, AccountBalance)
        {
            Current.Count++;
            this.CAccountID = Current.Count;
            Console.WriteLine("Current Constructor");

        }
        public int PAccountID
        {
            get
            {
                return this.CAccountID;
            }
        }
        public override void Deposit(int Amt)
        {
             this.AccountBalance += Amt;
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance -= Amt;
        }
    }
}
