﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    abstract class Account
    {

      //  protected int AccountID;
        protected string CustomerName;
        protected int AccountBalance;

        public Account(string CustomerName,int AccountBalance)
        {
          //  this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("Account Constructor");

        }
        //public int PAccountID
        //{
        //    get
        //    {
        //        return this.AccountID;
        //    }
        //}
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
            
        }
        public int PAccountBalance
        {
            get
            {
                return this.AccountBalance;
            }
        }

        public void StopPayment()
        {
            Console.WriteLine("Stop Payment Called");
        }
        public void BlockAccount()
        {
            Console.WriteLine("Block Account Called");
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }

        public abstract void Deposit(int Amt);
        public abstract void Withdraw(int Amt);

    }
}
