﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the Customer Name ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the ItemPrice");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the ItemQty");
            int qty = Convert.ToInt32(Console.ReadLine());

            Order obj = null;
               
            Console.WriteLine("Enter the Type of Order ");
            string type = Console.ReadLine();
            if (type == "Order")
            {
                obj = new Order(name, qty, price);

            }
            else if(type == "Overseas")
            {
                obj = new Order_Overseas(name, qty, price);
            }

            if (obj != null)
            {
                Console.WriteLine(obj.POrderID + " " + obj.PCustomerName + " " + obj.PItemPrice + " " + obj.PItemQty + " " + obj.GetOrderValue());
            }
            Console.ReadLine();
        }
    }
}
