﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_Overriding
{
    class Order
    {
        private static int count = 1000;
        private int OrderID;
        private string CustomerName;
        private int ItemQty;
        private int ItemPrice;

        public Order(string CustomerName,int ItemQty,int ItemPrice)
        {
            Order.count++;
            this.OrderID  = Order.count;
            this.CustomerName = CustomerName;
            this.ItemPrice = ItemPrice;
            this.ItemQty = ItemQty;
        }

        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemQty;
            }
        }
        public virtual int GetOrderValue()
        {
            return this.ItemPrice * this.ItemQty;

        }



    }
}
