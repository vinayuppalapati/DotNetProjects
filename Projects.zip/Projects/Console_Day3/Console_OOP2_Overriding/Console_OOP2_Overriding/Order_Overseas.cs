﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_Overriding
{
    class Order_Overseas: Order
    {
        public Order_Overseas(string CustomerName,int ItemQty,int ItemPrice) : base(CustomerName, ItemQty, ItemPrice)
        {

        }
        public override int GetOrderValue()
        {
            int amt= this.PItemPrice * this.PItemQty;
            amt = amt - (amt * 10/100);
            return amt;

        }
    }
}
