﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                Employee emp = dal.Find(ID);
                if (emp != null)
                {
                    txt_employeename.Text = emp.EmployeeName;
                    txt_employeecity.Text = emp.EmployeeCity;
                    txt_employeepassword.Text = emp.EmployeePassword;
                    txt_employeedoj.Text = emp.EmployeeDOJ.ToString();
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_employeepassword.Text == string.Empty)
            {
                MessageBox.Show("Enter password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
               bool status= dal.Update(ID, txt_employeecity.Text, txt_employeepassword.Text);
                if (status)
                {
                    MessageBox.Show("Updated");

                }
                else
                {
                    MessageBox.Show("Not found");
                }
                    
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                bool status = dal.Delete(Convert.ToInt32(txt_employeeid.Text));
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }
    }
}
