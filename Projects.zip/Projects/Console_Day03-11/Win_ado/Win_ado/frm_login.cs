﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmployeeID");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");

            }
             
            else
            {
                try
                {
                    EmployeeDAL_Proc dal = new EmployeeDAL_Proc();
                    bool status = dal.Login(Convert.ToInt32(txt_employeeid.Text), txt_password.Text);
                    if (status)
                    {

                        MessageBox.Show("Successfully Login");
                        //frm_home home = new frm_home();
                        //home.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid");
                    }
                }
                catch(System.Data.SqlClient.SqlException exp)
                {
                    MessageBox.Show("SQL ERROR");
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);

                }
                finally
                {
                    try
                    {
                        int a, b = 0;
                        a = 23 / b;
                    }
                    catch (DivideByZeroException)
                    {
                        MessageBox.Show("divide by zero");
                    }
                    MessageBox.Show("finally Block");
                }
            }
            
            
        }

        private void btn_loginsqlinjection_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmployeeID");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");

            }
            else
            {
                int id = Convert.ToInt32(txt_employeeid.Text);
                string password = txt_password.Text;

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Loginsqlinjection(id, password);
                if (status)
                {
                    MessageBox.Show("valid user");
                }
                else
                {
                    MessageBox.Show("Invalid");
                }
            }
        }
    }
}
