﻿namespace Win_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.btn_newemployee = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(36, 64);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(156, 25);
            this.lbl_employeename.TabIndex = 0;
            this.lbl_employeename.Text = "Employee Name";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(36, 112);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(138, 25);
            this.lbl_employeecity.TabIndex = 1;
            this.lbl_employeecity.Text = "Employee City";
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeepassword.Location = new System.Drawing.Point(36, 167);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(190, 25);
            this.lbl_employeepassword.TabIndex = 2;
            this.lbl_employeepassword.Text = "Employee Password";
            // 
            // txt_employeename
            // 
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(308, 61);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(177, 30);
            this.txt_employeename.TabIndex = 3;
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(308, 107);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(177, 30);
            this.txt_employeecity.TabIndex = 4;
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(308, 162);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(177, 30);
            this.txt_employeepassword.TabIndex = 5;
            // 
            // btn_newemployee
            // 
            this.btn_newemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newemployee.Location = new System.Drawing.Point(116, 257);
            this.btn_newemployee.Name = "btn_newemployee";
            this.btn_newemployee.Size = new System.Drawing.Size(151, 50);
            this.btn_newemployee.TabIndex = 6;
            this.btn_newemployee.Text = "New Employee";
            this.btn_newemployee.UseVisualStyleBackColor = true;
            this.btn_newemployee.Click += new System.EventHandler(this.btn_newemployee_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(343, 257);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(142, 50);
            this.btn_reset.TabIndex = 7;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 437);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newemployee);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.Button btn_newemployee;
        private System.Windows.Forms.Button btn_reset;
    }
}

