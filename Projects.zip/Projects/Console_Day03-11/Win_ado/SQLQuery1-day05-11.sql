select * from tbl_employees where EmployeeId like '100%'

select * from tbl_employees where EmployeeId like '_000'
--select * from tbl_employees where EmployeeID like '%"+vij+"%' or EmployeeName like '%"+Search+"%' or Employeecity like '%"+Search+"%' or EmployeePassword like '%"+Search+"%' 


create proc proc_addemployee(@name varchar(100),@city varchar(100),@password varchar(100))
as
insert tbl_employees values(@name,@city,@password,getdate())
return @@identity
--1
create proc proc_employeedetails(@id int)
as
select * from tbl_employees where EmployeeId=@id

--2
create proc proc_showemployees(@city varchar(100))
as
select * from tbl_employees where EmployeeCity=@city
--3
create proc proc_searchemployees(@key varchar(100))
as
select * from tbl_employees where EmployeeId like '%+key+%' or EmployeeName like '%+key+%' or EmployeeCity like '%+key+%';
--4
create proc proc_updateemployee(@id int,@city varchar(100),@password varchar(100))
as
update tbl_employees set EmployeeCity=@city, EmployeePassword=@password where EmployeeId=@id
return @@rowcount
--5
create proc proc_deleteemployee(@id int)
as
delete tbl_employees where EmployeeId=@id
return @@rowcount

--6


create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_employees where EmployeeId=@id and EmployeePassword=@password
return @count

--7

