use PathfrontADO;

select * from  tbl_customers

create proc proc_addcustomer(@name varchar(100),@password varchar(100),
@city varchar(100),@address varchar(100),@mobileno varchar(100),
@email varchar(100))
as
insert tbl_customers values(@name,@password,@city,@address,@mobileno,@email)
return @@identity
--1
create proc proc_customerdetails(@id int)
as
select * from tbl_customers where CustomerID=@id

--2

create proc proc_showcustomers(@city varchar(100))
as
select * from tbl_customers where  CustomerCity=@city
--3

create proc proc_updatecustomer(@id int,@address varchar(100),@mobileno varchar(100))
as
update tbl_customers set CustomerAddress=@address,CustomerMobileNo=@mobileno where CustomerID=@id
return @@rowcount
--4

create proc proc_deletecustomer(@id int)
as
delete tbl_customers where CustomerID=@id
return @@rowcount


--5
create proc proc_logincustomer(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_customers where CustomerID=@id and CustomerPassword=@password
return @count

--6
