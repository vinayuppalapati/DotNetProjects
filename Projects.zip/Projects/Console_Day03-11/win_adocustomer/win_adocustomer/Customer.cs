﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;


namespace win_adocustomer
{
    class Customer
    {
        public int  CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPassword { get; set; }

        public string CustomerCity { get; set; }

        public string CustomerAddress { get; set; }
        public string CustomerMobileNo { get; set; }
        public string CustomerEmailID { get; set; }
        
      
    }
}
