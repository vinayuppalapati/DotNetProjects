﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_adocustomer
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {

            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter Customer id");

            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                try
                {

                    CustomerDAL_proc dal = new CustomerDAL_proc();
                    bool status = dal.Login(Convert.ToInt32(txt_customerid.Text), txt_password.Text);
                    if (status)
                    {
                        MessageBox.Show("Valid user");
                        frm_New Add = new frm_New();
                        Add.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid user");
                    }
                }catch(Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
        }
        }
    }
}
