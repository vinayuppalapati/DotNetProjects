﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_adocustomer
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            frm_New f1 = new frm_New();
            f1.Show();

        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_customeremailid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailID");
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("Enter MobileNo");
            }
            else
            {
                try
                {
                    int ID = Convert.ToInt32(txt_customerid.Text);
                    CustomerDAL_proc dal = new CustomerDAL_proc();
                    bool status = dal.update(ID, txt_customermobileno.Text, txt_customeremailid.Text);
                    if (status)
                    {
                        MessageBox.Show("Updated");

                    }
                    else
                    {
                        MessageBox.Show("Not found");
                    }
                }catch(Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }   
            else
            {
                try
                { 
                CustomerDAL_proc dal = new CustomerDAL_proc();
                bool status = dal.delete(Convert.ToInt32(txt_customerid.Text));
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                try { 
                int ID = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL_proc dal = new CustomerDAL_proc();
                Customer cus = dal.Find(ID);
                if (cus != null)
                {
                    txt_customername.Text = cus.CustomerName;
                    txt_customercity.Text = cus.CustomerCity;
                    txt_customerpassword.Text = cus.CustomerPassword;
                    txt_customeremailid.Text = cus.CustomerEmailID;
                    txt_customermobileno.Text = cus.CustomerMobileNo;
                    txt_customeraddress.Text = cus.CustomerAddress;

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else
            {
                try { 
                    CustomerDAL_proc dal = new CustomerDAL_proc();
                    string city = txt_customercity.Text;
                    List<Customer> list = dal.ShowCustomers(city);
                    dg_customerdata.DataSource = list;
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }
            
        }
    }
}
