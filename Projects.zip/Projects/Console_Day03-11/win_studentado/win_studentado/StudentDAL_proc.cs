﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace win_studentado
{
    class StudentDAL_proc

    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddStudent(Student st)
        {
            try
            {
                SqlCommand com_cus_insert = new SqlCommand("proc_addstudent", con);
                com_cus_insert.Parameters.AddWithValue("@name", st.StudentName);
                com_cus_insert.Parameters.AddWithValue("@city", st.StudentCity);
                com_cus_insert.Parameters.AddWithValue("@address", st.StudentAddress);
                com_cus_insert.Parameters.AddWithValue("@email", st.StudentEmailID);
                com_cus_insert.Parameters.AddWithValue("@studentpassword", st.StudentPassword);
                com_cus_insert.CommandType = CommandType.StoredProcedure;

                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cus_insert.Parameters.Add(retdata);

                con.Open();
                com_cus_insert.ExecuteNonQuery();

                int ID = Convert.ToInt32(retdata.Value);

                con.Close();
                return ID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public Student Find(int ID)
        {
            try { 
            SqlCommand com_find = new SqlCommand("proc_findstudent", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();

            if (dr.Read())
            {
                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.StudentAddress = dr.GetString(3);
                s.StudentEmailID = dr.GetString(4);
                s.StudentPassword = dr.GetString(5);
                return s;
            }
            else
            {
                return null;
            }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
        public bool update(int ID, string city, string email)
        {
            try
            {

                SqlCommand com_update = new SqlCommand("proc_updatestudent", con);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@email", email);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool delete(int ID)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletestudent", con);
                com_delete.Parameters.AddWithValue("@id", ID);
                com_delete.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                con.Open();
                int count = com_delete.ExecuteNonQuery();
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }



       

        }

        public List<Student> ShowStudents(string City)
        {
            try
            {
                SqlCommand com_students = new SqlCommand
                    ("proc_showstudents", con);
                com_students.Parameters.AddWithValue("@city", City);
                com_students.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = com_students.ExecuteReader();

                List<Student> stulist = new List<Student>();
                while (dr.Read())
                {
                    Student obj = new Student();
                    obj.StudentID = dr.GetInt32(0);
                    obj.StudentName = dr.GetString(1);
                    obj.StudentCity = dr.GetString(2);
                    obj.StudentAddress = dr.GetString(3);
                    obj.StudentEmailID = dr.GetString(4);
                    obj.StudentPassword = dr.GetString(5);

                    stulist.Add(obj);
                }
                con.Close();
                return stulist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool LoginStudent(int ID, string Password)
        {
            
                SqlCommand com_login = new SqlCommand("customer_login", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            
            

        }
    }
}
