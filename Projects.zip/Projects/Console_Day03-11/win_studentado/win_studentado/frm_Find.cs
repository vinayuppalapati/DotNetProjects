﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_studentado
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            frm_New f1 = new frm_New();
            f1.Show();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                try { 
                int ID = Convert.ToInt32(txt_studentid.Text);
                StudentDAL_proc dal = new StudentDAL_proc();
                Student st = dal.Find(ID);
                if (st != null)
                {

                    txt_studentname.Text = st.StudentName;
                    txt_studentcity.Text = st.StudentCity;
                    txt_studentemailid.Text = st.StudentEmailID;
                    txt_studentaddress.Text = st.StudentAddress;
                    txt_password.Text = st.StudentPassword;

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
                catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

        }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_studentcity.Text == string.Empty)
            {
                MessageBox.Show("EnterCity");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailID");
            }
            else
            {
                try { 

                int ID = Convert.ToInt32(txt_studentid.Text);
                StudentDAL_proc dal = new StudentDAL_proc();
                bool status = dal.update(ID, txt_studentcity.Text, txt_studentemailid.Text);
                if (status)
                {
                    MessageBox.Show("Updated");

                }
                else
                {
                    MessageBox.Show("Not found");
                }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                try { 
                StudentDAL_proc dal = new StudentDAL_proc();
                bool status = dal.delete(Convert.ToInt32(txt_studentid.Text));
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }


            }
        }

        private void btn_showstudents_Click(object sender, EventArgs e)
        {
            if (txt_studentcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else
            {
                try
                {
                    StudentDAL_proc dal = new StudentDAL_proc();
                    string city = txt_studentcity.Text;
                    List<Student> list = dal.ShowStudents(city);
                    dg_studentdata.DataSource = list;
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message);
                }
            }
        }
    }
}
