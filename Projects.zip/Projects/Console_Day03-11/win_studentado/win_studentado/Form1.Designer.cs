﻿namespace win_studentado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.btn_findstudent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newstudent.Location = new System.Drawing.Point(68, 145);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(173, 55);
            this.btn_newstudent.TabIndex = 3;
            this.btn_newstudent.Text = "New Student";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_findstudent
            // 
            this.btn_findstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findstudent.Location = new System.Drawing.Point(279, 145);
            this.btn_findstudent.Name = "btn_findstudent";
            this.btn_findstudent.Size = new System.Drawing.Size(156, 55);
            this.btn_findstudent.TabIndex = 2;
            this.btn_findstudent.Text = "Find Student";
            this.btn_findstudent.UseVisualStyleBackColor = true;
            this.btn_findstudent.Click += new System.EventHandler(this.btn_findcustomer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 344);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.btn_findstudent);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.Button btn_findstudent;
    }
}

