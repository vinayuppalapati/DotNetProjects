﻿namespace win_studentado
{
    partial class frm_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentCity = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentname.Location = new System.Drawing.Point(29, 74);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(64, 25);
            this.lbl_studentname.TabIndex = 0;
            this.lbl_studentname.Text = "Name";
            this.lbl_studentname.Click += new System.EventHandler(this.lbl_studentname_Click);
            // 
            // lbl_studentCity
            // 
            this.lbl_studentCity.AutoSize = true;
            this.lbl_studentCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentCity.Location = new System.Drawing.Point(32, 119);
            this.lbl_studentCity.Name = "lbl_studentCity";
            this.lbl_studentCity.Size = new System.Drawing.Size(46, 25);
            this.lbl_studentCity.TabIndex = 1;
            this.lbl_studentCity.Text = "City";
            this.lbl_studentCity.Click += new System.EventHandler(this.lbl_studentCity_Click);
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentaddress.Location = new System.Drawing.Point(32, 170);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(85, 25);
            this.lbl_studentaddress.TabIndex = 2;
            this.lbl_studentaddress.Text = "Address";
            this.lbl_studentaddress.Click += new System.EventHandler(this.lbl_studentaddress_Click);
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentemailid.Location = new System.Drawing.Point(32, 225);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(79, 25);
            this.lbl_studentemailid.TabIndex = 3;
            this.lbl_studentemailid.Text = "EmailID";
            this.lbl_studentemailid.Click += new System.EventHandler(this.lbl_studentemailid_Click);
            // 
            // txt_studentname
            // 
            this.txt_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentname.Location = new System.Drawing.Point(182, 74);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(155, 30);
            this.txt_studentname.TabIndex = 4;
            this.txt_studentname.TextChanged += new System.EventHandler(this.txt_studentname_TextChanged);
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentcity.Location = new System.Drawing.Point(182, 119);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(155, 30);
            this.txt_studentcity.TabIndex = 5;
            this.txt_studentcity.TextChanged += new System.EventHandler(this.txt_studentcity_TextChanged);
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentaddress.Location = new System.Drawing.Point(182, 162);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(155, 30);
            this.txt_studentaddress.TabIndex = 6;
            this.txt_studentaddress.TextChanged += new System.EventHandler(this.txt_studentaddress_TextChanged);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentemailid.Location = new System.Drawing.Point(182, 217);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(155, 30);
            this.txt_studentemailid.TabIndex = 7;
            this.txt_studentemailid.TextChanged += new System.EventHandler(this.txt_studentemailid_TextChanged);
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newstudent.Location = new System.Drawing.Point(34, 361);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(147, 47);
            this.btn_newstudent.TabIndex = 8;
            this.btn_newstudent.Text = "New Student";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(343, 361);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(115, 48);
            this.btn_reset.TabIndex = 9;
            this.btn_reset.Text = "Reset";
            this.btn_reset.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(516, 47);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(105, 52);
            this.btn_find.TabIndex = 10;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_password
            // 
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(182, 263);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(155, 30);
            this.txt_password.TabIndex = 12;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(32, 271);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(98, 25);
            this.lbl_password.TabIndex = 11;
            this.lbl_password.Text = "Password";
            // 
            // frm_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 458);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentCity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "frm_New";
            this.Text = "frm_New";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentCity;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label lbl_password;
    }
}