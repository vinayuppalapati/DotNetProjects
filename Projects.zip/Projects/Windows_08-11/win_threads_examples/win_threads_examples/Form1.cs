﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace win_threads_examples
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_new_thread_Click(object sender, EventArgs e)
        {
            ThreadStart d = new ThreadStart(this.call);
            Thread th = new Thread(d);
            th.Start();//create a new thread
            th.IsBackground = true;


/*ThreadStart d = new ThreadStart(this.call1);
            Thread th2= new Thread(this.call1);
            th2.Start();
            th2.IsBackground = true;
            Thread th3 = new Thread(() => {
                MessageBox.Show("New Task 3 using lambda update1");
            });

            th3.Start();
            th3.IsBackground = true;
            */

            MessageBox.Show("Main Thread Task");

            th.Join();
            MessageBox.Show("Main Thread Task2");
        }



     




        public void call()
        {
            MessageBox.Show("Thread Task");
            Thread.Sleep(1000);
            MessageBox.Show("New Thread Task Completed");
        }

        public void call1()
        {
            MessageBox.Show("Thread Task");
        }
    }
}
