﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace win_threads_examples
{
    class Test
    {

        public Task<int> AddNumbersAsync(int n1,int n2)
        {
            Task<int> t = Task.Run(() =>
            {
                System.Threading.Thread.Sleep(5000);
                return n1 + n2;
            });
            return t;
            
        }
    }
}
