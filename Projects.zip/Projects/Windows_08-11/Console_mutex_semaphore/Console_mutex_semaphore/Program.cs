﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Console_mutex_semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            //Mutex m = new Mutex(false, "XYZ", out status);
            Semaphore s = new Semaphore(3, 4);
            Task t1 = Task.Run(() =>
            {
                s.WaitOne();
                //m.WaitOne();
                Console.WriteLine("Task 1 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 1 Completed");
                //  m.ReleaseMutex();
                s.Release();
            });


            Task t2 =  Task.Run(() =>
            {
                s.WaitOne();
              //  m.WaitOne();
                Console.WriteLine("Task 2 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 2 Completed");
                //m.ReleaseMutex();
                s.Release();
            }
                );

            Task t3 = Task.Run(() =>
            {
                s.WaitOne();
                //  m.WaitOne();
                Console.WriteLine("Task 3 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 3 Completed");
                //m.ReleaseMutex();
                s.Release();
            }
                );


            Task t4 = Task.Run(() =>
            {
                s.WaitOne();
                //  m.WaitOne();
                Console.WriteLine("Task 4 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 4 Completed");
                //m.ReleaseMutex();
                s.Release();
            }
                );

            Console.ReadLine();
        }
    }
}
