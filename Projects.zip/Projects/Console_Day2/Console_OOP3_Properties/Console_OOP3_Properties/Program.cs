﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter Student ID : ");
            //int ID = Convert.ToInt32(Console.ReadLine());



            Console.WriteLine("Enter Student Name : ");
            string s = Console.ReadLine();

            Console.WriteLine("Enter Student Marks : ");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student obj = new Student(s,marks);
            int a = obj.PSTudentID;
            string sname = obj.PStudentName;

            Student s1 = new Student("ABC", 83);
            Console.WriteLine(s1.PSTudentID);
           // obj.PStudentName = Console.ReadLine();
         
            Console.WriteLine(a + "  " + sname);
            Console.WriteLine(obj.PStudentMarks);
            obj.PStudentMarks = 200;
            Console.WriteLine(obj.PStudentMarks);
            obj.PStudentMarks = 30;
            Console.WriteLine(obj.PStudentMarks);
            Console.ReadLine();

        }
    }
}
