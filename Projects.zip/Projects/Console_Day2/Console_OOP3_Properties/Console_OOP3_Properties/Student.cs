﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3_Properties
{
    class Student
    {
        private int StudentID;
        private string StudentName;
        private int StudentMarks;
        private static int Count;
        public Student(string StudentName,int StudentMarks)
        {
            Student.Count++;
            this.StudentID = Student.Count;
            this.StudentName = StudentName;
            this.StudentMarks = StudentMarks;
        }

        static Student()
        {
            Student.Count = 1000;
            Console.WriteLine("Static Constructor");
        }
        public int PStudentMarks
        {
            get
            {
                return this.StudentMarks;
            }
            set
            {
                if (value < 0 || value > 100)
                {
                    this.StudentMarks = 0;

                }
                else
                {
                    this.StudentMarks = value;
                }
            }
        }
        public int PSTudentID
        {
            get
            {
                return this.StudentID;
            }
            //set
            //{
            //    this.StudentID = value;
            //}
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
            set
            {
                this.StudentName = value;
            }
        }

    }
}
