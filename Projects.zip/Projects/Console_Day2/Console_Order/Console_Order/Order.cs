﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Order
    {
        private int OrderID, ItemPrice, Quantity;
        private string CustomerName, ItemName;
        public Order(int OrderID,string CustomerName, string ItemName, int ItemPrice,int Quantity)
        {
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.OrderID = OrderID;
            this.ItemPrice = ItemPrice;
            this.Quantity = Quantity;

        }

        public int GetOrderAmount()
        {
            return this.Quantity * this.ItemPrice;
        }

        public string GetDetails()
        {
            return this.OrderID + " " + this.CustomerName + " " + this.ItemName + " " + this.ItemPrice+"Total Amount is " +GetOrderAmount();
        }
    }
}
