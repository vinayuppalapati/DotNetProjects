﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Program
    {
        static void Main(string[] args)
        {

            int id;
            double salary;
            string name, city;
            Console.WriteLine("Enter the Employee ID");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Employee Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the Employee City");
            city = Console.ReadLine();
            Console.WriteLine("Enter the Employee Salary");
            salary = Convert.ToInt32(Console.ReadLine());

            Employee obj = new Employee(id, name, city, salary);
            Console.WriteLine("Enter the Noofdays ");
            int i= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" Empoylee of the salary for this month is :"+ obj.GetEmployeeSalary(i));

            Console.WriteLine(obj.GetDetails());
            Console.ReadLine();





        }
    }
}
