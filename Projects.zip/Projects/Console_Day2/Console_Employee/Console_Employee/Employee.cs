﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Employee
    {
        private int EmployeeID;
        private double EmployeeSalary;
        private string EmployeeName, EmployeeCity;

        public Employee(int EmployeeID,string EmployeeName, string EmployeeCity, double EmployeeSalary)
        {
            this.EmployeeName = EmployeeName;
            this.EmployeeID = EmployeeID;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;


        }

        public double GetEmployeeSalary(int Noofdays)
        {
            double d = this.EmployeeSalary / 30;
            return Noofdays * d;
        }
        public string GetDetails()
        {
            return this.EmployeeID + "  " + this.EmployeeName + "  " + this.EmployeeCity;
        }
    
    }
}
