﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Account

    {
        private int AccountID;
        private string CustomerName;
        private int AccountBalance;

        public Account(int AccountID,string CustomerName,int AccountBalance): this()
        {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("Constructor Called with parameters");

        }
        public Account()
        {
            this.AccountID = 1222;
            Console.WriteLine("Constructor Called without parameters");
        }

        public void Withdraw(int Amt)
        {
            if (AccountBalance > Amt)
            {
                this.AccountBalance = AccountBalance - Amt;
            }
            else
            {
                Console.WriteLine("Insufficient Balance");
            }
        }
        public void Deposit(int Amt)
        {
            this.AccountBalance = AccountBalance + Amt;
        }
        public int GetBalance()
        {

            return this.AccountBalance;
        }

        public string GetName()
        {
            return this.CustomerName;
        }
    }



}
