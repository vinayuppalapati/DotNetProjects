﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inhertiance
{
    class Customer
    {
        private string CustomerEmailID;
        private string CustomerName;

        public Customer(string CustomerEmailID, string CustomerName)
        {
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerName = CustomerName;
            Console.WriteLine("Customer Constructor ");

        }

        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;
            }
            //set
            //{
            //    this.CustomerEmailID = value;
            //}
        }

        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
            //set
            //{   
            //    this.CustomerName=value;
            //}
        }
    }
}
