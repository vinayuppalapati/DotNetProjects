﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order_2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Order obj = new Order("ABC", "Mobile", 383, 3);
            Console.WriteLine(obj.GetDetails());
            

            Console.WriteLine("Enter Customer Name");
            obj.PCustomerName = Console.ReadLine();
            Console.WriteLine("Enter Item Name");
            obj.PItemName = Console.ReadLine();
            Console.WriteLine("Enter Price");
            obj.PItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Quantity");
            obj.PQuantity= Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(obj.POrderID + " " + obj.PCustomerName + " " + obj.PItemName + " " + obj.PQuantity + " " + obj.PItemPrice + " " + obj.GetOrderAmount());

            Console.ReadLine();
        }
    }
}
