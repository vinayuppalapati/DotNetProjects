﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_CallByVal_CallByRef
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] marks = new int[3];
            marks[0] = 10;
            marks[1] = 20;
            marks[2] = 30;

            Test obj = new Test();
            obj.CallArray(48,335,3,44,3,3,3,455);

            int x;
            obj.Call(out x);
            Console.WriteLine(obj.GetOrderValue(34,5564));
            Console.WriteLine(obj.GetOrderValue(ItemQty:34,ItemPrice: 5564));

            Console.WriteLine(x);

            XYZ obj1 = new XYZ();
            obj1.Call();
            obj1.GetData();



           Console.ReadLine();

        }
    }
}
