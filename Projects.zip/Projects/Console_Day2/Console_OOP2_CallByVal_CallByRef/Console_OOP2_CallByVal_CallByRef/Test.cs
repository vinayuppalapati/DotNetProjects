﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_CallByVal_CallByRef
{
    class Test
    {
        public void Call(out int Amt)
        {
            //Console.WriteLine(Amt);
            Amt = 1000;
        }

        public void CallArray(params int [] marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }
        public int GetOrderValue(int ItemPrice, int ItemQty=1,int x=1)
        {
            return ItemPrice*ItemQty*x;

        }
    }
}
