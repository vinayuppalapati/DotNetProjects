Create Database PathfrontDB

use PathfrontDB

Create Table tbl_Customers
(
CustomerID int,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerDOB DateTime
)
sp_help tbl_customers

Select * from tbl_Customers

insert tbl_Customers values(1001,'Vinay','Vijayawada','10-31-2018')

insert tbl_Customers values(1002,'Kumar','Guntur','10-18-1996')

insert tbl_Customers values(1003,'Ramesh','Hyderabad','11-18-1987')
insert tbl_Customers values(1004,'Gopi','Tenali','07-23-1995')
insert tbl_Customers values(1005,'Raju','Vijayawada','01-29-1987')
insert tbl_Customers values(1006,'Sekhar','Hyderabad','02-13-1923')
insert tbl_Customers values(1007,'Vijay','Vizag','11-18-1996')

insert tbl_Customers values(1008,'XBS',null,null)

insert tbl_Customers(CustomerID,CustomerName)values(1009,'ACS')

select * from tbl_Customers

select CustomerID,CustomerName from tbl_Customers
select * from tbl_Customers where CustomerCity='Vijayawada'

update tbl_Customers set CustomerCity='Hyd' where CustomerID=1001 and CustomerName='vinay'

delete tbl_Customers where  CustomerID = '1009'

truncate table tbl_customers
-- don't do 

alter table tbl_customers add CustomerEmail varchar(100)
--adding column to table

select * from tbl_Customers

alter table tbl_customers drop column customeremail
--droping a column

alter table tbl_customers alter column customername varchar(200)
--modifying the column data type and size

drop table tbl_Customers
--delete table and data full

select * from tbl_Customers where customercity in ('Vizag','Pune')
--any of the place will be shown

select * from tbl_Customers where Customercity is null
--For checking null value in the column we can use the is clause

select * from tbl_Customers where customerdob between '12-12-1990'	and '12-12-2000'

-- between will use the display b/n data

select * from tbl_Customers order by customerdob desc
-- order by for displaying the specific column based on the list will be made 
-- desc descending order

select * from tbl_Customers order by customerdob asc,customercity desc
--first it will be sort by dob and later it will check based on the date of birth 
--if both are same dob then it will again do sort for same dob specific list


select top 5 * from tbl_Customers order by customerdob desc
--top 1 candidate will get the top 1 after sorting the based on dateofbirth
--top clause will get the top records



 select top 1 * from employee order by salary desc 


 select len('Hello')
 -- show lenght of string

 select substring('hello',1,4)
 --it will show hell

 select lower('VINAY')
 --convert to lowercase

 select UPPER('vinay')
--convert to uppercase

select LEFT('hello',2)
--- index start from 1 in SQL
--it show he

select RIGHT('vinay',4)
--it show inay

select isnumeric('12a')
-- if it is numeric it will return 1 else 0

select CEILING(25.01)
--it will show 26

select FLOOR(25.99)
--it will shoe 25

select round(253.2323,2)
-- it show 253.2300

select ISNULL(column_name,0)
-- where in the data having null in the data we can replace NULL with some character


select * from tbl_Customers order by len(customername)asc
--it will sort the customers by length of the name in the ascending


select len(customername) from tbl_Customers
-- it will display length of the name


Create table tbl_Employees(
EmployeeID int,
EmployeeName varchar(10),
EmployeeCity varchar(10),
EmployeeSalary int
)

insert tbl_Employees values(101,'vinay','vijayawada',2323)

insert tbl_Employees values(102,'ramesh','bangalore',2123)
insert tbl_Employees values(103,'gopi','tenali',2000)
insert tbl_Employees values(104,'rahul','hyderabad',1800)
insert tbl_Employees values(105,'sandeep','guntur',2500)



select sum(Employeesalary) from tbl_Employees

select AVG(Employeesalary) from tbl_Employees

select MAX(Employeesalary) from tbl_Employees

select MIN(Employeesalary) from tbl_Employees

select COUNT(EmployeeSalary) from tbl_Employees

select COUNT(EmployeeID) from tbl_Employees

select COUNT(EmployeeName) from tbl_Employees

select COUNT(EmployeeCity) from tbl_Employees

select COUNT(*) from tbl_Employees

select GETDATE()
--return date

select * from tbl_Customers

select  customerid,customername,DATEDIFF(yy,customerdob,getdate()) from tbl_customers

--years
select  customerid,customername,DATEDIFF(DD,customerdob,getdate()) from tbl_customers
--dates


select  customerid,customername,DATEDIFF(yy,customerdob,getdate()),DATENAME(dw,customerdob) from tbl_customers
--Day


select  customerid,customername,DATEDIFF(yy,customerdob,getdate()),
DATENAME(dw,customerdob),DATEPART(dw,customerdob) from tbl_customers

select  customerid,customername,DATEDIFF(yy,customerdob,getdate()) as 'Age',
DATENAME(dw,customerdob) as 'Day',DATEPART(dw,customerdob) as 'Number',
DATENAME(M,customerdob) as 'Month' from tbl_customers


select DATEADD(mm,10,customerdob) from tbl_customers


select dateadd(yy,2,customerdob) from tbl_customers
--we use -2 after reducing years 
--we use 2 after increasing years 

select CONVERT (varchar(10),employeesalary) from tbl_Employees

Select CAST(employeesalary as decimal(12,2)) from tbl_Employees


select employeecity,count(*) As 'Count'  from tbl_Employees group by EmployeeCity

select employeecity,count(*) As 'Count',AVG(Employeesalary) from tbl_Employees group by EmployeeCity

select employeecity,AVG(Employeesalary) As 'Salary' from tbl_Employees group by EmployeeCity,EmployeeSalary
insert tbl_Employees values(106,'raja','guntur',2500)

select * from tbl_Employees
select employeecity,MAX(EMPLOYEESALARY) as 'Salary' from tbl_Employees group by EmployeeCity


select employeecity,count(*) from tbl_Employees where EmployeeSalary>2200 group by EmployeeCity

select employeecity, count(*) from tbl_Employees group by EmployeeCity 
having count(*)<2


