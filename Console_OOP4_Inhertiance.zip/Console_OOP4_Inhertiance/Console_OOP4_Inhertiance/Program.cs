﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inhertiance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Email Id");
            string Email = Console.ReadLine();
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();

           
         


            Console.WriteLine("Enter the Customer type");
            string Type = Console.ReadLine();
            if (Type == "Online")
            {
                Console.WriteLine("Enter Payment type: ");
                string payment = Console.ReadLine();
                Console.WriteLine("Enter Delivery Address: ");
                string address = Console.ReadLine();
                Customer_Online obj_online = new Customer_Online(Email, name, payment, address);
                Console.WriteLine(obj_online.PCustomerEmailID + " " + obj_online.PCustomerName+" " + obj_online.PDeliveryAddress + " " + obj_online.PPaymentType);

            }
            else
            {
                Customer obj = new Customer(Email, name);
                Console.WriteLine(obj.PCustomerEmailID + " " + obj.PCustomerName);
            }
            Console.ReadLine();

        }
    }
}
