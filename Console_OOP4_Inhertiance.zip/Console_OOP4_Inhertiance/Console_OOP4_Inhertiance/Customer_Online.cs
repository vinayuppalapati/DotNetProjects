﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inhertiance
{
    class Customer_Online : Customer
    {
        private string PaymentType;
        private string DeliveryAddress;

        public Customer_Online(string email, string Name, string PaymentType, string DeliveryAddress) : base(email, Name)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            Console.WriteLine("Customer Online Constructor");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
        }
    }
}